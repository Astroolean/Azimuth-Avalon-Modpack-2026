"""Build the complete Azimuth package with the collector correction."""
from pathlib import Path
from hashlib import sha256
import ast
import json
import os
import re
import zipfile

TASK=Path(__file__).resolve().parent
ROOT=TASK/'package/Azimuth'
PARENT=json.loads((TASK/'parent.json').read_text())
OUTPUT=TASK/'output/Azimuth_DayZ_Server_Manager_R23_Full_Package_Collector_Fix.zip'
ALLOWED={
    'Engine/azimuth_app/checks/vehicle_repair_assets.py',
    'Engine/azimuth_app/ui/dashboard_workshop.py',
    'Docs/START_HERE.md','Docs/Audit/README.md',
    'Docs/Guides/VEHICLE_WRAPS_GUIDE.txt','Docs/Guides/VEHICLE_WRAP_COVERAGE.txt',
    'Docs/Guides/TRANSPORTATION_GUIDE.txt','Docs/Guides/PLAYTHROUGH_AUDIT.txt',
}

def digest(path):
    result=sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):result.update(block)
    return result.hexdigest()

def payload(root):
    result={}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():raise ValueError('Link in release payload')
        if path.is_file():
            name=path.relative_to(root).as_posix()
            if name.endswith(('.pyc','.tmp')) or '/__pycache__/' in name:raise ValueError('Temporary file in release')
            result[name]=digest(path)
    return result

def code_assets(root):
    return {name:value for name,value in payload(root).items() if not name.startswith('Docs/')}

def test_count(path):
    text=path.read_text()
    matches=re.findall(r'Ran (\d+) tests? in',text)
    if not matches or not re.search(r'^OK\s*$',text,re.M) or re.search(r'^(FAILED|ERROR:|FAIL:)',text,re.M):
        raise ValueError('Test log did not pass: '+str(path))
    return int(matches[-1])

def validate(final):
    parent=Path(PARENT['path'])
    if digest(parent)!=PARENT['sha256']:raise ValueError('Parent hash differs')
    current=payload(ROOT)
    changed=[];unchanged=[];protected=[]
    with zipfile.ZipFile(parent) as archive:
        names=set()
        for info in archive.infolist():
            if info.is_dir():continue
            name=info.filename.removeprefix('Azimuth/');names.add(name)
            if name not in current:raise ValueError('Original payload removed: '+name)
            if current[name]==sha256(archive.read(info)).hexdigest():unchanged.append(name)
            else:
                if name not in ALLOWED:raise ValueError('Out-of-scope modification: '+name)
                changed.append(name)
            if name.startswith(('Custom/','Visuals/','WorldSetup/','Worlds/')):
                if name in changed:raise ValueError('Game/delivery/asset payload changed: '+name)
                protected.append(name)
    for name in current:
        if name.startswith(('Config/','Backups/','Profiles/')):raise ValueError('Live state packaged')
    py=sorted(ROOT.rglob('*.py'))
    for path in py:ast.parse(path.read_text(encoding='utf-8-sig'),filename=str(path),feature_version=(3,10))
    result={'release':OUTPUT.name,'parent':PARENT,'changed':changed,'unchanged_count':len(unchanged),
            'removed':[],'added':sorted(set(current)-names),'protected_unchanged_count':len(protected),
            'python_files_parse_310':len(py),'native_game_or_windows_execution':False,
            'live_user_state_modified':False,
            'repair_tests':test_count(TASK/'reports/all_repair_tests.log'),
            'retained_checks':test_count(TASK/'reports/retained_regressions.log')}
    if final:
        result['fresh_zip_repair_tests']=test_count(TASK/'reports/fresh_zip_repair_tests.log')
        result['fresh_zip_retained_checks']=test_count(TASK/'reports/fresh_zip_retained_regressions.log')
        if code_assets(ROOT)!=code_assets(TASK/'fresh/Azimuth'):raise ValueError('Code/assets changed after fresh ZIP tests')
        result['fresh_zip_code_assets_match_final']=True
    (TASK/'reports/release_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    (ROOT/'Docs/Audit/Vehicle_Collector_Repair_Verification.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def evidence():
    paths=[TASK/'parent.json',TASK/'build_release.py']
    paths+=sorted((TASK/'Tests').glob('*.py'))
    paths+=[p for p in (TASK/'reports').rglob('*') if p.is_file() and p.suffix in {'.txt','.md','.json','.log'}]
    with zipfile.ZipFile(ROOT/'Docs/Audit/Vehicle_Collector_Repair_Evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        archive.writestr('README.txt','Executed collector correction checks. No native DayZ success is claimed.\n'
                         'Referenced original uploads and game/mod payloads remain separate; raw models and live player state are not bundled.\n')
        for path in paths:
            if path.stat().st_size>4*1024*1024:raise ValueError('Unexpected large report')
            archive.write(path,path.relative_to(TASK).as_posix())
        archive.writestr('qualified_code_assets.json',json.dumps(code_assets(ROOT),indent=2)+'\n')

def build():
    OUTPUT.parent.mkdir(exist_ok=True)
    temporary=OUTPUT.with_suffix('.tmp')
    expected=payload(ROOT)
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name in sorted(expected):archive.write(ROOT/name,'Azimuth/'+name)
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() is not None:raise ValueError('ZIP CRC failure')
        actual={i.filename.removeprefix('Azimuth/'):sha256(archive.read(i)).hexdigest() for i in archive.infolist()}
        if actual!=expected:raise ValueError('Archive does not match qualified source')
    os.replace(temporary,OUTPUT)
    result={'path':str(OUTPUT),'sha256':digest(OUTPUT),'bytes':OUTPUT.stat().st_size,'files':len(expected)}
    (TASK/'release.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--final',action='store_true');args=parser.parse_args()
    validate(args.final);evidence();build()
