from __future__ import annotations
import copy, hashlib, json, os, pathlib, shutil, sys, tempfile, types, unittest, zipfile
from unittest.mock import patch
from xml.etree import ElementTree as ET

WORK = pathlib.Path(__file__).resolve().parents[2]
ROOT = pathlib.Path(os.environ.get('AZIMUTH_TEST_ROOT', WORK / 'complete_repair/package/Azimuth'))
sys.path[:0] = [str(ROOT / 'Engine'), str(WORK / 'vehicle_integration/research/tools')]
from azimuth_app.transport import additional_vehicles as av, avalon_plane_transport as plane
from azimuth_app.transport import vehicle_slot_compat, vehicle_scalar_compat
from config_index import ConfigIndex, load_records
from decode_config import Text

REC = {'source':'repair_test','archive':'compat','prefix':'compat','input_path':'compat','input_sha256':'test'}

def value(node, path):
    for name in path[:-1]:
        node = next(v for k,v in node['classes'].items() if k.lower() == name.lower())
    return next((v for k,v in node['properties'].items() if k.lower() == path[-1].lower()), None)

class ConfigRepairTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records = load_records()
        cls.native = ConfigIndex(cls.records, {'dayz_client'})
        cls.raw = ConfigIndex(cls.records)
        cls.text = vehicle_slot_compat.config_fragment(ROOT, [p['id'] for p in av._catalog()['packs'] if p.get('load')])
        cls.tree = Text(cls.text).decode()['root']
        cls.fixed = ConfigIndex(cls.records + [(REC,cls.tree)])
        cls.data = vehicle_scalar_compat._load(ROOT)

    def test_native_shared_defaults_and_native_wheel_durability_restored(self):
        for row in self.data['shared_defaults']:
            with self.subTest(row=row):
                self.assertEqual(value(self.fixed.resolve(row['class']),row['path']), row['value'])
        for name in ('CivSedanWheel','HatchbackWheel','Truck_01_Wheel','Motorbike_01_Wheel_1'):
            self.assertEqual(value(self.fixed.resolve(name),['DamageSystem','GlobalHealth','Health','hitpoints']),
                             value(self.native.resolve(name),['DamageSystem','GlobalHealth','Health','hitpoints']))

    def test_each_publisher_local_scalar_retains_own_archive_value(self):
        native_records = [r for r in self.records if r[0]['source'] == 'dayz_client']
        cache = {}
        for row in self.data['publisher_local_defaults']:
            if row['source_config'] not in cache:
                source = next(r for r in self.records if r[0]['input_path'] == row['source_config'])
                self.assertEqual(source[0]['input_sha256'],row['source_sha256'])
                cache[row['source_config']] = ConfigIndex(native_records+[source])
            expected = value(cache[row['source_config']].resolve(row['class']),row['path'])
            self.assertEqual(row['value'],expected)
            self.assertEqual(value(self.fixed.resolve(row['class']),row['path']),expected)

    def test_scalar_repair_is_independent_of_publisher_archive_order(self):
        native = [r for r in self.records if r[0]['source']=='dayz_client']
        publisher = [r for r in self.records if r[0]['source']!='dayz_client']
        reverse = ConfigIndex(native+list(reversed(publisher))+[(REC,self.tree)])
        for row in self.data['shared_defaults']+self.data['publisher_local_defaults']:
            self.assertEqual(value(reverse.resolve(row['class']),row['path']),row['value'])

    def test_every_generated_dependency_is_in_export_and_no_duplicate_full_classes(self):
        known = {n.lower() for n in self.raw.section('CfgPatches')}
        for patch_node in self.tree['classes']['CfgPatches']['classes'].values():
            for dependency in patch_node['properties']['requiredAddons']:
                self.assertIn(dependency.lower(),known)
        names = [e['name'].lower() for e in self.tree['classes']['CfgVehicles']['entries'] if e['kind']=='class']
        self.assertEqual(len(names),len(set(names)))

    def test_exact_green_kamaz_panels_match_body_texture_and_gokart_is_unchanged(self):
        cat=av._catalog();pack=next(p for p in cat['packs'] if p['id']=='3387855369')
        truck=next(v for v in pack['vehicles'] if v['class']=='Kamaz_TyphoonK_Green')
        replacements=json.loads((WORK/'full_audit/transport/palette_probe.json').read_text())['texture_grounded']
        body=set(value(self.raw.resolve(truck['class']),['hiddenSelectionsTextures']))-{''}
        for row in replacements:
            chosen=next(a['class'] for a in truck['attachments'] if a['slot']==row['slot'])
            self.assertEqual(chosen,row['matching_unsuffixed_part'])
            self.assertTrue(body & set(value(self.raw.resolve(chosen),['hiddenSelectionsTextures'])))
        old=json.loads((WORK/'vehicle_integration/fresh/Azimuth/Custom/Transport/Workshop/catalog.json').read_text())
        self.assertEqual(next(p for p in cat['packs'] if p['id']=='3456445155'),next(p for p in old['packs'] if p['id']=='3456445155'))

    def test_cybertruck_redirects_only_missing_materials_and_preserves_damage_thresholds(self):
        manifest=json.loads((WORK/'vehicle_integration/evidence/Vehicle_Wrap_Evidence.json').read_text())
        archive=next(a for a in manifest['archives'] if a['archive']=='Van_Cybertruck.pbo')
        assets={('van_cybertruck/'+m['path'].replace('\\','/')).lower() for m in archive['members']}
        for zone in ('Windowfront','Windowrear','Windowleft','Windowright'):
            path=['DamageSystem','DamageZones',zone,'Health','healthLevels']
            before=value(self.raw.resolve('Van_Cybertruck'),path);after=value(self.fixed.resolve('Van_Cybertruck'),path)
            self.assertEqual([r[0] for r in before],[r[0] for r in after])
            self.assertEqual(after[-1][1],'hidden')
            for _,mats in after:
                if isinstance(mats,list):
                    for material in mats:self.assertIn(material.replace('\\','/').lower(),assets)

    def test_airship_exact_author_assembly_and_remote_only(self):
        pack=next(p for p in av._catalog()['packs'] if p['id']=='3810689113')
        self.assertEqual([v['class'] for v in pack['vehicles']],['Airship'])
        self.assertEqual(pack['vehicles'][0]['assembly'],'publisher_on_spawn')
        self.assertEqual(av._spawnable(pack['vehicles'][0]).findall('attachments'),[])
        self.assertEqual([p['class'] for p in pack['support_items']],['AirshipRemote'])
        self.assertNotIn('AirshipRemoteAdmin',json.dumps(pack))

class ActualPublisherTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.base=pathlib.Path(self.temp.name)
        self.mission=self.base/'mission';self.profiles=self.base/'profiles';self.profiles.mkdir()
        prefix='Worlds/avalon/World/Mission/metro.Avalon/'
        with zipfile.ZipFile(WORK/'vehicle_coverage/input/Worlds.zip') as z:
            for name in z.namelist():
                if name.startswith(prefix) and not name.endswith('/'):
                    p=self.mission/name[len(prefix):];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
        self.publisher=WORK/'vehicle_integration/evidence/publisher/workshop_3834034916_library_1'

    def test_actual_an2_publisher_configures_and_is_idempotent_without_save_edits(self):
        saved=self.mission/'storage_1/test-preserve.bin';saved.parent.mkdir(exist_ok=True);saved.write_bytes(b'owned aircraft and players')
        messages=plane.prepare(self.mission,self.profiles,{plane.WORKSHOP_ID:self.publisher})
        self.assertIn('configured from installed publisher XML',messages[0])
        output=self.mission/'azimuth_workshop/an2_plane/types.xml';root=ET.parse(output).getroot()
        self.assertEqual(len(root),7)
        for node in root:
            if node.get('name').lower() in plane.PERSISTENT_DOORS:
                self.assertEqual(node.findtext('nominal'),'0');self.assertEqual(node.findall('usage'),[])
        report=json.loads((self.profiles/plane.REPORT).read_text())
        self.assertEqual(report['ordinary_spare_parts'],['an2_tailwheel','an2_wheel'])
        before={str(p):p.read_bytes() for p in self.mission.rglob('*') if p.is_file()}
        plane.prepare(self.mission,self.profiles,{plane.WORKSHOP_ID:self.publisher})
        self.assertEqual(before,{str(p):p.read_bytes() for p in self.mission.rglob('*') if p.is_file()})
        self.assertEqual(saved.read_bytes(),b'owned aircraft and players')

    def test_unknown_an2_part_is_still_rejected(self):
        copy_dir=self.base/'publisher';shutil.copytree(self.publisher,copy_dir)
        path=copy_dir/'ServerFiles/an2_ce/cfgspawnabletypes.xml';root=ET.parse(path).getroot()
        ET.SubElement(ET.SubElement(root.find('type'),'attachments',chance='1.00'),'item',name='An2_UnknownDoor',chance='1.00')
        path.write_bytes(ET.tostring(root))
        with self.assertRaisesRegex(ValueError,'unknown.*no verified'):
            plane._publisher_data(copy_dir)

    def test_survey_import_uses_distinct_sites_preserves_dedicated_positions(self):
        fake=types.ModuleType('azimuth_app.transport.transport_survey')
        fake.validated_sites=lambda m,p:{'large_water':[ET.Element('pos',x='18000',z='5000',y='0',a='0')],
                                       'airship':[ET.Element('pos',x='18000',z='10000',y='20',a='90')],
                                       'air':[ET.Element('pos',x='15000',z='10000',y='20',a='0')]}
        with patch.dict(sys.modules,{'azimuth_app.transport.transport_survey':fake}):
            _,out,pools,_=av._positions(self.mission,{'large_water','airship','air'},self.profiles)
        self.assertEqual(len(pools['air']),1)
        self.assertEqual(pools['air'][0].get('x'),'15000')
        for route in ('large_water','airship'):
            self.assertIsNotNone(out.find(f"event[@name='{av.EVENTS[route]}']/pos"))
        path=self.mission/'cfgeventspawns.xml';root=ET.parse(path).getroot()
        event=ET.SubElement(root,'event',name=av.EVENTS['large_water']);ET.SubElement(event,'pos',x='19000',z='6000',a='12')
        path.write_bytes(ET.tostring(root))
        with patch.dict(sys.modules,{'azimuth_app.transport.transport_survey':fake}):
            _,_,pools,_=av._positions(self.mission,{'large_water'},self.profiles)
        self.assertEqual(pools['large_water'][0].attrib,{'x':'19000','z':'6000','a':'12'})

    def test_without_survey_new_helicopters_do_not_share_expansion_pads(self):
        _,_,pools,notices=av._positions(self.mission,{'air'},self.profiles)
        self.assertEqual(pools['air'],[])
        self.assertTrue(any('no suitable authored Avalon placement' in n for n in notices))

    def test_surveyed_additional_routes_publish_idempotently_and_preserve_save(self):
        fake=types.ModuleType('azimuth_app.transport.transport_survey')
        fake.validated_sites=lambda m,p:{'large_water':[ET.Element('pos',x='18000',z='5000',y='0',a='0')],
                                       'airship':[ET.Element('pos',x='18000',z='10000',y='20',a='90')],
                                       'air':[ET.Element('pos',x='15000',z='10000',y='20',a='0')]}
        mods={}
        for ident in av.READY_IDS:
            p=self.base/'mods'/ident;p.mkdir(parents=True);mods[ident]=p
        saved=self.mission/'storage_1/vehicles.bin';saved.parent.mkdir(exist_ok=True);saved.write_bytes(b'keep previously owned vehicles')
        with patch.dict(sys.modules,{'azimuth_app.transport.transport_survey':fake}):
            av.prepare(self.mission,self.profiles,mods)
            before={str(p):p.read_bytes() for p in self.mission.rglob('*') if p.is_file()}
            av.prepare(self.mission,self.profiles,mods)
        self.assertEqual(before,{str(p):p.read_bytes() for p in self.mission.rglob('*') if p.is_file()})
        report=json.loads((self.profiles/'Azimuth/Additional_Vehicle_Transport_Audit.json').read_text())
        self.assertEqual(len(report['configured_variants']),568)
        self.assertEqual(report['without_natural_placement'],[])
        output=ET.parse(self.mission/av.FOLDER/'types.xml').getroot()
        self.assertIsNotNone(output.find("type[@name='AirshipRemote']"))
        self.assertIsNone(output.find("type[@name='AirshipRemoteAdmin']"))
        self.assertEqual(saved.read_bytes(),b'keep previously owned vehicles')

if __name__=='__main__':unittest.main(verbosity=2)
