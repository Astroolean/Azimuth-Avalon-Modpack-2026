from __future__ import annotations
from hashlib import sha256
import json, os, pathlib, struct, sys, tempfile, unittest
from unittest.mock import patch
from zipfile import ZipFile
ROOT=pathlib.Path(os.environ.get('AZIMUTH_TEST_ROOT', pathlib.Path(__file__).resolve().parents[1]/'package/Azimuth'))
sys.path.insert(0,str(ROOT/'Engine'))
from azimuth_app.checks import vehicle_repair_assets as repair
from azimuth_app.checks import vehicle_wrap_evidence as evidence

def pbo(rows,prefix='testvehicles'):
    header=bytearray(b'\0sreV'+bytes(16)+b'prefix\0'+prefix.encode()+b'\0\0');payload=bytearray()
    for name,data,method,original in rows:
        header.extend(name.encode()+b'\0'+struct.pack('<5I',method,original,0,0,len(data)));payload.extend(data)
    return bytes(header)+bytes(21)+bytes(payload)

class RepairCollectorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.base=pathlib.Path(self.temp.name)
        self.app=self.base/'app';self.app.mkdir();self.mods=self.base/'mods';self.mods.mkdir();self.lm=self.base/'lm';self.lm.mkdir()
        coverage={'schema_version':1,'vehicle_classes':[{'class':'TestCar','scope':2,'model':'testvehicles/body.p3d','status':'no_supported_exterior_selection',
                 'declared_surfaces':[{'configured_texture':'testvehicles/body_co.paa','configured_material':'testvehicles/body.rvmat'}],
                 'origins':[{'source':'workshop_3387855369_library_1'}]},
                 {'class':'Zodiac','scope':2,'model':'testvehicles/zodiac.p3d','status':'mapped_exterior','declared_surfaces':[{'configured_texture':'testvehicles/zodiac_ca.paa'}]}], 'panel_classes':[]}
        for relative,data in [(repair.COVERAGE,coverage),(repair.CATALOG,{'schema_version':1,'packs':[]})]:
            target=self.app/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(data))
        self.source=self.mods/'vehicle.pbo';self.source.write_bytes(pbo([
            ('body.p3d',b'original model',0,0),('body_co.paa',b'original texture',0,0),('body.rvmat',b'original material',0,0),
            ('zodiac.p3d',b'zodiac model',0,0),('zodiac_ca.paa',b'alpha texture',0,0),('config.bin',b'config',0,0),
            ('scripts/4_world/car.c',b'class TestCar {}',0,0),('unrelated.p3d',b'unselected',0,0),
            ('server.cfg',b'no config files',0,0),('keys/private.biprivatekey',b'no keys',0,0)]))
        self.raw=self.lm/'LM_Planes.pbo';self.raw.write_bytes(b'opaque unknown header full original LM container')
        self.discovery=patch.object(evidence,'_discover',return_value=([('workshop_3387855369_library_1',self.mods,False),('workshop_3639695989_library_1',self.lm,False)],[],[]))
        self.discovery.start();self.addCleanup(self.discovery.stop)
    def collect(self):
        target=repair.collect_vehicle_repair_assets(self.app,[])
        with ZipFile(target) as z:return target,json.loads(z.read('Vehicle_Repair_Files.json')),{n:z.read(n) for n in z.namelist()}
    def test_exact_assets_zodiac_scripts_raw_lm_and_hashes_no_private_copy(self):
        before={p:p.read_bytes() for p in (self.source,self.raw)}
        target,report,data=self.collect()
        self.assertEqual(target.parent.parent,self.app/'Docs/Audit/Exports');self.assertLessEqual(target.stat().st_size,repair.MAX_ZIP_BYTES)
        self.assertEqual(report['missing_assets'],[]);self.assertEqual(report['raw_lm']['status'],'copied')
        copied=[r for r in report['files'] if r['status']=='copied']
        for row in copied:self.assertEqual(sha256(data[row['export_path']]).hexdigest(),row['sha256'])
        content=b''.join(data.values())
        self.assertIn(b'alpha texture',content);self.assertIn(b'original model',content);self.assertIn(before[self.raw],content)
        self.assertFalse(any('private' in n or n.endswith('server.cfg') or 'unrelated.p3d' in n for n in data))
        self.assertNotIn(str(self.base),data['Vehicle_Repair_Files.json'].decode())
        self.assertEqual(before,{p:p.read_bytes() for p in before})
    def test_compressed_members_are_not_mislabelled_as_decoded(self):
        self.source.write_bytes(pbo([('body.p3d',b'compressed exact bytes',evidence.CPRS,100)]))
        _,report,data=self.collect();row=next(r for r in report['files'] if r['resource']=='testvehicles/body.p3d')
        self.assertEqual(row['encoding'],'stored_compressed_or_unknown');self.assertTrue(row['export_path'].endswith('.stored'))
        self.assertEqual(data[row['export_path']],b'compressed exact bytes')
    def test_missing_oversized_and_total_budget_entries_are_explicit(self):
        with patch.object(repair,'MAX_RAW_LM_BYTES',3),patch.object(repair,'MAX_ASSET_BYTES',4):
            _,report,_=self.collect()
        self.assertEqual(report['raw_lm']['status'],'over_size_limit')
        self.assertTrue(report['missing_assets']);self.assertTrue(any(r['status']=='over_entry_limit' for r in report['files']))
        with patch.object(repair,'MAX_PAYLOAD_BYTES',1):
            _,report,_=self.collect()
        self.assertEqual(report['raw_lm']['status'],'copied_in_companion')
        self.assertEqual(report['counts']['copied_assets'],0)
        self.assertTrue(all(r['status']=='over_total_limit' for r in report['files'] if r['kind']!='raw_lm'))
    def test_native_scripts_and_irrelevant_mods_are_not_copied(self):
        other=self.base/'other';other.mkdir();(other/'vehicle.pbo').write_bytes(pbo([('body.p3d',b'wrong mod',0,0),('script.c',b'private unrelated',0,0)]))
        with patch.object(evidence,'_discover',return_value=([('dayz_client',self.mods,True),('workshop_2971993210_library_1',other,False)],[],[])):
            _,report,data=self.collect()
        self.assertFalse(any(r['kind']=='script' for r in report['files']))
        self.assertNotIn(b'private unrelated',b''.join(data.values()));self.assertEqual(report['raw_lm']['status'],'source_not_located')
    def test_child_reparse_and_output_redirect_are_rejected(self):
        outside=self.base/'outside';outside.mkdir();other=outside/'other.pbo';other.write_bytes(self.source.read_bytes());self.source.unlink()
        try:self.source.symlink_to(other)
        except OSError:self.skipTest('symlinks unavailable')
        _,report,_=self.collect();self.assertIn('testvehicles/body.p3d',report['missing_assets'])
        output=self.app/'Docs/Audit/Exports'
        import shutil
        for p in output.iterdir():shutil.rmtree(p)
        output.rmdir();output.symlink_to(outside,target_is_directory=True)
        with self.assertRaises(ValueError):self.collect()
    def test_changed_source_aborts_and_cleans_temporary_zip(self):
        real=repair._copy_payload;changed=False
        def change(archive,item):
            nonlocal changed
            if not changed:
                changed=True;item.path.write_bytes(item.path.read_bytes()+b'changed')
            return real(archive,item)
        with patch.object(repair,'_copy_payload',side_effect=change):
            with self.assertRaisesRegex(ValueError,'changed'):self.collect()
        self.assertEqual(list((self.app/'Docs/Audit/Exports').iterdir()),[])
    def test_final_zip_limit_never_leaves_an_over_limit_output(self):
        with patch.object(repair,'MAX_ZIP_BYTES',100):
            with self.assertRaisesRegex(ValueError,'500 MiB'):self.collect()
        self.assertEqual(list((self.app/'Docs/Audit/Exports').iterdir()),[])
    def test_bad_resource_path_and_malformed_pbo_do_not_escape(self):
        path=self.app/repair.COVERAGE;data=json.loads(path.read_text());data['vehicle_classes'][0]['model']='../private.p3d';path.write_text(json.dumps(data))
        with self.assertRaises(ValueError):self.collect()
        data['vehicle_classes'][0]['model']='testvehicles/body.p3d';path.write_text(json.dumps(data));self.source.write_bytes(b'bad header')
        _,report,_=self.collect();self.assertTrue(any(r['status']=='could_not_inspect' for r in report['archives']))
        self.assertIn('testvehicles/body.p3d',report['missing_assets'])

if __name__=='__main__':unittest.main(verbosity=2)
