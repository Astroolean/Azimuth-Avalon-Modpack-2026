"""Extract actual native survey predicates into a fake-engine C++ adapter.

No native DayZ compilation/terrain/geometry claim. Tests cover production
control flow and the exact collision bounds sent to the engine.
"""
from pathlib import Path
import os
import re
import subprocess
import tempfile
import unittest

TASK = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('AZIMUTH_TEST_ROOT', TASK / 'package/Azimuth')).resolve()
SOURCE = ROOT / 'WorldSetup/avalon/AzimuthTransportSurvey/scripts/5_mission/azimuth_transport_survey.c'


def method(text, name):
    match = re.search(r'    static (?:bool|AzimuthSurveyPoint) ' + name + r'\([^\n]+\)\s*\{', text)
    end, depth = match.end(), 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[match.start():end]


def translate(text):
    text = text.replace('static AzimuthSurveyPoint Inspect(', 'static AzimuthSurveyPoint* Inspect(')
    text = text.replace('AzimuthSurveyCandidate candidate', 'AzimuthSurveyCandidate* candidate')
    text = text.replace('AzimuthSurveyPoint accepted', 'AzimuthSurveyPoint* accepted')
    text = text.replace('array<ref AzimuthSurveyPoint> points', 'Array<AzimuthSurveyPoint*>* points')
    text = text.replace('foreach (AzimuthSurveyPoint point : points)', 'for (auto point : points->values)')
    text = text.replace('foreach (AzimuthSurveyCandidate other : s_Request.excluded)', 'for (auto other : s_Request->excluded->values)')
    text = text.replace('foreach (Man player : people)', 'for (auto player : people->values)')
    for cls in ('Object', 'Man'):
        text = text.replace('ref array<' + cls + '>', 'Array<' + cls + '>*').replace('new array<' + cls + '>', 'new Array<' + cls + '>')
    text = text.replace('GetGame().', 'GetGame()->').replace('Math.', 'Math::')
    for variable in ('candidate', 's_Request', 's_Result', 'point', 'other', 'accepted', 'player'):
        text = text.replace(variable + '.', variable + '->')
    text = re.sub(r'\bnull\b', 'nullptr', text)
    return text


class NativeSurveyReviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temp.cleanup)
        path = Path(cls.temp.name)
        source = SOURCE.read_text()
        cpp = path/'survey.cpp'
        cpp.write_text(ADAPTER + '\n'.join(translate(method(source, n)) for n in ('Finite','Distant','Separated','Inspect')) + MAIN)
        cls.binary = path/'survey'
        result = subprocess.run(['g++','-std=c++17','-O0','-fsanitize=undefined','-fno-sanitize-recover=all',str(cpp),'-o',str(cls.binary)],capture_output=True,text=True)
        if result.returncode:
            raise AssertionError(result.stderr)

    def test_actual_inspect_accepts_rejects_and_queries_full_vertical_footprint(self):
        result = subprocess.run([str(self.binary)],capture_output=True,text=True)
        self.assertEqual(0, result.returncode, result.stdout+result.stderr)

    def test_primary_api_contract_and_no_object_mutations(self):
        text = SOURCE.read_text()
        game = (TASK/'reference/game.c').read_text(encoding='utf-8-sig')
        world = (TASK/'reference/world.c').read_text(encoding='cp1252')
        self.assertRegex(world, r'proto\s+int\s+GetWorldSize\(\)')
        for name in ('SurfaceY','SurfaceIsHole','SurfaceIsSea','SurfaceIsPond','SurfaceGetNormal',
                     'SurfaceGetSeaLevel','SurfaceGetSeaLevelMin','IsBoxCollidingGeometry','GetPlayers'):
            self.assertRegex(game, r'\b'+name+r'\s*\(')
        stripped = re.sub(r'//[^\n]*', '', text)
        self.assertNotRegex(stripped, r'\b(?:CreateObject(?:Ex)?|ObjectDelete|SetPosition|SetOrientation|DeleteSafe|SetHealth01|CreateAttachment(?:Ex)?)\s*\(')


ADAPTER=r'''
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
using string=std::string;
struct vector{float d[3]={0,0,0};vector()=default;vector(float x,float y,float z):d{x,y,z}{}float&operator[](int i){return d[i];}};
vector Vector(float x,float y,float z){return vector(x,y,z);}
namespace Math{float AbsFloat(float n){return std::abs(n);}float Min(float a,float b){return std::min(a,b);}float Max(float a,float b){return std::max(a,b);}}
template<class T>struct Array{std::vector<T>values;int Count(){return int(values.size());}};
using Object=void*;
struct Player{vector pos;vector GetPosition(){return pos;}};using Man=Player*;
struct AzimuthSurveyCandidate{string route="air";float x=1000,z=1000,a=45;};
struct AzimuthSurveyPoint{float x=0,y=0,z=0,a=0;string surface;float footprint_radius_m=0;int sample_count=0;float min_depth_m=0,max_height_delta_m=0,obstacle_clearance_m=0;};
struct Request{Array<AzimuthSurveyCandidate*>*excluded=new Array<AzimuthSurveyCandidate*>;};
struct Result{float world_size=10000;Array<AzimuthSurveyPoint*>*large_water=new Array<AzimuthSurveyPoint*>;Array<AzimuthSurveyPoint*>*airship=new Array<AzimuthSurveyPoint*>;Array<AzimuthSurveyPoint*>*air=new Array<AzimuthSurveyPoint*>;};
constexpr int ObjIntersectGeom=0;
struct Game{
 bool sea=false,pond=false,hole=false,slope=false,uneven=false,obstacle=false,lowRock=false,landEdge=false;
 float ground=0,seaLevel=0,minSea=0;int samples=0,boxes=0;vector center,size;
 std::vector<Man> people;
 float minX=100000,maxX=-100000,minZ=100000,maxZ=-100000;
 float SurfaceY(float x,float z){samples++;minX=std::min(minX,x);maxX=std::max(maxX,x);minZ=std::min(minZ,z);maxZ=std::max(maxZ,z);return ground+(uneven&&x>1000?0.5f:0);}
 bool SurfaceIsHole(float x,float z){return hole&&x>=1030&&z>=1030;}
 bool SurfaceIsSea(float x,float z){return sea&&!(landEdge&&x>=1100&&z>=1100);}
 bool SurfaceIsPond(float,float){return pond;}
 vector SurfaceGetNormal(float,float){return Vector(0,slope?0.994f:1,0);}
 float SurfaceGetSeaLevel(){return seaLevel;}float SurfaceGetSeaLevelMin(){return minSea;}
 bool IsBoxCollidingGeometry(vector c,const char*,vector s,int,int,Array<Object>*,Array<Object>*){boxes++;center=c;size=s;return obstacle||(lowRock&&c[1]-s[1]/2<=0.3f&&c[1]+s[1]/2>=0.3f);}
 void GetPlayers(Array<Man>* out){out->values=people;}
}game;
Game* GetGame(){return &game;}
void require(bool v,const char* why){if(!v)throw std::runtime_error(why);}
struct AzimuthTransportSurvey{
static inline Request* s_Request=new Request;
static inline Result* s_Result=new Result;
'''
MAIN=r'''
};
void reset(){game=Game();AzimuthTransportSurvey::s_Request->excluded->values.clear();AzimuthTransportSurvey::s_Result->large_water->values.clear();AzimuthTransportSurvey::s_Result->airship->values.clear();AzimuthTransportSurvey::s_Result->air->values.clear();}
int main(){try{
AzimuthSurveyCandidate c;
reset();auto p=AzimuthTransportSurvey::Inspect(&c);require(p&&p->surface=="land"&&p->sample_count==81&&game.samples==81,"Flat land rejected or not fully sampled");require(game.minX==970&&game.maxX==1030&&game.minZ==970&&game.maxZ==1030,"Land boundary samples missing");require(game.size[0]==60&&game.size[2]==60&&game.center[1]-game.size[1]/2<=-0.19f,"Land collision volume does not cover lower edge");
reset();game.uneven=true;game.lowRock=true;require(!AzimuthTransportSurvey::Inspect(&c),"Low rock below highest terrain escaped collision box");require(game.center[1]-game.size[1]/2<=-0.19f&&game.center[1]+game.size[1]/2>=50.49f,"Uneven footprint lost bottom or top clearance");
reset();game.hole=true;require(!AzimuthTransportSurvey::Inspect(&c)&&game.boxes==0,"Boundary terrain hole accepted");
reset();game.slope=true;require(!AzimuthTransportSurvey::Inspect(&c),"Excess slope accepted");
reset();game.pond=true;require(!AzimuthTransportSurvey::Inspect(&c),"Pond accepted as aircraft land");
reset();game.obstacle=true;require(!AzimuthTransportSurvey::Inspect(&c),"Geometry collision accepted");
reset();Player near;near.pos=Vector(1049,0,1000);game.people={&near};require(!AzimuthTransportSurvey::Inspect(&c),"Nearby player accepted");
reset();AzimuthSurveyCandidate existing;existing.x=1349;AzimuthTransportSurvey::s_Request->excluded->values={&existing};require(!AzimuthTransportSurvey::Inspect(&c)&&game.samples==0,"350m excluded separation ignored");
reset();AzimuthSurveyPoint prior;prior.x=1000;prior.z=1349;AzimuthTransportSurvey::s_Result->airship->values={&prior};require(!AzimuthTransportSurvey::Inspect(&c)&&game.samples==0,"Cross-route separation ignored");
reset();c.x=30;require(!AzimuthTransportSurvey::Inspect(&c)&&game.samples==0,"Out-of-world footprint accepted");c.x=1000;
reset();c.a=std::numeric_limits<float>::quiet_NaN();require(!AzimuthTransportSurvey::Inspect(&c)&&game.samples==0,"Nonfinite candidate accepted");c.a=45;
reset();c.route="unsupported";require(!AzimuthTransportSurvey::Inspect(&c),"Unknown route accepted");
reset();c.route="airship";p=AzimuthTransportSurvey::Inspect(&c);require(p&&p->footprint_radius_m==40&&p->obstacle_clearance_m==80&&game.size[0]==80,"Airship footprint wrong");
reset();c.route="large_water";game.sea=true;game.ground=-20;game.seaLevel=2;game.minSea=-1;p=AzimuthTransportSurvey::Inspect(&c);require(p&&p->surface=="sea"&&p->min_depth_m==19&&std::abs(p->y-2.3f)<0.001,"Deep sea point incorrect");require(game.minX==900&&game.maxX==1100&&game.minZ==900&&game.maxZ==1100&&game.samples==81&&game.size[0]==200,"Sea footprint bounds wrong");require(game.center[1]-game.size[1]/2==-11&&game.size[1]==100,"Sea collision/draft bounds wrong");
reset();game.sea=true;game.ground=-11;require(!AzimuthTransportSurvey::Inspect(&c),"Shallow sea accepted");
reset();game.sea=true;game.ground=-20;game.landEdge=true;require(!AzimuthTransportSurvey::Inspect(&c),"Land on sea footprint boundary accepted");
reset();game.sea=true;game.ground=-20;game.seaLevel=std::numeric_limits<float>::quiet_NaN();require(!AzimuthTransportSurvey::Inspect(&c),"Nonfinite sea level accepted");
std::cout<<"PASS 17 native survey control-flow/bounds scenarios\n";
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
'''
