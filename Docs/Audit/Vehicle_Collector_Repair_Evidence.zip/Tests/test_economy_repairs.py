"""Regression checks using the supplied actual Avalon mission and publisher bicycle XML.

Run with AZIMUTH_SOURCE_ROOT, AZIMUTH_TEST_WORLDS_ZIP and
AZIMUTH_TEST_BICYCLE_ROOT set to the package and original evidence locations.
No native DayZ runtime is executed; every mutation is inside TemporaryDirectory.
"""
import hashlib
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from xml.etree import ElementTree as ET
from zipfile import ZipFile

ROOT = Path(os.environ.get('AZIMUTH_SOURCE_ROOT', Path(__file__).resolve().parents[1] / 'package/Azimuth'))
sys.path.insert(0, str(ROOT / 'Engine'))
sys.dont_write_bytecode = True
from azimuth_app.economy import avalon_economy_repair as repair, avalon_loot_balance as balance
from azimuth_app.economy.avalon_loot_audit import read_economy, _references, _load_layers, _effective
from azimuth_app.checks.verify_playthrough import inspect_mission
from azimuth_app.transport import avalon_land_transport as land
from azimuth_app.world import avalon_immersion as bikes

ARCHIVE = Path(os.environ.get('AZIMUTH_TEST_WORLDS_ZIP', '/workspace/scratch/5af776953b72/vehicle_coverage/input/Worlds.zip'))
PUBLISHER = Path(os.environ.get('AZIMUTH_TEST_BICYCLE_ROOT', '/workspace/scratch/5af776953b72/vehicle_integration/evidence/publisher/workshop_2971190303_library_1'))
PREFIX = 'Worlds/avalon/World/Mission/metro.Avalon/'


@unittest.skipUnless(ARCHIVE.is_file() and PUBLISHER.is_dir(), 'Actual mission and publisher evidence required')
class EconomyRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='azimuth-economy-regression-')
        cls.folder = Path(cls.tmp.name)
        cls.source = cls.folder / 'source'
        cls.source.mkdir()
        with ZipFile(ARCHIVE) as archive:
            for name in archive.namelist():
                if name.startswith(PREFIX) and not name.endswith('/'):
                    path = cls.source / name[len(PREFIX):]
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(archive.read(name))
        cls.prepared = cls.folder / 'metro.Avalon'
        shutil.copytree(cls.source, cls.prepared)
        cls.profiles = cls.folder / 'Profiles'
        cls.bike = bikes._ce_examples(PUBLISHER, 'bike', tuple(bikes.ROOTS))
        cls.bike['events'] = bikes._bike_events(cls.bike)
        cls.bike['spawnabletypes'] = bikes._bike_spawnables(
            cls.bike, cls.prepared / 'azimuth_workshop/dayz_bicycle/spawnabletypes.xml')
        position = bikes._bike_positions(cls.prepared, cls.bike['events'])
        bikes._register(cls.prepared, 'dayz_bicycle', cls.bike)
        if position:
            position[0].write_bytes(position[1])
        land.prepare(cls.prepared, cls.profiles, {})
        cls.notices = repair.prepare(cls.prepared)
        balance.prepare(cls.prepared, cls.profiles, cls.notices)
        cls.economy = read_economy(cls.prepared)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def clone(self, name):
        target = self.folder / name
        shutil.copytree(self.prepared, target)
        return target

    def test_actual_mission_has_no_configuration_errors_or_unmatched_ordinary_route(self):
        checked = inspect_mission(self.prepared)
        self.assertEqual([], checked['errors'])
        self.assertEqual([], checked['no_static_route_confirmed'])
        self.assertEqual(56, checked['event_checks']['events'])
        self.assertGreater(checked['event_checks']['validated_probability_fields'], 1800)

    def test_bike_migrates_actual_lady_variants_using_retained_rules(self):
        self.assertEqual(8, len(self.bike['spawnabletypes']))
        source = ET.parse(self.source / 'cfgeventspawns.xml').getroot()
        trusted = {'VehicleOffroadHatchback', 'VehicleOffroad02', 'VehicleSedan02'}
        anchors = {(p.get('x'), p.get('z')) for event in source.findall('event')
                   if event.get('name') in trusted for p in event.findall('pos')}
        root = ET.parse(self.prepared / 'cfgeventspawns.xml').getroot()
        points = root.find("event[@name='VehicleHunterz_Old_Bike']").findall('pos')
        self.assertEqual(40, len(points))
        self.assertEqual(40, len({(p.get('x'), p.get('z')) for p in points}))
        self.assertTrue({(p.get('x'), p.get('z')) for p in points} <= anchors)
        for classname in ('Lady_Bicycle', 'Lady_Bicycle_Purple'):
            row = self.bike['spawnabletypes'].find(f"type[@name='{classname}']")
            self.assertEqual(['ladybicycle_wheel'] * 2,
                             [n.get('name').casefold() for n in row.findall('attachments/item')])

    def test_bike_fallback_rejects_unverified_attachment(self):
        fresh = bikes._ce_examples(PUBLISHER, 'bike', tuple(bikes.ROOTS))
        fresh['events'] = bikes._bike_events(fresh)
        retained = self.folder / 'bad_bike.xml'
        root = ET.parse(self.source / 'azimuth_workshop/dayz_bicycle/spawnabletypes.xml').getroot()
        root.find("type[@name='Lady_Bicycle']/attachments/item").set('name', 'Invented_Wheel')
        ET.ElementTree(root).write(retained)
        with self.assertRaisesRegex(ValueError, 'complete positive wheel rules'):
            bikes._bike_spawnables(fresh, retained)

    def test_preserves_creator_source_and_supplies(self):
        for name in ('db/types.xml', 'db/events.xml', 'cfgspawnabletypes.xml', 'mapgroupproto.xml', 'mapgrouppos.xml'):
            self.assertEqual((self.source / name).read_bytes(), (self.prepared / name).read_bytes(), name)
        for key, nominal in [('hippack_party', 3), ('svd_wooden', 4), ('punchedcard', 3)]:
            self.assertEqual(nominal, self.economy.types[key].nominal)
        for key in balance.COMMON_AMMO | balance.COMMON_AMMO_BOXES | balance.STANDARD_MAGAZINES:
            self.assertTrue(self.economy.types[key].natural, key)
        self.assertEqual(24, self.economy.types['nailbox'].nominal)
        self.assertEqual(60, self.economy.types['waterbottle'].nominal)

    def test_humvee_overlay_and_zero_population_sources(self):
        warnings, contained = [], []
        refs = _references(self.prepared, set(), warnings, contained)
        events = _load_layers(self.prepared, refs['events'], 'event', warnings)
        event = _effective(events['vehicleoffroad02'], event=True)
        child = event.find('children/child')
        self.assertEqual(('3', '4'), (child.get('min'), child.get('max')))
        self.assertEqual('4', event.findtext('nominal'))
        self.assertNotIn('animal_vulpesvulpes', self.economy.events)
        self.assertNotIn('animal_lepuseuropaeus', self.economy.events)
        self.assertIn('zmbm_ussoldier_officer_convoy', self.economy.events)

    def test_repeat_is_byte_stable(self):
        before = {str(p.relative_to(self.prepared)): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in self.prepared.rglob('*') if p.is_file()}
        notices = repair.prepare(self.prepared)
        balance.prepare(self.prepared, self.profiles, notices)
        after = {str(p.relative_to(self.prepared)): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in self.prepared.rglob('*') if p.is_file()}
        self.assertEqual(before, after)

    def test_checker_catches_missing_motorbike_root(self):
        mission = self.clone('missing-root')
        path = mission / 'cfgeconomycore.xml'; root = ET.parse(path).getroot()
        classes = root.find('classes')
        classes.remove(classes.find("rootclass[@name='MotorbikeScript']"))
        ET.ElementTree(root).write(path)
        self.assertTrue(any('Missing required economy root class MotorbikeScript' in e for e in inspect_mission(mission)['errors']))

    def test_checker_catches_event_numeric_corruption(self):
        mission = self.clone('bad-event')
        path = mission / 'azimuth_transport_land/events.xml'; root = ET.parse(path).getroot()
        root.find("event[@name='VehicleAzimuthMotorbike']/nominal").text = 'NOT_A_NUMBER'
        ET.ElementTree(root).write(path)
        self.assertTrue(any('nominal is not a whole number' in e for e in inspect_mission(mission)['errors']))

    def test_checker_catches_unusable_position_pool(self):
        mission = self.clone('bad-position')
        path = mission / 'cfgeventspawns.xml'; root = ET.parse(path).getroot()
        event = root.find("event[@name='VehicleAzimuthMotorbike']")
        for p in list(event): event.remove(p)
        ET.SubElement(event, 'pos', x='NaN', z='-10', a='Infinity')
        ET.ElementTree(root).write(path)
        errors = inspect_mission(mission)['errors']
        self.assertTrue(any('invalid coordinate' in e for e in errors))
        self.assertTrue(any('VehicleAzimuthMotorbike: active fixed vehicle event has no valid position' in e for e in errors))

    def test_checker_catches_invalid_probability(self):
        mission = self.clone('bad-probability')
        path = mission / 'azimuth_transport_land/spawnabletypes.xml'; root = ET.parse(path).getroot()
        root.find('type/attachments').set('chance', '2')
        ET.ElementTree(root).write(path)
        self.assertTrue(any('invalid attachments chance' in e for e in inspect_mission(mission)['errors']))

    def test_checker_catches_actual_unrepaired_vehicle_bounds(self):
        errors = inspect_mission(self.source)['errors']
        self.assertTrue(any('Event VehicleOffroad02, child Offroad_02: min exceeds max' in e for e in errors))


if __name__ == '__main__':
    unittest.main(verbosity=2)
