"""Lifecycle regressions use isolated files and mocked process boundaries only."""
import json
from contextlib import ExitStack
import os
import socket
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
from zipfile import ZipFile

sys.dont_write_bytecode = True
SOURCE = Path(os.environ.get('AZIMUTH_TEST_ROOT', str(Path(__file__).resolve().parents[1] / 'package/Azimuth')))
sys.path.insert(0, str(SOURCE / 'Engine'))
from azimuth_app.core.server import Server
from azimuth_app.core import server as server_module
from azimuth_app.core import azimuth as controller_module
from azimuth_app.core.azimuth import Azimuth, SWITCH_START_TIMEOUT
from azimuth_app.core.backups import validate_archive, write_backup, latest_backup
from azimuth_app.ui.dashboard_operations import verify_backup, restore_backup


class LifecycleRepair(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.server = Server(self.root)
        self.manager = Azimuth(self.server)

    def world(self):
        mission = self.server.world / 'Mission/dayzOffline.avalon'
        (mission / 'db').mkdir(parents=True, exist_ok=True)
        (mission / 'init.c').write_text('void main() {}')
        (mission / 'db/types.xml').write_text('<types />')
        (self.server.world / 'Saves').mkdir(exist_ok=True)
        (self.server.world / 'Saves/players.db').write_bytes(b'save-A')
        (self.server.profiles / 'receipt.json').write_text('{"receipt":"A"}')
        return mission

    def launch_baseline(self):
        self.server._launch_reports = self.server._report_signatures()
        self.server._save_launch_provenance()

    def process(self):
        process = SimpleNamespace(pid=123, returncode=None)
        process.poll = lambda: process.returncode
        self.server.process = process
        return process

    def snapshot(self):
        return write_backup(self.server.world_paths.root, time.time() - 10, manager_root=self.root)

    def test_old_clean_report_remains_rejected_after_reopen(self):
        (self.server.profiles / 'old.RPT').write_text('termination successfully completed')
        self.launch_baseline()
        self.assertFalse(self.server._backup_clean_exit())
        reopened = Server(self.root)
        self.assertFalse(reopened._backup_clean_exit())

    def test_new_clean_report_survives_reopen(self):
        self.launch_baseline()
        (self.server.profiles / 'new.RPT').write_text('termination successfully completed')
        self.assertTrue(Server(self.root)._backup_clean_exit())

    def test_activity_does_not_relabel_previous_launch_log(self):
        report = self.server.profiles / 'reused.RPT'
        report.write_text('old startup error\ntermination successfully completed\n')
        self.launch_baseline()
        self.assertEqual(len(self.server.recent_logs()),1)
        self.assertIn('No new report',self.server.recent_logs()[0])
        with report.open('a') as stream:
            stream.write('new run is starting\n')
        self.assertEqual(self.server.recent_logs(),['new run is starting'])

    def test_legacy_or_invalid_provenance_fails_closed(self):
        (self.server.profiles / 'old.RPT').write_text('termination successfully completed')
        self.assertFalse(Server(self.root)._backup_clean_exit())
        self.server._launch_state_path.write_text('{"version":1,"kind":"launch","reports":[["../old.RPT",1,2]]}')
        self.assertFalse(Server(self.root)._backup_clean_exit())

    def test_stop_waits_for_clean_archive_while_manager_is_disabled(self):
        self.world()
        self.launch_baseline()
        process = self.process()
        def stopped():
            process.returncode = 0
            (self.server.profiles / 'current.RPT').write_text('termination successfully completed')
            return True
        self.manager.enabled = True
        with patch.object(self.server, 'stop', side_effect=stopped), patch.object(self.server, 'start') as start:
            self.manager.disable()
            self.assertFalse(self.manager.enabled)
            self.assertTrue(self.server.backing_up)
            self.manager.tick()
            self.assertFalse(self.server.backing_up)
            self.assertIsNotNone(latest_backup(self.server.world_paths.root))
            start.assert_not_called()

    def test_stop_archive_rejects_unclean_exit(self):
        self.world()
        self.launch_baseline()
        process = self.process()
        def stopped():
            process.returncode = 1
            (self.server.profiles / 'current.RPT').write_text('error')
            return True
        with patch.object(self.server, 'stop', side_effect=stopped):
            self.manager.disable()
            self.manager.tick()
        self.assertIsNone(latest_backup(self.server.world_paths.root))
        self.assertEqual(self.server._backup_state, 'Backup delayed')

    def test_scheduled_backup_restarts_but_final_stop_does_not(self):
        self.world()
        self.launch_baseline()
        process = self.process()
        self.server._backup_due = time.time() - 1
        self.server._backup_idle_since = time.monotonic() - 61
        def stopped():
            process.returncode = 0
            (self.server.profiles / 'current.RPT').write_text('termination successfully completed')
            return True
        with patch.object(self.server, 'stop', side_effect=stopped), patch.object(self.server, 'start') as start:
            self.server.backup_tick({'state':'online','players':0})
            self.server.backup_tick({'state':'stopped'})
            self.assertEqual(start.call_count, 1)
            self.assertIsNotNone(latest_backup(self.server.world_paths.root))

    def test_backup_failure_does_not_loop_restart(self):
        self.process()
        with patch.object(self.server, 'stop', side_effect=RuntimeError('cannot stop')):
            with self.assertRaisesRegex(RuntimeError, 'cannot stop'):
                self.manager.disable()
        self.assertFalse(self.manager.enabled)
        self.assertFalse(self.server.backing_up)

    def test_latest_skips_corrupt_and_future_archives(self):
        self.world()
        good = self.snapshot()
        bad = self.server.backups_dir / 'FreeDayZ_Backup_20300101T000000.000000Z.zip'
        bad.write_bytes(b'')
        with ZipFile(self.server.backups_dir / 'FreeDayZ_Backup_29990101T000000.000000Z.zip','w') as z:
            with ZipFile(good) as original:
                for row in original.infolist():
                    z.writestr(row, original.read(row))
        self.assertEqual(latest_backup(self.server.world_paths.root), good)
        self.assertEqual(Server(self.root)._backup_last, good and __import__('azimuth_app.core.backups',fromlist=['backup_time']).backup_time(good))

    def bad_archive(self, members):
        target = self.server.backups_dir / 'FreeDayZ_Backup_20260101T000000.000000Z.zip'
        with ZipFile(target,'w') as archive:
            for name, content in members:
                archive.writestr(name, content)
        return target

    def test_verify_rejects_fake_mission_and_device_name(self):
        bad = self.bad_archive([('World/Mission/not-a-mission.txt',''),('World/Saves/NUL','')])
        with self.assertRaises(ValueError):
            verify_backup(self.server.world_paths.root, bad)

    def test_verify_rejects_wrong_world(self):
        self.world()
        archive = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'different world'):
            verify_backup(self.server.world_paths.root, archive, world_id='livonia')

    def test_verify_rejects_invalid_xml_and_empty_saves(self):
        for xml, save in (('<broken>','save'),('<types/>','')):
            with self.subTest(xml=xml, save=save):
                archive = self.bad_archive([('World/Mission/dayzOffline.avalon/init.c','void main() {}'),('World/Mission/dayzOffline.avalon/db/types.xml',xml),('World/Saves/players.db',save)])
                with self.assertRaises(ValueError):
                    validate_archive(archive)

    def test_verify_rejects_path_conflicts(self):
        archive = self.bad_archive([('World/Mission/dayzOffline.avalon/init.c','void main() {}'),('World/Mission/dayzOffline.avalon/db/types.xml','<types/>'),('World/Saves/save','x'),('World/Saves/save/child','x')])
        with self.assertRaisesRegex(ValueError,'conflicting'):
            validate_archive(archive)

    def test_restore_replaces_world_receipts_and_skin_choices_preserves_connection(self):
        self.world()
        skins = self.root / 'Config/GunSkins/settings.json'
        skins.parent.mkdir(parents=True)
        skins.write_text('{"choice":"A"}')
        archive = self.snapshot()
        (self.server.world / 'Saves/players.db').write_bytes(b'save-B')
        (self.server.profiles / 'receipt.json').write_text('{"receipt":"B"}')
        skins.write_text('{"choice":"B"}')
        self.server.update_settings({'password':'current-password'})
        with patch('azimuth_app.ui.dashboard_operations.ensure_client_closed'):
            safety = restore_backup(self.manager, archive)
        self.assertTrue(safety.is_file())
        self.assertEqual((self.server.world / 'Saves/players.db').read_bytes(), b'save-A')
        self.assertEqual(json.loads((self.server.profiles / 'receipt.json').read_text()), {'receipt':'A'})
        self.assertEqual(json.loads(skins.read_text()), {'choice':'A'})
        self.assertEqual(self.server.settings['password'], 'current-password')
        self.assertTrue(Server(self.root)._backup_clean_exit())
        self.assertFalse(self.manager.enabled)
        self.assertIsNone(self.server.process)
        self.assertTrue(list(self.server.backups_dir.glob('BeforeRestore-*')))

    def test_restore_rolls_back_all_swaps_after_injected_failure(self):
        self.world()
        archive = self.snapshot()
        (self.server.world / 'Saves/players.db').write_bytes(b'current-B')
        (self.server.profiles / 'receipt.json').write_text('{"receipt":"B"}')
        real = os.replace
        failed = False
        def replace(source, target):
            nonlocal failed
            if not failed and str(source).endswith('/data/Profiles'):
                failed = True
                raise OSError('injected publication failure')
            return real(source, target)
        with patch('azimuth_app.ui.dashboard_operations.ensure_client_closed'), patch('azimuth_app.ui.dashboard_operations.os.replace', side_effect=replace):
            with self.assertRaisesRegex(OSError,'injected'):
                restore_backup(self.manager, archive)
        self.assertEqual((self.server.world / 'Saves/players.db').read_bytes(), b'current-B')
        self.assertEqual(json.loads((self.server.profiles / 'receipt.json').read_text()), {'receipt':'B'})
        self.assertFalse(self.server.backing_up)

    def test_restore_rejects_live_server_before_mutation(self):
        self.world()
        archive = self.snapshot()
        self.process()
        with self.assertRaisesRegex(RuntimeError,'Stop and pause'):
            restore_backup(self.manager, archive)
        self.assertEqual((self.server.world / 'Saves/players.db').read_bytes(),b'save-A')

    def test_restore_rejects_external_udp_listener_without_owned_process(self):
        self.world()
        archive = self.snapshot()
        (self.server.world / 'Saves/players.db').write_bytes(b'current-B')
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as listener:
            listener.bind(('127.0.0.1',0))
            port = listener.getsockname()[1]
            if port > 65533:
                self.skipTest('ephemeral port cannot be a DayZ base port')
            self.server.update_settings({'game_port':port})
            with patch('azimuth_app.ui.dashboard_operations.ensure_client_closed'):
                with self.assertRaisesRegex(RuntimeError,'is in use'):
                    restore_backup(self.manager,archive)
        self.assertEqual((self.server.world / 'Saves/players.db').read_bytes(),b'current-B')
        self.assertFalse(self.server.backing_up)
        self.assertFalse(list(self.server.backups_dir.glob('BeforeRestore-*')))

    def test_restore_recovers_after_process_interruption_between_swaps(self):
        self.world()
        archive = self.snapshot()
        (self.server.world / 'Saves/players.db').write_bytes(b'current-B')
        (self.server.profiles / 'receipt.json').write_text('{"receipt":"B"}')
        real = os.replace
        def replace(source, target):
            if str(source).endswith('/data/Profiles'):
                raise KeyboardInterrupt('simulated process interruption')
            return real(source, target)
        with patch('azimuth_app.ui.dashboard_operations.ensure_client_closed'), patch('azimuth_app.ui.dashboard_operations.os.replace', side_effect=replace):
            with self.assertRaises(KeyboardInterrupt):
                restore_backup(self.manager, archive)
        self.assertTrue((self.server.world_paths.config / 'restore-transaction.json').is_file())
        reopened = Server(self.root)
        self.assertEqual((reopened.world / 'Saves/players.db').read_bytes(), b'current-B')
        self.assertEqual(json.loads((reopened.profiles / 'receipt.json').read_text()), {'receipt':'B'})
        self.assertFalse((reopened.world_paths.config / 'restore-transaction.json').exists())
        self.assertTrue(list(reopened.backups_dir.glob('BeforeRestore-*/InterruptedAttempt/World/Saves/players.db')))

    def test_restore_interrupted_before_first_swap_retains_recovery_root(self):
        self.world()
        archive = self.snapshot()
        (self.server.world / 'Saves/players.db').write_bytes(b'current-B')
        real = os.replace
        def replace(source, target):
            if Path(source) == self.server.world:
                raise KeyboardInterrupt('before first swap')
            return real(source, target)
        with patch('azimuth_app.ui.dashboard_operations.ensure_client_closed'), patch('azimuth_app.ui.dashboard_operations.os.replace', side_effect=replace):
            with self.assertRaises(KeyboardInterrupt):
                restore_backup(self.manager, archive)
        journal = self.server.world_paths.config / 'restore-transaction.json'
        state = json.loads(journal.read_text())
        self.assertTrue((self.server.backups_dir / state['originals']).is_dir())
        reopened = Server(self.root)
        self.assertEqual((reopened.world / 'Saves/players.db').read_bytes(),b'current-B')
        self.assertFalse(journal.exists())

    def test_start_is_blocked_by_unrecoverable_restore(self):
        journal = self.server.world_paths.config / 'restore-transaction.json'
        journal.write_text('{"version":1,"phase":"publishing","originals":"BeforeRestore-1","operations":[]}')
        with patch.object(self.server, 'find_installation') as install:
            with self.assertRaisesRegex(RuntimeError,'interrupted restore'):
                self.server.start()
            install.assert_not_called()

    def test_never_online_process_is_gracefully_stopped_and_paused(self):
        self.process()
        self.manager.enabled = True
        self.manager.starting_since = 1
        with patch.object(self.server, 'status', return_value={'state':'starting'}), patch.object(self.server,'stop',return_value=True) as stop, patch('azimuth_app.core.azimuth.time.monotonic',return_value=SWITCH_START_TIMEOUT+2):
            self.manager.tick()
        self.assertFalse(self.manager.enabled)
        stop.assert_called_once()
        self.assertIn('startup timeout',self.manager.play_error)

    def test_previously_online_server_is_not_stopped_for_lost_query(self):
        self.process()
        self.manager.enabled = True
        self.manager.starting_since = 1
        with patch.object(self.server, 'status', return_value={'state':'running'}), patch.object(self.server,'stop') as stop, patch('azimuth_app.core.azimuth.time.monotonic',return_value=SWITCH_START_TIMEOUT+2):
            self.manager.tick()
        self.assertTrue(self.manager.enabled)
        stop.assert_not_called()

    def play_fixture(self, stack):
        self.manager.enabled = True
        self.manager.play_pending = True
        self.manager._play_online_deadline = time.monotonic() + 200
        self.server.loaded_client_mods = (self.root / 'workshop',)
        stack.enter_context(patch.object(controller_module, 'ensure_client_closed'))
        stack.enter_context(patch.object(controller_module, 'find_client', return_value=self.root / 'client'))
        stack.enter_context(patch.object(controller_module, 'require_dayz130', return_value='1.30.1.1'))
        stack.enter_context(patch.object(controller_module, 'require_matching_dayz_versions', return_value=('1.30.1.1','1.30.1.1')))
        stack.enter_context(patch.object(controller_module, 'snapshot_client_reports', return_value={}))
        stack.enter_context(patch.object(self.server, 'find_installation', return_value=self.root / 'installation'))
        stack.enter_context(patch.object(self.server, 'steam_libraries', return_value=[self.root]))
        stack.enter_context(patch.object(self.server, 'status', return_value={'state':'online','players':0}))
        stack.enter_context(patch.object(self.server, 'avalon_pack_restart_needed', return_value=False))
        stack.enter_context(patch.object(self.manager, '_prepare_client_graphics'))
        launched = stack.enter_context(patch.object(controller_module, 'launch_client', return_value=[]))
        restarted = stack.enter_context(patch.object(self.manager, '_restart_updated_avalon'))
        return launched, restarted

    def test_play_waits_for_survey_then_restarts_before_join(self):
        with ExitStack() as stack:
            launched, restarted = self.play_fixture(stack)
            running = stack.enter_context(patch.object(self.server, 'avalon_survey_running', return_value=True))
            pending = stack.enter_context(patch.object(self.server, 'avalon_first_run_pending', return_value=False))
            self.manager._play_tick()
            launched.assert_not_called()
            restarted.assert_not_called()
            self.assertTrue(self.manager.play_pending)
            self.assertEqual(self.manager.message,'Checking Avalon vehicle placement sites')
            running.return_value = False
            pending.return_value = True
            self.manager._play_tick()
            restarted.assert_called_once()
            launched.assert_not_called()
            pending.return_value = False
            self.manager._play_tick()
            launched.assert_called_once()
            self.assertFalse(self.manager.play_pending)

    def test_survey_timeout_continues_without_restart_loop(self):
        with ExitStack() as stack:
            launched, restarted = self.play_fixture(stack)
            stack.enter_context(patch.object(self.server, 'avalon_survey_running', return_value=True))
            stack.enter_context(patch.object(self.server, 'avalon_first_run_pending', return_value=False))
            self.manager._play_survey_deadline = time.monotonic() - 1
            self.manager._play_tick()
            launched.assert_called_once()
            restarted.assert_not_called()
            self.assertFalse(self.manager.play_pending)

    def test_pending_combines_fishing_and_completed_survey(self):
        self.world()
        with patch.object(server_module.avalon_workshop, 'enabled', return_value=True), patch.object(server_module.avalon_workshop, 'fishing_setup_pending', return_value=False), patch.object(server_module.transport_survey, 'setup_pending', return_value=True):
            self.assertTrue(self.server.avalon_first_run_pending())

    def test_survey_mod_is_server_only_and_server_version_captured(self):
        mission = self.world()
        survey = self.root / 'survey'
        process = Mock(pid=42, poll=Mock(return_value=None))
        with ExitStack() as stack:
            for owner, name, value in (
                (self.server,'find_installation',self.root / 'installation'),
                (self.server,'_workshop_folders',[self.root / 'CF',self.root / 'Avalon']),
                (server_module.avalon_workshop,'enabled',True),
                (server_module,'require_dayz130','1.30.1.1'),
                (self.server,'_stage_mission',mission),
                (server_module.avalon_qol,'prepare_logout',None),
                (server_module.transport_survey,'prepare_survey',survey),
                (self.server,'_mod_folders',[]),
                (self.server,'_workshop_file_state',()),
            ):
                stack.enter_context(patch.object(owner,name,return_value=value))
            for owner, name in ((server_module,'ensure_udp_available'),(self.server,'_check_avalon_animation_mods'),(self.server,'_configure_world'),(self.server,'_sync_avalon_pack_keys')):
                stack.enter_context(patch.object(owner,name))
            launched = stack.enter_context(patch.object(server_module.subprocess,'Popen',return_value=process))
            self.server.start()
        command = launched.call_args.args[0]
        self.assertIn('-serverMod=' + str(survey),command)
        self.assertNotIn(survey,self.server.loaded_client_mods)
        self.assertEqual(self.server._loaded_server_version,'1.30.1.1')

if __name__ == '__main__':
    unittest.main(verbosity=2)
