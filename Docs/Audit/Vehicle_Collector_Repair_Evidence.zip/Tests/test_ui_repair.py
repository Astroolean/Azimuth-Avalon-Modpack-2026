"""Headless callback/state regressions; does not claim native Tk rendering."""
import os
from pathlib import Path
from queue import Queue
import sys
from types import MethodType, SimpleNamespace
import unittest
from unittest.mock import Mock, patch

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get('AZIMUTH_TEST_ROOT', Path(__file__).resolve().parents[1] / 'package/Azimuth'))
sys.path.insert(0, str(ROOT / 'Engine'))
from azimuth_app.ui import dashboard as module, dashboard_workshop, dashboard_overview, dashboard_utility, dashboard_skins
from azimuth_app.transport import vehicle_workshop, additional_vehicles


class Widget:
    def __init__(self, **options): self.options=options; self.manager=''; self.drawings=[]
    def configure(self, **options): self.options.update(options)
    def pack(self, **_options): self.manager='pack'
    def pack_forget(self): self.manager=''
    def winfo_manager(self): return self.manager
    def winfo_width(self): return 400
    def delete(self, _tag): self.drawings.clear()
    def create_rectangle(self, *args, **options): self.drawings.append((args,options))


class Var:
    def __init__(self,value):self.value=value
    def get(self):return self.value
    def set(self,value):self.value=value


def workshop_page():
    dashboard=SimpleNamespace(show_notice=Mock(),open_avalon_pack_item=Mock(return_value=True),
                              workshop_status=None,workshop_error=None)
    page=SimpleNamespace(dashboard=dashboard,items=(('CF','1559212036'),('Avalon','3225634444')),
        status=None,opened=set(),busy=False,vehicle_items=vehicle_workshop.ITEMS,
        vehicle_status=None,vehicle_opened=set(),winfo_toplevel=lambda:'window')
    page.rows={identity:(Widget(),Widget()) for _,identity in page.items}
    page.vehicle_rows={identity:(Widget(),Widget()) for identity,_,_ in page.vehicle_items}
    for name in ('refresh_button','vehicle_export_button','vehicle_repair_button','vehicle_next_button','next_button',
                 'enable_button','pack_state','summary','progress','vehicle_summary'):
        setattr(page,name,Widget())
    for name in ('render_status','show_pack_error','_draw_progress','_render_controls','_refreshed',
                 'render_vehicle_status','show_vehicle_error','set_busy','_open_vehicle_item'):
        setattr(page,name,MethodType(getattr(dashboard_workshop.WorkshopPage,name),page))
    return page


def dash():
    d=SimpleNamespace(results=Queue(),busy=False,polling=True,events=[],stop_deadline=0,
        server=SimpleNamespace(events=Queue()),azimuth=SimpleNamespace(play_error='',show_requested=lambda:False),
        last_play_error='',workshop_status=None,workshop_error=None,
        workshop_page=SimpleNamespace(render_status=Mock(),show_pack_error=Mock(),render_vehicle_status=Mock()),
        redact=lambda text:text,refresh=Mock(),render_logs=Mock(),show_notice=Mock(),
        window=SimpleNamespace(after=Mock()),drain_queues=Mock())
    return d


class WorkshopRepairTests(unittest.TestCase):
    def test_manual_failure_invalidates_ready_badges_and_enable_button_then_recovers(self):
        p=workshop_page();ready={'1559212036','3225634444'}
        p.render_status((False,ready));self.assertEqual('pack',p.enable_button.manager)
        p._refreshed(((None,'drive unavailable'),(set(),None)))
        self.assertIsNone(p.status);self.assertIsNone(p.dashboard.workshop_status)
        self.assertEqual('drive unavailable',p.dashboard.workshop_error)
        self.assertEqual('Check failed',p.pack_state.options['text'])
        self.assertTrue(all(row.options['text']=='Check failed' for row,_ in p.rows.values()))
        self.assertEqual('disabled',p.enable_button.options['state'])
        self.assertEqual('',p.enable_button.manager);self.assertEqual([],p.progress.drawings)
        p.set_busy(True);p.set_busy(False)
        self.assertEqual('Check failed',p.pack_state.options['text'])
        p._refreshed((((True,ready),None),(set(),None)))
        self.assertEqual((True,frozenset(ready)),p.dashboard.workshop_status)
        self.assertIsNone(p.dashboard.workshop_error)
        self.assertEqual('All 2 items ready',p.summary.options['text'])

    def test_automatic_failure_clears_overview_state_reports_once_and_recovers(self):
        d=dash();d.workshop_status=(True,{'1559212036'})
        for _ in range(2):
            d.results.put(('workshop',None,None,OSError('read failed')))
        d.results.put(('vehicle_workshop',None,{'3456445155'},None))
        module.Dashboard.drain_queues(d)
        self.assertIsNone(d.workshop_status);self.assertEqual('read failed',d.workshop_error)
        self.assertEqual(1,d.show_notice.call_count)
        d.workshop_page.render_vehicle_status.assert_called_once_with({'3456445155'})
        d.results.put(('workshop',None,(True,{'1559212036'}),None))
        module.Dashboard.drain_queues(d)
        self.assertIsNone(d.workshop_error);self.assertEqual((True,{'1559212036'}),d.workshop_status)

    def test_integrated_links_give_restart_guidance_and_unreadable_pack_stays_distinct(self):
        p=workshop_page()
        for identity in additional_vehicles.READY_IDS:
            self.assertTrue(p._open_vehicle_item(identity))
            notice=p.dashboard.show_notice.call_args.args[0]
            self.assertIn('restart Avalon',notice);self.assertNotIn('upload',notice)
        self.assertTrue(p._open_vehicle_item('3639695989'))
        self.assertIn('not integrated',p.dashboard.show_notice.call_args.args[0])

    def test_overview_clears_old_ready_summary_when_status_is_unknown(self):
        d=SimpleNamespace(status_data={},process_sample=None,cpu_history=[],memory_history=[],
            world_names={'avalon':'Avalon'},server=SimpleNamespace(active_world_id='avalon',settings={}),
            workshop_status=None,workshop_error='read failed',events=[],harbor=SimpleNamespace(render=Mock()),
            cpu_trend=SimpleNamespace(set_data=Mock()),memory_trend=SimpleNamespace(set_data=Mock()))
        for name in ('players_label','cpu_label','memory_label','uptime_label','telemetry_note',
                     'connection_detail','workshop_summary','overview_note'):
            setattr(d,name,Widget())
        dashboard_overview.render_overview(d,'Offline',False)
        self.assertIn('check failed',d.workshop_summary.options['text'])
        d.workshop_error=None
        dashboard_overview.render_overview(d,'Offline',False)
        self.assertEqual('Checking Steam Workshop',d.workshop_summary.options['text'])


class QueueRecoveryTests(unittest.TestCase):
    def test_completion_failure_does_not_lose_later_actions_poll_done_or_timer(self):
        d=dash();d.busy=True;later=Mock()
        d.results.put(('action',Mock(side_effect=OSError('callback failed')),None,None))
        d.results.put(('action',later,'saved',None));d.results.put(('poll_done',None,None,None))
        module.Dashboard.drain_queues(d)
        later.assert_called_once_with('saved');self.assertFalse(d.busy);self.assertFalse(d.polling)
        self.assertIn('callback failed',d.events[0]);d.window.after.assert_called_once_with(250,d.drain_queues)

    def test_renderer_failure_still_renders_activity_and_reschedules(self):
        d=dash();d.refresh.side_effect=ValueError('bad page')
        module.Dashboard.drain_queues(d)
        d.render_logs.assert_called_once();d.window.after.assert_called_once_with(250,d.drain_queues)
        self.assertIn('bad page',d.events[0])

    def test_notice_widget_failure_and_closing_window_do_not_escape(self):
        d=dash();d.show_notice.side_effect=module.tk.TclError('destroyed notice')
        d.window.after.side_effect=module.tk.TclError('destroyed window')
        later=Mock();d.results.put(('action',Mock(side_effect=RuntimeError('callback')),None,None))
        d.results.put(('action',later,None,None))
        module.Dashboard.drain_queues(d)
        later.assert_called_once_with(None)

    def test_action_still_runs_if_refresh_fails_before_worker_start(self):
        d=dash();d.refresh.side_effect=RuntimeError('bad display');command=Mock(return_value='saved')
        class Thread:
            def __init__(self,target,daemon):self.target=target
            def start(self):self.target()
        with patch.object(module.threading,'Thread',Thread):
            module.Dashboard.action(d,'Saving',command,Mock())
        command.assert_called_once();self.assertEqual('saved',d.results.get_nowait()[2])


class VehicleRepairCollectorUiTests(unittest.TestCase):
    def summary(self, **changes):
        result = {'requested_assets': 200, 'copied_assets': 191, 'missing_assets': 9,
                  'partial_scan': False, 'limited_files': 0, 'lm_status': 'copied',
                  'companion_files': []}
        result.update(changes)
        return result

    def context(self):
        p=workshop_page();d=dash()
        d.server.root=Path('/Azimuth');d.server.installation=Path('/Steam/DayZServer')
        d.server.steam_libraries=Mock(return_value=[Path('/Steam')]);d.action=Mock()
        p.dashboard=d
        return p,d

    def test_optional_collection_is_queued_and_opens_only_local_result_folder(self):
        p,d=self.context();output=Path('/Azimuth/Docs/Audit/Exports/repair.zip')
        collector=Mock(return_value=output)
        with patch.dict(sys.modules,{'azimuth_app.checks.vehicle_repair_assets':
                                     SimpleNamespace(collect_vehicle_repair_assets=collector,
                                                     read_collection_summary=Mock(return_value=self.summary()))}), \
             patch.object(dashboard_workshop.os,'startfile',create=True) as startfile:
            dashboard_workshop.WorkshopPage._collect_vehicle_repair_files(p)
            collector.assert_not_called()
            label,command,done=d.action.call_args.args
            self.assertIn('repair files',label);done(command())
            collector.assert_called_once_with(d.server.root,[Path('/Steam')],d.server.installation)
            d.server.steam_libraries.assert_called_once_with(d.server.installation,refresh=True)
            startfile.assert_called_once_with(str(output.parent))
            self.assertIn('Nothing was uploaded',d.show_notice.call_args.args[0])
            self.assertIn('191 of 200',d.show_notice.call_args.args[0])
            self.assertIn('9 were not collected',d.show_notice.call_args.args[0])

    def test_folder_open_failure_keeps_saved_zip_location_visible(self):
        p,d=self.context();output=Path('/Azimuth/Docs/Audit/Exports/repair.zip')
        dashboard_workshop.WorkshopPage._collect_vehicle_repair_files(p)
        with patch.object(dashboard_workshop.os,'startfile',create=True,side_effect=OSError('no shell')):
            d.action.call_args.args[2]((output,self.summary()))
        self.assertIn(str(output.parent),d.show_notice.call_args.args[0])

    def test_collection_failure_clears_busy_and_reports_without_success_or_folder_open(self):
        p,d=self.context();d.action=MethodType(module.Dashboard.action,d)
        collector=Mock(side_effect=ValueError('Linked mod path refused'))
        class Thread:
            def __init__(self,target,daemon):self.target=target
            def start(self):self.target()
        with patch.dict(sys.modules,{'azimuth_app.checks.vehicle_repair_assets':
                                     SimpleNamespace(collect_vehicle_repair_assets=collector,
                                                     read_collection_summary=Mock())}), \
             patch.object(module.threading,'Thread',Thread), \
             patch.object(dashboard_workshop.os,'startfile',create=True) as startfile:
            dashboard_workshop.WorkshopPage._collect_vehicle_repair_files(p)
            module.Dashboard.drain_queues(d)
            startfile.assert_not_called()
        self.assertFalse(d.busy)
        d.show_notice.assert_any_call('Linked mod path refused',error=True)
        self.assertFalse(any('saved:' in call.args[0] for call in d.show_notice.call_args_list))
        d.window.after.assert_called_once()

    def test_scan_limit_and_missing_lm_are_not_reported_as_complete(self):
        p,d=self.context();output=Path('/Azimuth/Docs/Audit/Exports/collection/repair.zip')
        dashboard_workshop.WorkshopPage._collect_vehicle_repair_files(p)
        summary=self.summary(copied_assets=20,missing_assets=180,partial_scan=True,lm_status='not_scanned')
        with patch.object(dashboard_workshop.os,'startfile',create=True):
            d.action.call_args.args[2]((output,summary))
        notice=d.show_notice.call_args.args[0]
        self.assertIn('20 of 200',notice);self.assertIn('could not be fully scanned',notice)
        self.assertIn("LM's Planes could not be fully checked",notice)
        self.assertNotIn('was not located',notice)
        self.assertTrue(d.show_notice.call_args.kwargs['error'])

    def test_companion_output_tells_user_to_send_all_files_in_new_folder(self):
        p,d=self.context();output=Path('/Azimuth/Docs/Audit/Exports/collection/repair.zip')
        dashboard_workshop.WorkshopPage._collect_vehicle_repair_files(p)
        with patch.object(dashboard_workshop.os,'startfile',create=True) as startfile:
            d.action.call_args.args[2]((output,self.summary(companion_files=['LM_Planes.zip'],lm_status='copied_in_companion')))
        startfile.assert_called_once_with(str(output.parent))
        notice=d.show_notice.call_args.args[0]
        self.assertIn('send all 2 together',notice)
        self.assertNotIn('not included in full',notice)

    def test_summary_failure_still_exposes_saved_output(self):
        p,d=self.context();output=Path('/Azimuth/Docs/Audit/Exports/collection/repair.zip')
        with patch.dict(sys.modules,{'azimuth_app.checks.vehicle_repair_assets':
                       SimpleNamespace(collect_vehicle_repair_assets=Mock(return_value=output),
                                       read_collection_summary=Mock(side_effect=ValueError('bad summary')))}):
            dashboard_workshop.WorkshopPage._collect_vehicle_repair_files(p)
            _,command,done=d.action.call_args.args
            with patch.object(dashboard_workshop.os,'startfile',create=True):done(command())
        notice=d.show_notice.call_args.args[0]
        self.assertIn(str(output.parent),notice)
        self.assertIn('summary could not be read',notice)

    def test_size_limit_status_is_specific(self):
        notice,error=dashboard_workshop._repair_collection_notice(
            Path('/exports/repair.zip'),self.summary(lm_status='over_size_limit',limited_files=1))
        self.assertTrue(error);self.assertIn('too large for full collection',notice)
        self.assertIn('1 file exceeded',notice)

    def test_busy_collector_button_and_handler_do_not_queue_duplicate_work(self):
        p,d=self.context();p.set_busy(True)
        self.assertEqual('disabled',p.vehicle_repair_button.options['state'])
        dashboard_workshop.WorkshopPage._collect_vehicle_repair_files(p)
        d.action.assert_not_called()


class RestoreUiTests(unittest.TestCase):
    def context(self):
        d=SimpleNamespace(busy=False,stop_deadline=0,azimuth=SimpleNamespace(enabled=False,play_pending=False),
            server=SimpleNamespace(backing_up=False,active_world_id='avalon'),server_running=lambda:False,
            world_names={'avalon':'Avalon'},show_notice=Mock(),action=Mock(),window='window',
            skins_page=SimpleNamespace(reload_status=Mock()),workshop_page=SimpleNamespace(reset_status=Mock()))
        d.can_restore_backup=MethodType(module.Dashboard.can_restore_backup,d)
        return d

    def test_restore_unavailable_during_server_or_controller_operation(self):
        for owner,key in (('self','busy'),('self','stop_deadline'),('azimuth','enabled'),
                          ('azimuth','play_pending'),('server','backing_up')):
            d=self.context();setattr(d if owner=='self' else getattr(d,owner),key,True)
            with patch.object(module.messagebox,'askyesno') as confirm:
                module.Dashboard.restore_selected_backup(d,Path('/backup.zip'))
            confirm.assert_not_called();d.action.assert_not_called()

    def test_declining_restore_never_queues_mutation(self):
        d=self.context()
        with patch.object(module.messagebox,'askyesno',return_value=False) as confirm:
            module.Dashboard.restore_selected_backup(d,Path('/backup.zip'))
        self.assertIn('saved characters',confirm.call_args.args[1]);d.action.assert_not_called()

    def test_verify_uses_selected_world_identity(self):
        d=self.context();d.server.world_paths=SimpleNamespace(root=Path('/worlds/avalon'))
        archive=Path('/worlds/avalon/Backups/backup.zip')
        with patch.object(module,'verify_backup') as verify:
            module.Dashboard.verify_selected_backup(d,archive)
            d.action.call_args.args[1]()
        verify.assert_called_once_with(d.server.world_paths.root,archive,world_id='avalon')

    def test_confirmed_restore_queues_backend_and_refreshes_affected_views(self):
        d=self.context();archive=Path('/backup.zip');safety=Path('/safety.zip')
        with patch.object(module.messagebox,'askyesno',return_value=True), \
             patch('azimuth_app.ui.dashboard_operations.restore_backup',create=True,return_value=safety) as restore:
            module.Dashboard.restore_selected_backup(d,archive)
            label,command,done=d.action.call_args.args
            self.assertIn('Restoring Avalon',label);restore.assert_not_called()
            done(command());restore.assert_called_once_with(d.azimuth,archive)
        self.assertEqual(0,d.next_backups_poll);self.assertEqual(0,d.next_skins_poll)
        self.assertEqual(0,d.next_workshop_poll);self.assertEqual({},d.status_data)
        d.skins_page.reload_status.assert_called_once();d.workshop_page.reset_status.assert_called_once()
        self.assertIn('safety.zip',d.show_notice.call_args.args[0])

    def test_restore_selection_guard_tracks_controller_without_busy_transition(self):
        d=self.context();p=SimpleNamespace(_busy=False,d=d,verify=Widget(),restore=Widget(),
                                         tree=SimpleNamespace(selection=lambda:('archive',)))
        p._refresh_verify=MethodType(dashboard_utility.BackupsPage._refresh_verify,p)
        dashboard_utility.BackupsPage.set_busy(p,False)
        self.assertEqual('normal',p.restore.options['state'])
        d.azimuth.enabled=True
        dashboard_utility.BackupsPage.set_busy(p,False)
        self.assertEqual('disabled',p.restore.options['state'])


class CosmeticRecoveryUiTests(unittest.TestCase):
    def test_restore_reload_discards_draft_state_and_advances_scan_cutoff(self):
        p=SimpleNamespace(loaded=True,last_observed=1,_render_controls=Mock(),
                          selection_label=Widget(),status_label=Widget())
        with patch.object(dashboard_skins.time,'monotonic',return_value=50):
            dashboard_skins.SkinsPage.reload_status(p)
        self.assertFalse(p.loaded);self.assertEqual(50,p.last_observed)
        p._render_controls.assert_called_once()
        self.assertIn('restored',p.status_label.options['text'])

    def test_deferred_cleanup_message_remains_visible_with_all_finishes_off(self):
        p=SimpleNamespace(loaded=True,locked=False,running=False,skins=[],skin_vars={},checks=[],cards={},
            saved_ids=(),saved_showcase=False,saved_random_enabled=True,saved_random_chance=20,
            saved_vehicle_enabled=True,saved_vehicle_chance=100,saved_vehicle_test_enabled=False,
            kit_var=Var(False),random_enabled_var=Var(True),random_chance_var=Var(20),
            vehicle_enabled_var=Var(True),vehicle_chance_var=Var(100),vehicle_test_var=Var(False),
            cleanup_pending=False,cleanup_deferred=True,kit_status='Cleanup deferred. Use Remove test kit again.',
            vehicle_test_status='Off')
        for name in ('selected_ids','dirty','_render_controls'):
            setattr(p,name,MethodType(getattr(dashboard_skins.SkinsPage,name),p))
        for name in ('select_all_button','clear_button','random_check','vehicle_check','vehicle_test_check',
                     'random_chance','vehicle_chance','vehicle_export_button','kit_check','save_button',
                     'reissue_button','remove_button','selection_label','status_label','random_help',
                     'vehicle_help','vehicle_test_label','kit_label'):
            setattr(p,name,Widget())
        p._render_controls()
        self.assertEqual(p.kit_status,p.kit_label.options['text'])
        self.assertEqual('normal',p.remove_button.options['state'])
        self.assertIn('stay supported',p.status_label.options['text'])


if __name__=='__main__':unittest.main(verbosity=2)
