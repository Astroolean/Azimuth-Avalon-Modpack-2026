"""Historical-class safety and real cleanup control flow; no native DayZ claim."""
from pathlib import Path
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from xml.etree import ElementTree as ET

TASK = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('AZIMUTH_TEST_ROOT', TASK / 'package/Azimuth')).resolve()
sys.path.insert(0, str(ROOT / 'Engine'))
from azimuth_app.cosmetics import azimuth_skins as skins, skin_settings as settings, skin_showcase, random_skin_mode


class CompatibilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = skins.load_catalog(ROOT / 'Custom/GunSkins/catalog.json')
        cls.source = ROOT / 'Custom/GunSkins/azimuthskins'

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        bundle = self.root / 'Custom/GunSkins'
        bundle.mkdir(parents=True)
        shutil.copyfile(ROOT / 'Custom/GunSkins/catalog.json', bundle / 'catalog.json')
        self.mods = self.root / 'Worlds/avalon/Mods'
        self.pack = self.mods / skins.MOD_NAME
        self.profiles = self.root / 'Worlds/avalon/Profiles'
        self.choices = settings.save(self.root, self.catalog, ['neon420', 'deeporbit'], False,
                                     target_steam_id='76561198000000000', vehicle_test_enabled=False)

    def receipt(self, *, weapons=True, chests=True):
        value = {'schema_version': 1, 'target_steam_id': self.choices['target_steam_id'],
                 'delivered_generation': self.choices['test_kit_generation'], 'cleanup_generation': '',
                 'cleanup_pending': False, 'status': 'delivered',
                 'weapons': [{'class_name': 'Azimuth_Showcase_M4A1_Neon420', 'persistent_id': '1:2:3:4',
                              'attachments': []}] if weapons else [],
                 'chests': [{'persistent_id': '5:6:7:8', 'position': [100, 0, 100]}] if chests else []}
        target = self.root / settings.SHOWCASE_RECEIPT_PATH
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(value))
        return target

    def prepare(self):
        captured = []
        def economy(mission, catalog):
            captured.append(catalog)
            return {'types': ('types.xml', b'<types/>')}, ()
        def publish(source, pack, catalog, ids, libraries, root):
            skins.build_pbo(self.source, pack, catalog, ids)
        with patch.object(skins, 'economy_files', side_effect=economy), \
                patch.object(skins, '_publish_signed', side_effect=publish), \
                patch.object(skins, 'register_bytes'):
            result = skins.prepare(self.root, self.mods, self.root / 'Mission', [])
        return result, captured

    def test_receipt_class_survives_partial_and_complete_deselection(self):
        receipt = self.receipt()
        receipt_before = receipt.read_bytes()
        self.choices = settings.save(self.root, self.catalog, ['deeporbit'], False)
        (_, notices), captured = self.prepare()
        self.assertEqual(['neon420', 'deeporbit'], [s['id'] for s in captured[0]['skins']])
        self.assertIn(b'class Azimuth_Showcase_M4A1_Neon420:', (self.pack / 'Addons/azimuthskins.pbo').read_bytes())
        self.assertTrue(notices)
        self.assertEqual(receipt_before, receipt.read_bytes())
        settings.save(self.root, self.catalog, [], False)
        self.prepare()
        self.assertTrue((self.pack / 'Addons/azimuthskins.pbo').is_file())
        self.assertEqual([], settings.applied_ids(self.root, self.catalog))
        self.assertEqual((['neon420', 'deeporbit'], True), settings.retained_classes(self.root, self.catalog))
        self.assertEqual(receipt_before, receipt.read_bytes())

    def test_previous_applied_history_retains_only_proven_finishes(self):
        target = self.root / settings.APPLIED_PATH
        target.write_text(json.dumps({'schema_version': 1, 'selected_skin_ids': ['neon420']}))
        settings.save(self.root, self.catalog, ['deeporbit'], False)
        self.prepare()
        supported, chest = settings.retained_classes(self.root, self.catalog)
        self.assertEqual(['neon420', 'deeporbit'], supported)
        self.assertTrue(chest)
        self.assertNotIn('archer', supported)

    def test_old_installed_bank_recovers_history_without_applied_file(self):
        skins.build_pbo(self.source, self.pack, self.catalog, ['neon420'])
        self.assertFalse((self.root / settings.APPLIED_PATH).exists())
        settings.save(self.root, self.catalog, [], False)
        self.prepare()
        self.assertEqual((['neon420'], True), skins.installed_classes(self.pack, self.catalog))
        self.assertEqual((['neon420'], True), settings.retained_classes(self.root, self.catalog))

    def test_corrupt_installed_bank_fails_without_replacement(self):
        pbo = skins.build_pbo(self.source, self.pack, self.catalog, ['neon420'])
        broken = pbo.read_bytes()[:-1] + b'X'
        pbo.write_bytes(broken)
        with self.assertRaisesRegex(ValueError, 'saved classes'):
            self.prepare()
        self.assertEqual(broken, pbo.read_bytes())
        self.assertFalse((self.root / settings.APPLIED_PATH).exists())

    def test_unknown_receipt_or_broken_history_fails_closed(self):
        receipt = self.receipt()
        value = json.loads(receipt.read_text())
        value['weapons'][0]['class_name'] = 'Azimuth_Showcase_M4A1_Unknown'
        receipt.write_text(json.dumps(value))
        before = receipt.read_bytes()
        with self.assertRaisesRegex(ValueError, 'unknown rifle'):
            settings.retained_classes(self.root, self.catalog)
        self.assertEqual(before, receipt.read_bytes())
        receipt.unlink()
        (self.root / settings.APPLIED_PATH).write_text(json.dumps({'schema_version': 1, 'selected_skin_ids': ['unknown']}))
        with self.assertRaisesRegex(ValueError, 'class history'):
            settings.retained_classes(self.root, self.catalog)

    def test_receipt_only_chest_keeps_config_only_pack_and_cleanup_script(self):
        receipt = self.receipt(weapons=False)
        receipt_before = receipt.read_bytes()
        settings.save(self.root, self.catalog, [], False)
        (_, notices), captured = self.prepare()
        self.assertEqual([], captured[0]['skins'])
        data = (self.pack / 'Addons/azimuthskins.pbo').read_bytes()
        self.assertIn(b'class Azimuth_Skins_ShowcaseChest: SeaChest', data)
        self.assertNotIn(b'data\\', data)
        self.assertTrue(notices)
        shutil.copytree(ROOT / skin_showcase.SOURCE, self.root / skin_showcase.SOURCE)
        skin_showcase.prepare(self.root, self.mods, self.profiles)
        self.assertTrue((self.mods / 'ServerOnly' / skin_showcase.MOD_NAME / 'Addons/azimuthshowcase.pbo').is_file())
        config = json.loads((self.profiles / 'AzimuthSkins/showcase.json').read_text())
        self.assertFalse(config['test_kit_enabled'])
        self.assertEqual([], config['weapon_classes'])
        self.assertEqual(receipt_before, receipt.read_bytes())

    def test_compatibility_never_reenters_random_pool_or_rearms_requests(self):
        self.receipt()
        choices = settings.save(self.root, self.catalog, [], False)
        choices_before = (self.root / settings.SETTINGS_PATH).read_bytes()
        self.prepare()
        self.assertEqual(choices_before, (self.root / settings.SETTINGS_PATH).read_bytes())
        original = (ROOT / random_skin_mode.SOURCE / 'config.cpp').read_text()
        rendered = random_skin_mode.render_config(original, self.catalog, settings.load(self.root, self.catalog))
        self.assertIn('skinIds[] = {};', rendered)
        self.assertIn('vehicleEnabled = 0;', rendered)
        self.assertIn('enabled = 0;', rendered)
        self.assertEqual(choices['test_kit_generation'], settings.load(self.root, self.catalog)['test_kit_generation'])
        self.assertEqual(choices['vehicle_test_generation'], settings.load(self.root, self.catalog)['vehicle_test_generation'])

    def test_fresh_empty_installation_does_not_load_all_thirty(self):
        settings.save(self.root, self.catalog, [], False)
        result, captured = self.prepare()
        self.assertEqual((0, ()), result)
        self.assertEqual([], captured)
        self.assertFalse(self.pack.exists())

    def test_retained_classes_have_no_new_economy_spawns(self):
        retained = settings.selected_catalog(self.catalog, ['neon420'])
        templates, spawnables = {}, {}
        for weapon in retained['weapons']:
            base = weapon['base_class']
            element = ET.fromstring(f'<type name="{base}"><nominal>20</nominal><min>10</min><flags crafted="0"/></type>')
            templates[base.casefold()] = SimpleNamespace(nominal=20, element=element)
            spawnables[base.casefold()] = ET.fromstring(f'<type name="{base}"><attachments chance="1"><item name="VanillaPart" chance="1"/></attachments></type>')
        with patch.object(skins, 'read_economy', return_value=SimpleNamespace(warnings=[], types=templates)), \
                patch.object(skins, '_spawn_templates', return_value=spawnables), \
                patch.object(skins, '_read_xml', return_value=ET.Element('economycore')), \
                patch.object(skins, '_check_type_collisions'):
            files, _ = skins.economy_files(self.root/'Mission', retained)
        types = ET.fromstring(files['types'][1])
        self.assertGreater(len(types.findall('type')), 0)
        for node in types.findall('type'):
            self.assertEqual('0', node.findtext('nominal'))
            self.assertEqual('0', node.findtext('min'))

    def test_deferred_cleanup_is_requeueable_without_erasing_records(self):
        receipt_path = self.receipt()
        choices = settings.request_cleanup(self.root, self.catalog)
        receipt = json.loads(receipt_path.read_text())
        receipt.update(cleanup_generation=choices['cleanup_generation'], cleanup_pending=False,
                       status='cleanup_deferred', message='Recorded items remain unavailable; classes kept.')
        receipt_path.write_text(json.dumps(receipt))
        before = receipt_path.read_bytes()
        self.assertFalse(skin_showcase.cleanup_pending(choices, receipt))
        self.assertEqual(receipt['message'], skin_showcase.status_text(choices, receipt))
        fresh = settings.request_cleanup(self.root, self.catalog)
        self.assertTrue(skin_showcase.cleanup_pending(fresh, receipt))
        self.assertEqual(before, receipt_path.read_bytes())


def extract(source, name):
    start = source.index('    static void ' + name + '(')
    opening = source.index('{', start)
    end, depth = opening + 1, 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end]


class CleanupControlFlowTests(unittest.TestCase):
    def test_actual_cleanup_distinguishes_missing_protected_and_empty_entities(self):
        source = (ROOT / skin_showcase.SOURCE / 'scripts/5_mission/azimuth_showcase.c').read_text()
        body = extract(source, 'Cleanup')
        for name in ('PlayerBase', 'AzimuthShowcaseConfig', 'AzimuthShowcaseState'):
            body = body.replace(name + ' ', name + '* ')
        body = body.replace('ref array<EntityAI>', 'Array<EntityAI>*').replace('new array<EntityAI>', 'new Array<EntityAI>')
        body = body.replace('foreach (AzimuthShowcaseChestRecord oldChest : state.chests)', 'for (auto oldChest : state->chests->values)')
        body = body.replace('foreach (EntityAI content : contents)', 'for (auto content : contents->values)')
        body = body.replace('AzimuthShowcaseWeaponRecord record = state.weapons[w];', 'auto record = state->weapons->values[w];')
        body = re.sub(r'state.chests\[([^\]]+)\]', r'state->chests->values[\1]', body)
        body = body.replace('InventoryTraversalType.PREORDER', '0').replace('removed.ToString()', 'std::to_string(removed)')
        body = body.replace('GetGame().', 'GetGame()->').replace('GetInventory().', 'GetInventory()->')
        for variable in ['player', 'state', 'config', 'oldChest', 'record', 'weapon', 'chest', 'content']:
            body = body.replace(variable + '.', variable + '->')
        body = body.replace('weapons.', 'weapons->').replace('chests.', 'chests->').replace('].persistent_id', ']->persistent_id')
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            cpp = path / 'cleanup.cpp'
            cpp.write_text(ADAPTER + body + MAIN)
            result = subprocess.run(['g++', '-std=c++17', '-O0', '-fsanitize=undefined', '-fno-sanitize-recover=all', str(cpp), '-o', str(path/'cleanup')],capture_output=True,text=True)
            self.assertEqual(0, result.returncode, result.stderr)
            run = subprocess.run([str(path/'cleanup')],capture_output=True,text=True)
            self.assertEqual(0, run.returncode, run.stdout + run.stderr)


ADAPTER = r'''
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <stdexcept>
struct string:std::string{using std::string::string;string()=default;string(const std::string& v):std::string(v){}int IndexOf(const string& s){auto p=find(s);return p==npos?-1:int(p);}};
template<class T>struct Array{std::vector<T>values;int Count(){return int(values.size());}void Remove(int i){values.erase(values.begin()+i);}};
struct Entity;using EntityAI=Entity*;
struct Inventory{std::vector<EntityAI> items;void EnumerateInventory(int,Array<EntityAI>* out){out->values=items;}};
struct Entity{Entity* owner=nullptr;Inventory inventory;bool deleted=false,knownParts=true;Entity* GetHierarchyRootPlayer(){return owner;}Inventory* GetInventory(){return &inventory;}bool IsSetForDeletion(){return deleted;}void DeleteSafe(){deleted=true;}};
struct PlayerBase:Entity{int GetPosition(){return 0;}};
struct AzimuthShowcaseWeaponRecord{string class_name="Azimuth_Showcase_M4A1_Neon420",persistent_id="rifle";};
struct AzimuthShowcaseChestRecord{string persistent_id="chest";int position=0;};
struct AzimuthShowcaseConfig{string cleanup_generation="cleanup";};
struct AzimuthShowcaseState{Array<AzimuthShowcaseWeaponRecord*>*weapons=new Array<AzimuthShowcaseWeaponRecord*>;Array<AzimuthShowcaseChestRecord*>*chests=new Array<AzimuthShowcaseChestRecord*>;string cleanup_generation,status,message;bool cleanup_pending=false;};
struct Game{bool classPresent=true;bool ConfigIsExisting(string){return classPresent;}}game;
Game* GetGame(){return &game;}
std::map<string,EntityAI> found;
void require(bool value,const char* why){if(!value)throw std::runtime_error(why);}
struct AzimuthSkinShowcase{
static inline string WEAPON_PREFIX="Azimuth_Showcase_M4A1_",CHEST_CLASS="Azimuth_Skins_ShowcaseChest";
static void Collect(EntityAI,PlayerBase*,Array<EntityAI>*){}
static void CollectNearby(int,PlayerBase*,Array<EntityAI>*){}
static EntityAI FindRecorded(string id,string,Array<EntityAI>*){return found.count(id)?found[id]:nullptr;}
static bool ContainsOnlyIssuedParts(EntityAI e,AzimuthShowcaseWeaponRecord*){return e->knownParts;}
static bool Save(AzimuthShowcaseState*){return true;}
static void Notify(PlayerBase*,string){}
'''
MAIN = r'''
};
int main(){try{
PlayerBase player;AzimuthShowcaseConfig cfg;AzimuthShowcaseState state;AzimuthShowcaseChestRecord chest;AzimuthShowcaseWeaponRecord rifle;
state.chests->values={&chest};state.weapons->values={&rifle};
for(int i=0;i<100;i++)AzimuthSkinShowcase::Cleanup(&player,&cfg,&state);
require(state.chests->Count()==1&&state.weapons->Count()==1&&!state.cleanup_pending&&state.status=="cleanup_deferred","Absent receipts were retired or permanently blocked");
Entity box,userGear,gun;box.inventory.items={&userGear};found["chest"]=&box;gun.knownParts=false;found["rifle"]=&gun;
AzimuthSkinShowcase::Cleanup(&player,&cfg,&state);
require(state.cleanup_pending&&!box.deleted&&!gun.deleted&&state.status=="cleanup_pending","User-added gear was removed or not protected");
box.inventory.items.clear();gun.knownParts=true;game.classPresent=false;
AzimuthSkinShowcase::Cleanup(&player,&cfg,&state);
require(box.deleted&&!gun.deleted&&state.weapons->Count()==1&&state.status=="cleanup_deferred","Missing class receipt was retired");
game.classPresent=true;gun.owner=&player;
AzimuthSkinShowcase::Cleanup(&player,&cfg,&state);
require(state.cleanup_pending&&!gun.deleted,"Player-owned rifle was deleted");
gun.owner=nullptr;AzimuthSkinShowcase::Cleanup(&player,&cfg,&state);
require(gun.deleted&&state.weapons->Count()==0&&state.chests->Count()==0&&!state.cleanup_pending&&state.status=="removed","Reachable unchanged cleanup did not finish");
std::cout<<"PASS cleanup absent, protected, unavailable-class, player-owned and empty cases\n";
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
'''

if __name__ == '__main__':
    unittest.main()
