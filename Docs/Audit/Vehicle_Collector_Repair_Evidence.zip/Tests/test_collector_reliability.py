"""Collector isolation, truthful status and atomic companion publication."""
import json
import pathlib
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile, ZIP_DEFLATED

import test_vehicle_repair_assets as fixtures

repair = fixtures.repair
evidence = fixtures.evidence


class CollectorReliabilityTests(unittest.TestCase):
    setUp = fixtures.RepairCollectorTests.setUp
    collect = fixtures.RepairCollectorTests.collect

    def roots(self, extra=()):
        return [('workshop_3387855369_library_1',self.mods,False),
                ('workshop_3639695989_library_1',self.lm,False),*extra]

    def include_owner(self, wid):
        path = self.app / repair.CATALOG
        value = json.loads(path.read_text())
        value['packs'].append({'id':wid,'asset_issues':[{'resource':'testvehicles/missing.p3d'}]})
        path.write_text(json.dumps(value))

    def test_large_irrelevant_native_prefix_cannot_consume_workshop_member_budget(self):
        native=self.base/'native';native.mkdir()
        (native/'sounds_weapons.pbo').write_bytes(fixtures.pbo(
            [(f'{i}.bin',b'x',0,0) for i in range(20)],'DZ/sounds/weapons'))
        roots=[('dayz_client',native,True),*self.roots()]
        with patch.object(evidence,'_discover',return_value=(roots,[],[])),patch.object(evidence,'MAX_TOTAL_ENTRIES',15):
            _,report,_=self.collect()
        self.assertEqual(report['counts']['copied_assets'],5)
        self.assertEqual(report['raw_lm']['status'],'copied')
        native_record=next(r for r in report['archives'] if r['source']=='dayz_client')
        self.assertEqual(native_record['status'],'unrelated_native_prefix')

    def test_one_source_member_limit_does_not_skip_another_source_or_lm(self):
        bad=self.base/'bad';bad.mkdir();self.include_owner('2971993210')
        (bad/'huge.pbo').write_bytes(fixtures.pbo([(f'{i}.bin',b'x',0,0) for i in range(15)]))
        with patch.object(evidence,'_discover',return_value=(self.roots([('workshop_2971993210_library_1',bad,False)]),[],[])),patch.object(repair,'MAX_SOURCE_ENTRIES',12):
            _,report,_=self.collect()
        self.assertEqual(report['counts']['copied_assets'],5)
        self.assertEqual(report['raw_lm']['status'],'copied')
        self.assertTrue(report['partial_scan'])
        self.assertEqual(next(s for s in report['sources'] if '2971993210' in s['source'])['status'],'scan_limit')

    def test_corrupt_archive_charges_actual_reads_and_later_sources_are_collected(self):
        bad=self.base/'bad';bad.mkdir();self.include_owner('2971993210')
        (bad/'broken.pbo').write_bytes(b'bad')
        with patch.object(evidence,'_discover',return_value=(self.roots([('workshop_2971993210_library_1',bad,False)]),[],[])):
            _,report,_=self.collect()
        source=next(s for s in report['sources'] if '2971993210' in s['source'])
        self.assertEqual(source['header_bytes_read'],3)
        self.assertTrue(report['partial_scan'])
        self.assertEqual(report['counts']['copied_assets'],5)

    def test_exact_lm_is_scanned_before_auxiliary_archive_limit(self):
        (self.lm/'vehicle_extra.pbo').write_bytes(fixtures.pbo([('x.p3d',b'x',0,0)]))
        with patch.object(repair,'MAX_SOURCE_PBOS',1):_,report,_=self.collect()
        self.assertEqual(report['raw_lm']['status'],'copied')
        self.assertEqual(report['archives'][0]['archive'],'LM_Planes.pbo')
        self.assertTrue(report['partial_scan'])

    def test_lm_source_missing_and_incomplete_scan_are_distinct_from_absent_archive(self):
        with patch.object(evidence,'_discover',return_value=(self.roots()[:1],[],[])):
            _,missing,_=self.collect()
        self.assertEqual(missing['raw_lm']['status'],'source_not_located')
        self.raw.unlink()
        (self.lm/'a.pbo').write_bytes(fixtures.pbo([]));(self.lm/'b.pbo').write_bytes(fixtures.pbo([]))
        with patch.object(repair,'MAX_SOURCE_PBOS',1):_,partial,_=self.collect()
        self.assertEqual(partial['raw_lm']['status'],'not_scanned')
        _,complete,_=self.collect()
        self.assertEqual(complete['raw_lm']['status'],'not_found')

    def test_companion_contains_original_lm_and_summary_reports_both_files(self):
        # Model payload fits in the main budget; raw LM cannot crowd it out.
        self.raw.write_bytes(b'L'*500)
        with patch.object(repair,'MAX_PAYLOAD_BYTES',150):path,report,_=self.collect()
        self.assertEqual(report['counts']['copied_assets'],5)
        self.assertEqual(report['raw_lm']['status'],'copied_in_companion')
        summary=repair.read_collection_summary(path)
        self.assertEqual(len(summary['companion_files']),1)
        self.assertEqual(summary['copied_assets'],5)
        files=list(path.parent.iterdir());self.assertEqual(len(files),2)
        with ZipFile(path.parent/summary['companion_files'][0]) as archive:
            row=next(r for r in report['files'] if r['kind']=='raw_lm')
            self.assertEqual(archive.read(row['export_path']),self.raw.read_bytes())
        self.assertFalse(any(p.name.startswith('.vehicle-repair-') for p in path.parent.parent.iterdir()))

    def test_companion_write_failure_leaves_no_partial_collection(self):
        self.raw.write_bytes(b'L'*500)
        original=repair._copy_payload
        def fail(archive,item):
            if item.kind=='raw_lm':raise OSError('injected disk failure')
            return original(archive,item)
        with patch.object(repair,'MAX_PAYLOAD_BYTES',150),patch.object(repair,'_copy_payload',side_effect=fail):
            with self.assertRaisesRegex(OSError,'disk failure'):self.collect()
        self.assertEqual(list((self.app/'Docs/Audit/Exports').iterdir()),[])

    def test_companion_close_failure_still_removes_staging_directory(self):
        self.raw.write_bytes(b'L'*500)
        original=repair.ZipFile.close
        def fail_close(archive):
            name=str(getattr(archive,'filename',''))
            if 'Azimuth_LM_Planes_Repair_Files_' in name and getattr(archive,'fp',None) is not None:
                original(archive)
                raise OSError('injected close failure')
            return original(archive)
        with patch.object(repair,'MAX_PAYLOAD_BYTES',150),patch.object(repair.ZipFile,'close',fail_close):
            with self.assertRaisesRegex(OSError,'close failure'):self.collect()
        self.assertEqual(list((self.app/'Docs/Audit/Exports').iterdir()),[])

    def test_oversized_lm_collects_bounded_diagnostics_and_records_real_size(self):
        self.raw.write_bytes(bytes(range(100)))
        with patch.object(repair,'MAX_RAW_LM_BYTES',50),patch.object(repair,'MAX_LM_PROBE_BYTES',10),patch.object(repair,'MAX_LM_TAIL_BYTES',5):
            _,report,data=self.collect()
        self.assertEqual(report['raw_lm']['status'],'over_size_limit')
        self.assertTrue(report['raw_lm']['diagnostics_collected'])
        self.assertEqual(report['raw_lm']['archives'][0]['bytes'],100)
        rows=[r for r in report['files'] if r['kind']=='raw_lm_probe']
        self.assertEqual(sorted(r['stored_bytes'] for r in rows),[5,10])
        self.assertEqual(data[next(r['export_path'] for r in rows if r['export_path'].endswith('header.bin'))],bytes(range(10)))

    def test_equal_payloads_are_deduplicated_only_after_hash_equality(self):
        other=self.base/'other';other.mkdir()
        (other/'vehicle.pbo').write_bytes(self.source.read_bytes())
        with patch.object(evidence,'_discover',return_value=(self.roots([('workshop_3387855369_library_2',other,False)]),[],[])):
            _,report,_=self.collect()
        self.assertGreater(report['counts']['deduplicated_sources'],0)
        rows=[r for r in report['files'] if r['resource']=='testvehicles/body.p3d']
        self.assertEqual(rows[0]['export_path'],rows[1]['export_path'])
        (other/'vehicle.pbo').write_bytes(fixtures.pbo([('body.p3d',b'different data',0,0)]))
        with patch.object(evidence,'_discover',return_value=(self.roots([('workshop_3387855369_library_2',other,False)]),[],[])):
            _,report,_=self.collect()
        rows=[r for r in report['files'] if r['resource']=='testvehicles/body.p3d']
        self.assertNotEqual(rows[0]['sha256'],rows[1]['sha256'])
        self.assertNotEqual(rows[0]['export_path'],rows[1]['export_path'])

    def test_summary_rejects_missing_companion_and_invalid_zip(self):
        self.raw.write_bytes(b'L'*500)
        with patch.object(repair,'MAX_PAYLOAD_BYTES',150):path,report,_=self.collect()
        (path.parent/report['companion_files'][0]['file_name']).unlink()
        with self.assertRaises(ValueError):repair.read_collection_summary(path)
        path.write_bytes(b'not a zip')
        with self.assertRaises(ValueError):repair.read_collection_summary(path)

    def test_script_planning_limit_does_not_prevent_later_exact_assets(self):
        rows=[(f'scripts/{i}.c',b'class Script {}',0,0) for i in range(8)]
        rows += [('body.p3d',b'original model',0,0)]
        self.source.write_bytes(fixtures.pbo(rows))
        with patch.object(repair,'MAX_SOURCE_SCRIPT_FILES',2):_,report,_=self.collect()
        self.assertTrue(any(r['resource']=='testvehicles/body.p3d' and r['status']=='copied' for r in report['files']))
        self.assertEqual(next(s for s in report['sources'] if '3387855369' in s['source'])['scripts_not_planned'],6)
        self.assertTrue(report['partial_scan'])


if __name__=='__main__':unittest.main(verbosity=2)
