"""Replay uploaded directory names with synthetic payloads, not native game data.

The two retained user exports supply exact source labels, virtual prefixes and
member names. This proves selection/reachability and starvation handling; it
does not claim P3D rendering, native compilation or actual file transfer on PC.
"""
from __future__ import annotations
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile

TASK = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('AZIMUTH_TEST_ROOT', TASK / 'package/Azimuth')).resolve()
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'Engine'))
from azimuth_app.checks import vehicle_repair_assets as repair
from azimuth_app.checks import vehicle_wrap_evidence as evidence

MISSING = {
    'techs_allterrainvehicle/techs_proxies/techs_atv_handlebars.p3d',
    'van_camperrv/data/armor/armor_body.rvmat',
    'van_dodgephoenix/data/steklo.rvmat',
    'van_dodgephoenix/data/steklo_damage.rvmat',
    'van_dodgephoenix/data/steklo_destruct.rvmat',
    'van_hiluxcamper/data/armor/armor_body.rvmat',
    'van_hiluxcamper/data/glass.rvmat',
    'van_hiluxcamper/data/glass_damage.rvmat',
    'van_hiluxcamper/data/glass_destruct.rvmat',
}


def write_fixture(path: Path, prefix: str, names: list[str]):
    """Real PBO directory layout; each body is explicitly artificial evidence."""
    path.parent.mkdir(parents=True, exist_ok=True)
    data = b'SYNTHETIC_REPLAY_PAYLOAD'
    with path.open('wb') as stream:
        stream.write(b'\0sreV' + bytes(16) + b'prefix\0' + prefix.encode() + b'\0\0')
        for name in names:
            stream.write(name.encode() + b'\0' + struct.pack('<5I', 0, 0, 0, 0, len(data)))
        stream.write(bytes(21))
        for _ in names:
            stream.write(data)


class ActualExportReplay(unittest.TestCase):
    def test_exact_uploaded_inventory_reached_after_sixty_thousand_irrelevant_members(self):
        config_path = TASK / 'input/evidence/Vehicle_Wrap_Evidence.json'
        repair_path = TASK / 'input/assets/Vehicle_Repair_Files.json'
        inventory = json.loads(config_path.read_text())
        prior = json.loads(repair_path.read_text())
        requested = {r['resource'] for r in prior['requested_assets']}
        self.assertEqual(200, len(requested))
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            app = base / 'app'
            app.mkdir()
            for relative in (repair.COVERAGE, repair.CATALOG):
                destination = app / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT / relative, destination)
            targets, owners = repair._targets(app)
            self.assertEqual(requested, set(targets))
            folders = {label: base / 'sources' / label for label in inventory['sources']}
            for folder in folders.values():
                folder.mkdir(parents=True)
            expected_from_index = set()
            indexed = 0
            for row in inventory['archives']:
                if row['status'] != 'indexed':
                    continue
                source = row['source']
                names = [m['path'] for m in row['members']]
                names = list(dict.fromkeys(names))
                prefix = row.get('virtual_prefix', '')
                write_fixture(folders[source] / row['archive'], prefix, names)
                indexed += 1
                for name in names:
                    full = (prefix.rstrip('/') + '/' + name).strip('/').replace('\\', '/').casefold()
                    if full in targets:
                        expected_from_index.add(full)
            self.assertEqual(190, len(expected_from_index))
            # The generic native data PBO is absent from the config-only export,
            # but the user's repair ZIP proves this exact member exists there.
            native_default = 'dz/data/data/default.rvmat'
            self.assertTrue(any(r['resource'] == native_default and r['status'] == 'copied'
                                for r in prior['files']))
            write_fixture(folders['dayz_client'] / 'data.pbo', 'DZ/data', ['data/default.rvmat'])
            for index in range(4):
                write_fixture(folders['dayz_client'] / f'000_sounds_{index}.pbo',
                              f'DZ/sounds/replay{index}', [f'sound_{i}.ogg' for i in range(15000)])
            lm_label = 'workshop_3639695989_library_1'
            lm_bytes = b'SYNTHETIC_OPAQUE_LM_CONTAINER_REPLAY'
            (folders[lm_label] / 'LM_Planes.pbo').write_bytes(lm_bytes)
            roots = [(label, folder, label.startswith('dayz_')) for label, folder in folders.items()]
            roots.sort(key=lambda r: (not r[2], r[0]))  # reproduce original native-first discovery
            with patch.object(evidence, '_discover', return_value=(roots, [], [])):
                output = repair.collect_vehicle_repair_assets(app, [])
            with ZipFile(output) as archive:
                manifest = json.loads(archive.read('Vehicle_Repair_Files.json'))
                copied = {row['resource'] for row in manifest['files'] if row['status'] == 'copied'}
                captured = copied & requested
                expected = expected_from_index | {native_default}
                self.assertEqual(expected, captured)
                self.assertEqual(191, len(captured))
                self.assertEqual(MISSING, set(manifest['missing_assets']))
                self.assertFalse(manifest['partial_scan'])
                self.assertEqual([], manifest['missing_workshop_sources'])
                self.assertEqual(0, manifest['counts']['limited_files'])
                self.assertEqual('copied', manifest['raw_lm']['status'])
                raw = next(row for row in manifest['files'] if row['kind'] == 'raw_lm' and row['status'] == 'copied')
                self.assertEqual(lm_bytes, archive.read(raw['export_path']))
                reached = {row['source'].split('_')[1] for row in manifest['archives']
                           if row['source'].startswith('workshop_')}
                self.assertTrue(owners <= reached, (owners, reached))
                self.assertLessEqual(output.stat().st_size, repair.MAX_ZIP_BYTES)
            report = {
                'input_manifests_sha256': {str(p.relative_to(TASK)): sha256(p.read_bytes()).hexdigest()
                                           for p in (config_path, repair_path)},
                'indexed_archive_fixtures': indexed,
                'synthetic_unrelated_native_members': 60000,
                'requested_assets': len(requested),
                'captured_assets': len(captured),
                'missing_assets': sorted(MISSING),
                'required_workshop_owners_reached': sorted(owners),
                'raw_lm_small_synthetic_container_copied': True,
                'scan_complete_without_limited_payloads': True,
                'limitation': 'PBO headers replay exact uploaded names; all bodies synthetic. No native runtime or real LM binary validation.',
                'result': 'pass',
            }
            (TASK / 'reports').mkdir(exist_ok=True)
            (TASK / 'reports/actual_manifest_replay.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    unittest.main(verbosity=2)
