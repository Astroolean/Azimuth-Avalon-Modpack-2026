"""Graphics-baseline and executable compatibility regressions; no native launch."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import os
import sys
import unittest

SOURCE = Path(os.environ.get("AZIMUTH_TEST_ROOT", str(Path(__file__).resolve().parents[1] / "package" / "Azimuth")))
sys.path.insert(0, str(SOURCE / "Engine"))
from azimuth_app.client import client_performance as graphics
from azimuth_app.transport import transport_version as versions


PROFILE = (b"viewDistance=3500;\npreferredObjectViewDistance=2200;\n"
           b"TexQuality=1;\nshadowQuality=1;\nshadowZDistance=80;\n"
           b"sceneComplexity=500000;\nUnrelated=9;\n")
CFG = b"MSAA=0;\nAToC=0;\nFXAA=0;\nAnisoFilter=0;\nResolution_W=1920;\n"


class GraphicsBaselineTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.dayz = self.root / "DayZ"
        self.dayz.mkdir()
        self.profile = self.dayz / "Player_settings.DayZProfile"
        self.profile.write_bytes(PROFILE)
        self.config = self.dayz / "DayZ.cfg"
        self.config.write_bytes(CFG)
        self.addCleanup(patch.stopall)
        patch.object(graphics, "ensure_client_closed").start()
        patch.object(graphics, "documents_directory", return_value=self.root).start()

    def test_corrupt_existing_fps_backups_block_changes_and_are_preserved(self):
        backup = graphics.backup_file(self.profile)
        for payload in (b"", b"unrelated=42;\n", b"viewDistance=not_a_number;\n",
                        b"viewDistance=3000;\nviewDistance=4000;\n"):
            with self.subTest(payload=payload):
                backup.write_bytes(payload)
                with self.assertRaises(ValueError):
                    graphics.apply_preset(self.profile)
                self.assertEqual(PROFILE, self.profile.read_bytes())
                self.assertEqual(payload, backup.read_bytes())

    def test_valid_existing_fps_backup_restores_originals(self):
        backup = graphics.backup_file(self.profile)
        baseline = PROFILE.replace(b"3500", b"4200").replace(b"2200", b"2700")
        backup.write_bytes(baseline)
        self.assertEqual(backup, graphics.apply_preset(self.profile))
        self.assertIn(b"viewDistance=1600;", self.profile.read_bytes())
        self.assertEqual(baseline, backup.read_bytes())
        self.profile.write_bytes(self.profile.read_bytes().replace(b"Unrelated=9", b"Unrelated=12"))
        graphics.restore_quality_preset(self.profile)
        self.assertEqual(baseline.replace(b"Unrelated=9", b"Unrelated=12"), self.profile.read_bytes())

    def test_new_visibility_field_is_remembered_once_in_existing_backup(self):
        backup = graphics.backup_file(self.profile)
        backup.write_bytes(b"viewDistance=4200;\n")
        graphics.apply_preset(self.profile)
        saved = backup.read_bytes()
        self.assertEqual(b"viewDistance=4200;\npreferredObjectViewDistance=2200;\n", saved)
        self.profile.write_bytes(self.profile.read_bytes().replace(b"1000", b"1800"))
        graphics.apply_preset(self.profile)
        self.assertEqual(saved, backup.read_bytes())
        graphics.restore_profile(self.profile)
        self.assertIn(b"viewDistance=4200;", self.profile.read_bytes())
        self.assertIn(b"preferredObjectViewDistance=2200;", self.profile.read_bytes())

    def test_fps_after_quality_preserves_pre_quality_visibility(self):
        graphics.apply_quality_preset(self.profile)
        graphics.apply_preset(self.profile)
        baseline = graphics.backup_file(self.profile).read_bytes()
        self.assertIn(b"viewDistance=3500;", baseline)
        self.assertIn(b"preferredObjectViewDistance=2200;", baseline)
        graphics.restore_quality_preset(self.profile)
        self.assertEqual(PROFILE, self.profile.read_bytes())
        self.assertEqual(CFG, self.config.read_bytes())

    def test_fps_target_failure_removes_new_backup(self):
        replace = os.replace
        def fail_profile(source, target):
            if Path(target) == self.profile:
                raise OSError("injected profile publication failure")
            return replace(source, target)
        with patch.object(graphics.os, "replace", side_effect=fail_profile):
            with self.assertRaises(OSError):
                graphics.apply_preset(self.profile)
        self.assertEqual(PROFILE, self.profile.read_bytes())
        self.assertFalse(graphics.backup_file(self.profile).exists())
        self.assertFalse(list(self.dayz.glob(".azimuth-video-*")))

    def test_fps_target_failure_rolls_existing_backup_extension_back(self):
        backup = graphics.backup_file(self.profile)
        baseline = b"viewDistance=4200;\n"
        backup.write_bytes(baseline)
        replace = os.replace
        def fail_profile(source, target):
            if Path(target) == self.profile:
                raise OSError("injected profile publication failure")
            return replace(source, target)
        with patch.object(graphics.os, "replace", side_effect=fail_profile):
            with self.assertRaises(OSError):
                graphics.apply_preset(self.profile)
        self.assertEqual(PROFILE, self.profile.read_bytes())
        self.assertEqual(baseline, backup.read_bytes())

    def test_legacy_visual_rejects_corrupt_baseline(self):
        backup = graphics.visual_backup_file(self.profile)
        backup.write_bytes(b"viewDistance=3500;\nTexQuality=bad;\n")
        with self.assertRaises(ValueError):
            graphics.apply_visual_preset(self.profile)
        self.assertEqual(PROFILE, self.profile.read_bytes())

    def test_legacy_visual_remembers_new_quality_field(self):
        backup = graphics.visual_backup_file(self.profile)
        backup.write_bytes(b"viewDistance=3500;\npreferredObjectViewDistance=2200;\n")
        graphics.apply_visual_preset(self.profile)
        self.assertIn(b"TexQuality=1;", backup.read_bytes())
        graphics.restore_visual_profile(self.profile)
        self.assertEqual(PROFILE, self.profile.read_bytes())

    def test_quality_multi_file_roundtrip_retains_unrelated_edits(self):
        graphics.apply_quality_preset(self.profile)
        self.profile.write_bytes(self.profile.read_bytes().replace(b"Unrelated=9", b"Unrelated=12"))
        self.config.write_bytes(self.config.read_bytes().replace(b"Resolution_W=1920", b"Resolution_W=2560"))
        graphics.restore_quality_preset(self.profile)
        self.assertEqual(PROFILE.replace(b"Unrelated=9", b"Unrelated=12"), self.profile.read_bytes())
        self.assertEqual(CFG.replace(b"Resolution_W=1920", b"Resolution_W=2560"), self.config.read_bytes())


class ClientVersionCompatibilityTests(unittest.TestCase):
    CLIENT = Path("/fake/client/DayZ_x64.exe")
    SERVER = Path("/fake/server/DayZServer_x64.exe")

    def compare(self, client, server, **kwargs):
        with patch.object(versions, "read_file_version", side_effect=[client, server]) as read:
            result = versions.require_matching_dayz_versions(self.CLIENT, self.SERVER, **kwargs)
        self.assertEqual([self.CLIENT, self.SERVER], [call.args[0] for call in read.call_args_list])
        return result

    @staticmethod
    def observed(value, product="1.29.0.0"):
        return {"status":"OBSERVED", "file_version":value, "product_version":product}

    def test_equal_supported_fixed_versions_pass_despite_product_strings(self):
        self.assertEqual(("1.30.1.2", "1.30.1.2"),
                         self.compare(self.observed("1.30.1.2"), self.observed("1.30.1.2", "1.30.9.9")))

    def test_different_patch_builds_are_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "requires matching builds"):
            self.compare(self.observed("1.30.1.2"), self.observed("1.30.1.3"))

    def test_product_match_cannot_rescue_different_file_versions(self):
        with self.assertRaisesRegex(RuntimeError, "requires matching builds"):
            self.compare(self.observed("1.30.1.2", "1.30.1.2"), self.observed("1.30.1.3", "1.30.1.2"))

    def test_matching_files_cannot_mask_older_running_server(self):
        with self.assertRaisesRegex(RuntimeError, "restart Avalon to load the updated server"):
            self.compare(self.observed("1.30.1.3"), self.observed("1.30.1.3"),
                         loaded_server_version="1.30.1.2")

    def test_matching_loaded_server_and_current_files_pass(self):
        self.assertEqual(("1.30.1.3", "1.30.1.3"),
                         self.compare(self.observed("1.30.1.3"), self.observed("1.30.1.3"),
                                      loaded_server_version="1.30.1.3"))

    def test_loaded_server_version_requires_full_fixed_shape(self):
        for loaded in ("1.30.123456", "1.30.65536.1", "", "1.30.1.3 trailing"):
            with self.subTest(loaded=loaded), self.assertRaisesRegex(RuntimeError, "recorded executable version"):
                self.compare(self.observed("1.30.1.3"), self.observed("1.30.1.3"),
                             loaded_server_version=loaded)

    def test_old_client_or_server_rejected(self):
        for client, server in (("1.29.1.2", "1.30.1.2"), ("1.30.1.2", "1.29.1.2")):
            with self.subTest(client=client, server=server), self.assertRaisesRegex(RuntimeError, "needs DayZ 1.30"):
                self.compare(self.observed(client, "1.30.1.2"), self.observed(server, "1.30.1.2"))

    def test_missing_incomplete_and_invalid_fixed_resources_fail_closed(self):
        cases = ({"status":"UNAVAILABLE"},
                 {"status":"OBSERVED", "product_version":"1.30.1.2"},
                 self.observed("1.30.123456"), self.observed("1.30.65536.1"),
                 self.observed("1.30.1.2 trailing"))
        for missing in cases:
            for client, server in ((missing,self.observed("1.30.1.2")),
                                   (self.observed("1.30.1.2"),missing)):
                with self.subTest(client=client,server=server), self.assertRaisesRegex(RuntimeError,"could not compare"):
                    self.compare(client,server)

    def test_minimum_version_gate_retains_file_version_precedence(self):
        with patch.object(versions,"read_file_version",return_value=self.observed("1.29.1.2","1.30.1.2")):
            with self.assertRaisesRegex(RuntimeError,"needs DayZ 1.30"):
                versions.require_dayz130(self.CLIENT,"DayZ")
        with patch.object(versions,"read_file_version",return_value=self.observed("1.30.1.2","1.29.1.2")):
            self.assertEqual("1.30.1.2",versions.require_dayz130(self.CLIENT,"DayZ"))


if __name__ == "__main__":
    unittest.main()
