"""Actual photo update control flow against a fake native HUD refresh.

This exercises visibility ordering, not native rendering or Enforce compilation.
"""
from pathlib import Path
import os
import re
import subprocess
import tempfile
import unittest

TASK = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('AZIMUTH_TEST_ROOT', TASK / 'package/Azimuth')).resolve()
SCRIPT = ROOT / 'Custom/PhotoMode/azimuthphoto/scripts/5_mission/azimuth_photo_mission.c'


def method(source, name):
    match = re.search(r'override void ' + name + r'\([^\n]+\)\s*\{', source)
    start = match.start()
    end, depth = match.end(), 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end]


class PhotoOverlayTests(unittest.TestCase):
    def test_full_mission_root_is_captured_and_native_reshow_is_suppressed(self):
        source = SCRIPT.read_text()
        self.assertIn('m_AzimuthPhotoHudRoot = m_HudRootWidget;', source)
        self.assertIn('m_AzimuthPhotoHudWasVisible = m_AzimuthPhotoHudRoot.IsVisible();', source)
        self.assertIn('m_AzimuthPhotoHudRoot.Show(m_AzimuthPhotoHudWasVisible);', source)
        body = method(source, 'OnUpdate').replace('override ', '').replace('super.', 'Base::')
        body = body.replace('GetGame().', 'GetGame()->').replace('m_AzimuthPhotoHudRoot.', 'm_AzimuthPhotoHudRoot->')
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            (path/'photo.cpp').write_text(ADAPTER + body + MAIN)
            result = subprocess.run(['g++','-std=c++17','-O0','-fsanitize=undefined',str(path/'photo.cpp'),'-o',str(path/'photo')],capture_output=True,text=True)
            self.assertEqual(0, result.returncode, result.stderr)
            run = subprocess.run([str(path/'photo')],capture_output=True,text=True)
            self.assertEqual(0, run.returncode, run.stdout+run.stderr)


ADAPTER = r'''
#include <stdexcept>
#include <iostream>
#include <string>
struct Widget{bool visible=true;int hides=0;void Show(bool v){visible=v;if(!v)hides++;}};
struct Game{bool dedicated=false;bool IsDedicatedServer(){return dedicated;}}game;
Game* GetGame(){return &game;}
void require(bool v,const char* why){if(!v)throw std::runtime_error(why);}
struct Base{Widget root;bool canContinue=true,openMenu=false;int baseUpdates=0;void OnUpdate(float){baseUpdates++;root.Show(true);if(openMenu)canContinue=false;}};
struct Mission:Base{
bool m_AzimuthPhotoCamera=true,m_AzimuthPhotoPlayer=true,m_AzimuthPhotoOwnsCharacterExclude=true;
Widget* m_AzimuthPhotoHudRoot=&root;bool previousVisible=true,pressed=false;int stops=0,moves=0;
bool AzimuthPhotoCanContinue(){return canContinue;}
bool AzimuthPhotoPressed(std::string){bool p=pressed;pressed=false;return p;}
void AzimuthPhotoStop(){stops++;m_AzimuthPhotoCamera=false;m_AzimuthPhotoPlayer=false;m_AzimuthPhotoOwnsCharacterExclude=false;root.Show(previousVisible);m_AzimuthPhotoHudRoot=nullptr;}
void AzimuthPhotoStart(){m_AzimuthPhotoCamera=true;m_AzimuthPhotoPlayer=true;m_AzimuthPhotoOwnsCharacterExclude=true;m_AzimuthPhotoHudRoot=&root;previousVisible=root.visible;}
void AzimuthPhotoMove(float){moves++;}
'''
MAIN=r'''
};
int main(){try{
Mission active;active.OnUpdate(0.016f);require(active.baseUpdates==1&&!active.root.visible&&active.moves==1,"Native HUD refresh defeated active photo hide");
active.OnUpdate(0.016f);require(!active.root.visible&&active.root.hides==2,"Repeated frame exposed HUD");
active.openMenu=true;active.OnUpdate(0.016f);require(active.stops==1&&active.root.visible&&!active.m_AzimuthPhotoCamera,"Menu takeover did not restore original HUD");
Mission hidden;hidden.previousVisible=false;hidden.openMenu=true;hidden.OnUpdate(0.016f);require(!hidden.root.visible&&hidden.stops==1,"Initially hidden HUD was changed on stop");
Mission inactive;inactive.m_AzimuthPhotoCamera=false;inactive.m_AzimuthPhotoPlayer=false;inactive.m_AzimuthPhotoOwnsCharacterExclude=false;inactive.m_AzimuthPhotoHudRoot=nullptr;inactive.OnUpdate(0.016f);require(inactive.root.visible&&inactive.root.hides==0,"Inactive photo changed normal HUD");
std::cout<<"PASS active rehide, menu release, hidden restore, inactive visibility\n";
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
'''
