import unittest, tempfile, json, sys, shutil, copy, os
from pathlib import Path
from unittest.mock import patch
from xml.etree import ElementTree as ET
ROOT=Path(os.environ.get('AZIMUTH_TEST_ROOT','/workspace/scratch/5af776953b72/complete_repair/package/Azimuth'))
sys.path.insert(0,str(ROOT/'Engine'))
from azimuth_app.transport import transport_survey as s

class SurveyTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.b=Path(self.tmp.name);self.m=self.b/'metro.Avalon';self.m.mkdir();self.p=self.b/'Profiles';(self.p/'Azimuth').mkdir(parents=True)
        (self.m/'cfgeventspawns.xml').write_text('<eventposdef/>')
        self.req={'schema_version':1,'algorithm_version':1,'request_id':'a'*64,'world_name':'Avalon','candidates':[{'route':r,'x':1000+1000*i,'z':1000,'a':0} for i,r in enumerate(s.ROUTES)],'excluded':[]}
        self.rep={k:self.req[k] for k in ('schema_version','algorithm_version','request_id','world_name')};self.rep.update(status='complete',world_size=10000)
        for i,(r,(radius,height,depth)) in enumerate(s.ROUTES.items()):
            self.rep[r]=[{'x':1000+1000*i,'z':1000,'y':0.3,'a':0,'surface':'sea' if depth else 'land','footprint_radius_m':radius,'sample_count':81,'min_depth_m':depth,'max_height_delta_m':0,'obstacle_clearance_m':height}]
        self.mock=patch.object(s,'_request',return_value=self.req);self.mock.start();self.addCleanup(self.mock.stop);self.write()
    def write(self):
        (self.p/'Azimuth'/s.REQUEST).write_text(json.dumps(self.req));(self.p/'Azimuth'/s.REPORT).write_text(json.dumps(self.rep))
    def test_complete_matching_report_imports_all_routes(self):
        v=s.validated_sites(self.m,self.p);self.assertEqual({r:len(x) for r,x in v.items()},{r:1 for r in s.ROUTES});self.assertEqual(v['large_water'][0].get('y'),'0.3')
    def test_wrong_request_and_world_cannot_import(self):
        for key,value in [('request_id','b'*64),('world_name','ChernarusPlus'),('algorithm_version',2)]:
            with self.subTest(key=key):
                old=self.rep[key];self.rep[key]=value;self.write();self.assertFalse(any(s.validated_sites(self.m,self.p).values()));self.rep[key]=old
    def test_partial_or_failed_report_cannot_import(self):
        for status in ('running','failed',''):
            self.rep['status']=status;self.write();self.assertFalse(any(s.validated_sites(self.m,self.p).values()))
    def test_nan_coordinate_rejected(self):
        self.rep['air'][0]['x']=float('nan');self.write()
        with self.assertRaises(ValueError):s.validated_sites(self.m,self.p)
    def test_native_float32_coordinate_rounding_is_accepted(self):
        import struct
        self.req['candidates'][0]['x']=10000.123
        self.rep['large_water'][0]['x']=struct.unpack('<f',struct.pack('<f',10000.123))[0]
        self.rep['world_size']=20000
        self.write()
        self.assertEqual(len(s.validated_sites(self.m,self.p)['large_water']),1)
    def test_coordinate_not_requested_rejected(self):
        self.rep['air'][0]['x']+=1;self.write()
        with self.assertRaises(ValueError):s.validated_sites(self.m,self.p)
    def test_shallow_vessel_site_rejected(self):
        self.rep['large_water'][0]['min_depth_m']=11.9;self.write()
        with self.assertRaises(ValueError):s.validated_sites(self.m,self.p)
    def test_undersampled_undersized_and_sloped_rejected(self):
        for key,value in [('sample_count',1),('footprint_radius_m',1),('obstacle_clearance_m',1),('max_height_delta_m',0.51)]:
            with self.subTest(key=key):
                old=self.rep['air'][0][key];self.rep['air'][0][key]=value;self.write()
                with self.assertRaises(ValueError):s.validated_sites(self.m,self.p)
                self.rep['air'][0][key]=old
    def test_authored_pad_overlap_rejected(self):
        self.req['excluded']=[{'x':self.rep['air'][0]['x'],'z':1000}];self.write()
        with self.assertRaises(ValueError):s.validated_sites(self.m,self.p)
    def test_map_edge_rejected(self):
        self.rep['world_size']=3010;self.write()
        with self.assertRaises(ValueError):s.validated_sites(self.m,self.p)
    def test_import_restart_request_clears_after_registration(self):
        self.assertTrue(s.setup_pending(self.m,self.p));self.assertFalse(s.survey_running(self.m,self.p))
        root=ET.Element('eventposdef')
        for route,points in s.validated_sites(self.m,self.p).items():ET.SubElement(root,'event',name=s.EVENTS[route]).extend(points)
        ET.ElementTree(root).write(self.m/'cfgeventspawns.xml');self.assertFalse(s.setup_pending(self.m,self.p))
        root.find("event[@name='VehicleAzimuthWorkshopAir']/pos").set('x','4000');ET.ElementTree(root).write(self.m/'cfgeventspawns.xml');self.assertTrue(s.setup_pending(self.m,self.p))
    def test_partial_native_write_is_pending_not_launch_failure(self):
        (self.p/'Azimuth'/s.REPORT).write_text('{"schema_version": 1,')
        self.assertTrue(s.survey_running(self.m,self.p))
        self.assertFalse(any(s.validated_sites(self.m,self.p).values()))
        self.write(); self.assertFalse(s.survey_running(self.m,self.p))
    def test_no_completed_report_requests_bounded_controller_wait(self):
        (self.p/'Azimuth'/s.REPORT).unlink();self.assertTrue(s.survey_running(self.m,self.p));self.rep['status']='failed';self.write();self.assertFalse(s.survey_running(self.m,self.p))
    def test_real_mission_fingerprint_excludes_generated_events_and_build_is_stable(self):
        self.mock.stop()
        original=Path('/workspace/scratch/5af776953b72/full_audit/economy/source/Worlds/avalon/World/Mission/metro.Avalon')
        for name in ('cfgeventspawns.xml','mapgroupproto.xml','mapgrouppos.xml'):shutil.copyfile(original/name,self.m/name)
        before=s._request(self.m);self.assertGreater(len(before['candidates']),100);self.assertLessEqual(len(before['candidates']),2048)
        tree=ET.parse(self.m/'cfgeventspawns.xml');ET.SubElement(tree.getroot(),'event',name='VehicleAzimuthWorkshopLargeWater').append(ET.Element('pos',x='1',z='2'));tree.write(self.m/'cfgeventspawns.xml')
        self.assertEqual(before,s._request(self.m))
        mission_bytes={f.name:f.read_bytes() for f in self.m.iterdir()}
        mod=s.prepare_survey(self.m,self.p,self.b/'Config');self.assertTrue(any(mod.rglob('*.pbo')))
        first={str(f.relative_to(mod)):f.read_bytes() for f in mod.rglob('*') if f.is_file()}
        s.prepare_survey(self.m,self.p,self.b/'Config');self.assertEqual(first,{str(f.relative_to(mod)):f.read_bytes() for f in mod.rglob('*') if f.is_file()});self.assertEqual(mission_bytes,{f.name:f.read_bytes() for f in self.m.iterdir()})

if __name__=='__main__':unittest.main()
