"""Installed-config companion recovery; synthetic fixtures never assert real class names."""
import os
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from xml.etree import ElementTree as ET

ROOT = Path(os.environ.get('AZIMUTH_SOURCE_ROOT', Path(__file__).resolve().parents[1] / 'package/Azimuth'))
sys.path.insert(0, str(ROOT / 'Engine'))
sys.dont_write_bytecode = True
from azimuth_app.world import avalon_building as building
from azimuth_app.economy.publisher_config import decode, DecodeError

# These deliberately synthetic classnames test inspection, not publisher identities.
CONFIG = b'''class CfgVehicles {
class RaG_TestHoneycomb_Spatula {scope=2; displayName="Honeycomb Spatula";};
class RaG_TestHoneycomb_Dipper {scope=2; displayName="Honeycomb Dipper";};
class RaG_TestHoney_Pot {scope=2; displayName="Honey Pot";};
class RaG_TestHoney_Pot_Full {scope=2; displayName="Full Honey Pot";};
class RaG_TestHoneycomb_Spatula_Ruined: RaG_TestHoneycomb_Spatula {};
class RaG_TestHoneyPot_Abstract {scope=0;};
};'''


def pbo_config(data):
    row = b'config.cpp\0' + struct.pack('<5I', 0, 0, 0, 0, len(data))
    return row + b'\0' + bytes(20) + data


class PublisherCompanions(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='azimuth-publisher-class-test-')
        self.root = Path(self.tmp.name)
        self.mission = self.root / 'metro.Avalon'; self.mission.mkdir()
        self.workshop = self.root / 'workshop'; self.workshop.mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def test_direct_declared_companions_only_and_empty_pot(self):
        (self.workshop / 'config.cpp').write_bytes(CONFIG)
        data, notices = building._beehive_types(self.mission, self.workshop)
        entries = {node.get('name'):node for node in ET.fromstring(data).findall('type')}
        self.assertEqual({'rag_beehive_kit','RaG_TestHoneycomb_Spatula','RaG_TestHoneycomb_Dipper','RaG_TestHoney_Pot'}, set(entries))
        self.assertEqual('8', entries['RaG_TestHoneycomb_Spatula'].findtext('nominal'))
        self.assertEqual(('0','0'), tuple(entries['RaG_TestHoney_Pot'].findtext(k) for k in ('quantmin','quantmax')))
        self.assertFalse(notices)

    def test_read_only_raw_pbo_config_inspection(self):
        addons = self.workshop / 'Addons'; addons.mkdir()
        path = addons / 'publisher.pbo'; original = pbo_config(CONFIG); path.write_bytes(original)
        classes, notices = building._beehive_config_classes(self.workshop)
        self.assertEqual({'spatula','dipper','honeypot'}, set(classes))
        self.assertEqual(original, path.read_bytes())
        self.assertFalse(notices)

    def test_ambiguous_role_does_not_choose_random_class(self):
        (self.workshop / 'config.cpp').write_bytes(CONFIG.replace(b'class RaG_TestHoney_Pot_Full',
            b'class RaG_OtherHoneycomb_Dipper {scope=2;}; class RaG_TestHoney_Pot_Full'))
        classes, notices = building._beehive_config_classes(self.workshop)
        self.assertNotIn('dipper', classes)
        self.assertTrue(any('several concrete class candidates' in n for n in notices))

    def test_authored_zero_row_is_preserved(self):
        (self.workshop / 'config.cpp').write_bytes(CONFIG)
        (self.workshop / 'types.xml').write_text('<types><type name="RaG_TestHoneycomb_Spatula"><nominal>0</nominal><flags crafted="1"/></type></types>')
        data, _ = building._beehive_types(self.mission, self.workshop)
        row = ET.fromstring(data).find("type[@name='RaG_TestHoneycomb_Spatula']")
        self.assertEqual('0', row.findtext('nominal'))
        self.assertEqual('1', row.find('flags').get('crafted'))

    def test_no_unverified_names_when_assets_absent(self):
        data, notices = building._beehive_types(self.mission, self.workshop)
        self.assertEqual(['rag_beehive_kit'], [n.get('name') for n in ET.fromstring(data)])
        self.assertTrue(any('not fully configured' in n for n in notices))

    def test_text_macros_are_not_mistaken_for_class_evidence(self):
        (self.workshop / 'config.cpp').write_bytes(b'#define scope 2\n' + CONFIG)
        classes, notices = building._beehive_config_classes(self.workshop)
        self.assertFalse(classes)
        self.assertTrue(any('preprocessing' in n for n in notices))

    def test_cross_config_inheritance_and_display_only_role_survive_reload(self):
        # The class identifier has no role token; identity is declared and the
        # role/displayName/scope come from a local base in a different payload.
        (self.workshop / 'config.cpp').write_text('class CfgVehicles {class RaG_ToolA: RaG_ToolBase {};};')
        addons = self.workshop / 'Addons'; addons.mkdir()
        (addons / 'base.pbo').write_bytes(pbo_config(b'class CfgVehicles {class RaG_ToolBase {scope=2;displayName="Honeycomb Spatula";};};'))
        classes, notices = building._beehive_config_classes(self.workshop)
        self.assertEqual('RaG_ToolA', classes['spatula'][0])
        self.assertFalse(notices)
        data, notices = building._beehive_types(self.mission, self.workshop)
        self.assertFalse(any('needed for: Honeycomb Spatula' in line for line in notices))
        folder = self.mission / 'azimuth_workshop/rag_beehive'; folder.mkdir(parents=True)
        (folder / 'types.xml').write_bytes(data)
        # Simulate a later check without loaded config assets: the annotation
        # keeps the role tied to the exact already-verified CE classname.
        (self.workshop / 'config.cpp').unlink()
        (addons / 'base.pbo').unlink()
        later, notices = building._beehive_types(self.mission, self.workshop)
        self.assertIn(b'RaG_ToolA', later)
        self.assertFalse(any('needed for: Honeycomb Spatula' in line for line in notices))
        self.assertFalse(any('needed for: Honeycomb Spatula' in line
                             for line in building.beehive_setup_notices(self.mission)))

    def test_truncated_binary_is_rejected(self):
        with self.assertRaises(DecodeError):
            decode(b'\x00raP' + bytes(12))

    def test_actual_bicycle_rap_config_identifies_known_declared_classes(self):
        fixture = Path('/workspace/scratch/5af776953b72/vehicle_integration/evidence/configs/workshop_2971190303_library_1/0131/config.bin')
        if not fixture.is_file(): self.skipTest('Original binary config evidence unavailable')
        classes = decode(fixture.read_bytes())['root']['classes']['CfgVehicles']['classes']
        self.assertEqual(2, classes['Old_Bike']['properties']['scope'])
        self.assertEqual(2, classes['Lady_Bicycle']['properties']['scope'])
        self.assertIn('ladybicycle_wheel', classes)


if __name__ == '__main__':
    unittest.main(verbosity=2)
