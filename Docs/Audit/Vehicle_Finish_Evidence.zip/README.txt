Executed transport and wrap repair checks. No native DayZ success is claimed.
Referenced original uploads and game/mod payloads remain separate; raw models and live player state are not bundled.
