"""Regression checks against the supplied publisher payload and real Avalon map."""
import hashlib
import os
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch
from xml.etree import ElementTree as ET

BASE=Path(__file__).resolve().parents[1]
WORK=BASE.parent
APP=Path(os.environ.get('AZIMUTH_TEST_ROOT', BASE/'package/Azimuth'))
sys.path.insert(0,str(APP/'Engine'))
from azimuth_app.transport import additional_vehicles as av
from azimuth_app.transport import lm_plane_positions as lp
from azimuth_app.transport import avalon_plane_transport as an2
from azimuth_app.transport import vehicle_workshop as vw
RAW=BASE/'research/lm/raw'
MISSION=WORK/'full_audit/economy/source/Worlds/avalon/World/Mission/metro.Avalon'


class PublisherCatalog(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog=av._catalog()
        cls.pack=next(p for p in cls.catalog['packs'] if p['id']=='3639695989')
        cls.classes={};cls.files={}
        for path in RAW.rglob('config.json'):
            for name,node in json.loads(path.read_text())['root']['classes'].get('CfgVehicles',{}).get('classes',{}).items():
                cls.classes[name]=node;cls.files[name]=path
    def props(self,name):
        node=self.classes[name]
        base=self.props(node['parent']) if node['parent'] in self.classes else {}
        return {**base,**node['properties']}
    def test_complete_twelve_public_config_variants_enabled(self):
        expected={n for n,c in self.classes.items() if self.props(n).get('scope')==2 and c['parent'] in ('CarScript','LM_StuntPlane')}
        self.assertEqual(len(expected),12)
        self.assertEqual(expected,{v['class'] for v in self.pack['vehicles']})
        self.assertTrue(self.pack['load'])
        self.assertIn('3639695989',av.READY_IDS)
        self.assertEqual(len(av.READY_IDS),14)
    def test_all_models_parts_and_slot_recipes_come_from_publisher(self):
        self.assertEqual(len(self.pack['parts']),16)
        for part in self.pack['parts']:
            actual=self.props(part['class'])
            self.assertEqual(part['model'],actual['model'])
            self.assertEqual(part['slots'],actual['inventorySlot'])
        for v in self.pack['vehicles']:
            actual=self.props(v['class'])
            self.assertEqual(v['model'],actual['model'])
            self.assertEqual(v['config_sha256'],hashlib.sha256(self.files[v['class']].with_suffix('.bin').read_bytes()).hexdigest())
            for a in v['attachments']:
                self.assertIn(a['slot'],actual['attachments'])
                if a['class'].startswith('LM_'):
                    self.assertIn(a['slot'],self.props(a['class'])['inventorySlot'])
            self.assertTrue(set(v['wheel_slots']) <= {a['slot'] for a in v['attachments']})
    def test_land_three_wheel_geometry_is_not_rewritten_as_four_wheels(self):
        for v in self.pack['vehicles']:
            if v['route']=='plane':self.assertEqual(len(v['wheel_slots']),3,v['class'])
        self.assertEqual({v['class'] for v in self.pack['vehicles'] if v['route']=='large_water'},
                         {'LM_Catalina','LM_Tigermoth_MK3','LM_Patty_Wagon'})
    def test_intentionally_invisible_catalina_parts_never_become_floor_loot(self):
        parts=[p for p in self.pack['parts'] if p['class'].startswith('LM_Catalina_')]
        self.assertEqual(len(parts),2)
        self.assertTrue(all(p['model']=='' and p['kind']=='virtual_wheel' for p in parts))
    def test_publisher_does_not_reopen_shared_native_base_fields(self):
        for name in ('CarScript','CarWheel','CarDoor','BoatScript','Inventory_Base'):
            self.assertNotIn(name,self.classes)
    def test_tech_optional_missing_mesh_not_attached_but_class_retained(self):
        pack=next(p for p in self.catalog['packs'] if p['id']=='3125203834')
        self.assertEqual(len(pack['vehicles']),36)
        self.assertIn('TechsHandleBars',{p['class'] for p in pack['parts']})
        self.assertFalse(any(a['class']=='TechsHandleBars' for v in pack['vehicles'] for a in v['attachments']))
        self.assertEqual(pack['asset_issues'][0]['repair'],'omitted_invalid_optional_spawn_attachment')
    def test_whole_pack_selected_on_both_launcher_mod_lists(self):
        with patch.object(vw,'workshop_paths',return_value=[('3639695989','LMs Planes',RAW)]):
            paths=type('Paths',(),{'mission_source':MISSION,'mods':RAW})()
            selected,notices=vw.resolve(paths,[],[])
        self.assertEqual(selected,{'3639695989':RAW})
        self.assertEqual(notices,())


class PlanePlacement(unittest.TestCase):
    def setUp(self):
        self.root=ET.parse(MISSION/'cfgeventspawns.xml').getroot()
    def test_transfer_two_exact_author_points_preserves_an2_candidate_and_other_events(self):
        before={e.get('name'):ET.tostring(e) for e in self.root if e.get('name')!=lp.SOURCE_EVENT}
        original=[dict(n.attrib) for n in self.root.findall(f"event[@name='{lp.SOURCE_EVENT}']/pos")]
        result=lp.positions(MISSION,self.root)
        self.assertEqual([p.attrib for p in result],[{'x':'3203.92','z':'15690.2','a':'0'},{'x':'12622.1','z':'12224.5','a':'0'}])
        remaining=[n.attrib for n in self.root.findall(f"event[@name='{lp.SOURCE_EVENT}']/pos")]
        self.assertEqual(len(remaining),len(original)-2)
        self.assertIn({'x':'12217.1','z':'11915.7','a':'0'},remaining)
        self.assertTrue(all(p.attrib in original for p in result))
        self.assertTrue(all(p.attrib not in remaining for p in result))
        for e in self.root:
            if e.get('name') in before:self.assertEqual(ET.tostring(e),before[e.get('name')])
    def test_repeat_is_idempotent_and_an2_can_allocate_before_or_after(self):
        groups=ET.parse(MISSION/'mapgrouppos.xml').getroot()
        lp.positions(MISSION,self.root)
        an2position,_=an2._position(self.root,groups)
        self.assertEqual(an2position['x'],'12217.1')
        before=ET.tostring(self.root)
        lp.positions(MISSION,self.root)
        self.assertEqual(before,ET.tostring(self.root))
        other=ET.parse(MISSION/'cfgeventspawns.xml').getroot()
        an2._position(other,groups)
        lp.positions(MISSION,other)
        points=lambda r:[p.attrib for p in r.findall(f"event[@name='{lp.EVENT}']/pos")]
        self.assertEqual(points(other),points(self.root))
    def test_existing_conflict_fails_without_consuming_more_source_sites(self):
        lp.positions(MISSION,self.root)
        point=self.root.find(f"event[@name='{lp.EVENT}']/pos")
        e=ET.SubElement(self.root,'event',name='VehicleSomeOther')
        ET.SubElement(e,'pos',**point.attrib)
        before=ET.tostring(self.root)
        with self.assertRaisesRegex(ValueError,'failed static validation'):lp.positions(MISSION,self.root)
        self.assertEqual(before,ET.tostring(self.root))
    def test_duplicate_source_coordinates_fail_with_explicit_error(self):
        src=self.root.find(f"event[@name='{lp.SOURCE_EVENT}']")
        ET.SubElement(src,'pos',x='3203.92',z='15690.2',a='0')
        with self.assertRaisesRegex(ValueError,'duplicate crash-event'):lp.positions(MISSION,self.root)
        self.assertIsNone(self.root.find(f"event[@name='{lp.EVENT}']"))


class CompletePrepare(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name)
        self.mission=self.base/'mission';shutil.copytree(MISSION,self.mission)
        self.profiles=self.base/'profiles';self.profiles.mkdir()
        self.receipt=self.profiles/'delivery_receipt.json';self.receipt.write_bytes(b'existing go-kart receipt')
        self.save=self.mission/'storage_1/players.db';self.save.parent.mkdir(exist_ok=True);self.save.write_bytes(b'keep save')
        self.mod=self.base/'3639695989';self.mod.mkdir()
        self.mods={'3639695989':self.mod}
        # Existing independently surveyed open-water coordinates; preserve exactly.
        root=ET.parse(self.mission/'cfgeventspawns.xml').getroot()
        e=ET.SubElement(root,'event',name=av.EVENTS['large_water'])
        ET.SubElement(e,'pos',x='4100',z='5500',y='0',a='90')
        (self.mission/'cfgeventspawns.xml').write_bytes(av._bytes(root))
    def test_prepare_all_variants_full_assembly_ce_targets_and_preservation(self):
        with patch.object(av,'load_sites',return_value=None):av.prepare(self.mission,self.profiles,self.mods)
        folder=self.mission/av.FOLDER
        events=ET.parse(folder/'events.xml').getroot()
        self.assertEqual(len(events.findall('event/children/child')),12)
        self.assertEqual([(e.get('name'),e.findtext('nominal')) for e in events],[(av.EVENTS['large_water'],'1'),(av.EVENTS['plane'],'1')])
        spawn=ET.parse(folder/'spawnabletypes.xml').getroot()
        self.assertEqual(len(spawn),12)
        for node in spawn:
            self.assertTrue(all(g.get('chance')=='1.00' and len(g)==1 for g in node.findall('attachments')))
        types=ET.parse(folder/'types.xml').getroot()
        for node in types:
            if node.get('name').startswith('LM_Catalina_Wheel'):self.assertEqual(node.findtext('nominal'),'0')
        self.assertEqual(self.receipt.read_bytes(),b'existing go-kart receipt')
        self.assertEqual(self.save.read_bytes(),b'keep save')
        files=[folder/(k+'.xml') for k in ('types','events','spawnabletypes')]+[self.mission/'cfgeventspawns.xml',self.mission/'cfgeconomycore.xml']
        before={p:p.read_bytes() for p in files}
        with patch.object(av,'load_sites',return_value=None):av.prepare(self.mission,self.profiles,self.mods)
        self.assertEqual(before,{p:p.read_bytes() for p in files})
    def test_failed_transaction_restores_crash_positions_core_and_save(self):
        before={name:(self.mission/name).read_bytes() for name in ('cfgeventspawns.xml','cfgeconomycore.xml')}
        with patch.object(av,'load_sites',return_value=None),patch.object(av,'register_bytes',side_effect=ValueError('simulated write failure')):
            with self.assertRaisesRegex(ValueError,'simulated write failure'):av.prepare(self.mission,self.profiles,self.mods)
        self.assertEqual(before,{name:(self.mission/name).read_bytes() for name in before})
        self.assertEqual(self.save.read_bytes(),b'keep save')


if __name__=='__main__':unittest.main()
