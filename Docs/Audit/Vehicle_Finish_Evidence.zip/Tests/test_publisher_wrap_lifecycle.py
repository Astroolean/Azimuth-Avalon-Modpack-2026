"""Actual publisher callback audit and extracted cleanup adapter checks.

The C++ harness preserves the inspected EEDelete bodies and generated adapter
calls. It is not a native DayZ or Enforce execution claim.
"""
from pathlib import Path
from hashlib import sha256
import json
import os
import re
import subprocess
import sys
import tempfile
import unittest

TASK = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('AZIMUTH_TEST_ROOT', TASK/'package/Azimuth')).resolve()
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT/'Engine'))
from azimuth_app.cosmetics import publisher_wrap_lifecycle as lifecycle
from azimuth_app.cosmetics import random_skin_mode

LM = TASK/'research/lm/raw'
PLANE = LM/'Scripts/4_World/entities/LlamaPlaneScript.c'
SEA = LM/'Scripts/4_World/entities/LlamaSeaPlaneScript.c'
CALLBACKS = ('EEInit','AfterStoreLoad','EEOnAfterLoad','OnVariablesSynchronized',
             'EEHealthLevelChanged','EEItemAttached','EEItemDetached','EEDelete')


def stripped(text):
    return re.sub(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"',
                  lambda m: ''.join('\n' if c=='\n' else ' ' for c in m.group()), text)


def closing(text, at):
    depth = 1
    at += 1
    while depth:
        depth += (text[at]=='{') - (text[at]=='}')
        at += 1
    return at


def method_body(text, name):
    clean = stripped(text)
    match = re.search(r'\b(?:override\s+)?void\s+' + name + r'\s*\([^)]*\)\s*\{', clean)
    if match is None:
        raise ValueError('Missing inspected method: ' + name)
    return text[match.end():closing(clean,match.end()-1)-1]


class PublisherWrapLifecycleTests(unittest.TestCase):
    def test_uploaded_vehicle_callbacks_reach_parent_hooks(self):
        manifest = json.loads((TASK/'input/assets/Vehicle_Repair_Files.json').read_text())
        found = []
        omissions = []
        scripts = 0
        for row in manifest['files']:
            if row.get('kind') != 'script' or row.get('status') != 'copied':
                continue
            scripts += 1
            path = TASK/'input/assets'/row['export_path']
            raw = path.read_bytes()
            self.assertEqual(row['sha256'],sha256(raw).hexdigest())
            text = stripped(raw.decode('utf-8-sig'))
            classes = []
            for m in re.finditer(r'\b(?:modded\s+)?class\s+(\w+)\s*(?:(?::|extends)\s*(\w+))?\s*\{',text):
                try:
                    end = closing(text,m.end()-1)
                except IndexError:
                    # These publisher files have two preprocessor alternatives
                    # for the 1.29/1.30 OnCE method header, sharing one tail.
                    # Both raw branches have an opening brace; this source
                    # inventory is deliberately not a native preprocessor.
                    self.assertIn(m[1], {'ExpansionGarageVehicle','BoatScript','CarScript'})
                    self.assertIn('#ifndef DAYZ_1_29',text)
                    end = len(text)
                classes.append((m.start(),end,m[1],m[2]))
            for m in re.finditer(r'\b(?:override\s+)?void\s+('+'|'.join(CALLBACKS)+r')\s*\([^)]*\)\s*\{',text):
                owner = next((c for c in reversed(classes) if c[0]<m.start()<c[1]),None)
                if owner is None:
                    continue
                found.append((owner[2],m[1]))
                body = text[m.end():closing(text,m.end()-1)]
                if not re.search(r'\bsuper\s*\.\s*'+m[1]+r'\s*\(',body):
                    omissions.append((owner[2],owner[3],m[1]))
        self.assertEqual(663,scripts)
        self.assertEqual(164,len(found))
        self.assertEqual({('land_metro_OilRig','BuildingSuper','EEDelete'),
                          ('Land_waterfall_dego','BuildingSuper','EEDelete'),
                          ('ExpansionHelicopterWreck','ExpansionWreck','EEDelete')},set(omissions))

    def test_lm_public_classes_addons_and_missing_base_cleanup_are_actual(self):
        declarations = set()
        for path in (LM/'Scripts/4_World/entities/vehicles/inherited/Planes').glob('*.c'):
            declarations.update(re.findall(r'\bclass\s+(LM_\w+)\s+extends\b',path.read_text()))
        self.assertEqual(set(lifecycle.PUBLIC_CLASSES),declarations)
        source = '\n'.join(p.read_text() for p in LM.rglob('config.cpp'))
        for name in lifecycle.REQUIRED_ADDONS:
            self.assertRegex(source,rf'class\s+CfgPatches\s*\{{\s*class\s+{name}\b')
        self.assertNotIn('super.EEDelete',method_body(PLANE.read_text(),'EEDelete'))
        self.assertIn('super.EEDelete',method_body(SEA.read_text(),'EEDelete'))
        self.assertIn('super.EEInit',method_body(PLANE.read_text(),'EEInit'))

    def test_disabled_mod_adds_no_type_references_and_duplicate_config_is_rejected(self):
        source = (ROOT/random_skin_mode.SOURCE/'config.cpp').read_text()
        self.assertEqual({},lifecycle.script_files(()))
        self.assertEqual(source,lifecycle.apply_config(source,('3387855369',)))
        configured = lifecycle.apply_config(source,(lifecycle.WORKSHOP_ID,))
        with self.assertRaises(ValueError):
            lifecycle.apply_config(configured,(lifecycle.WORKSHOP_ID,))
        with self.assertRaises(ValueError):
            lifecycle.apply_config('class Wrong {};',(lifecycle.WORKSHOP_ID,))

    def test_real_builder_packages_only_active_lm_adapters_and_dependencies(self):
        inactive = random_skin_mode.source_files(ROOT/random_skin_mode.SOURCE,root=ROOT)
        active = random_skin_mode.source_files(ROOT/random_skin_mode.SOURCE,root=ROOT,
                                              active_vehicle_ids=iter((lifecycle.WORKSHOP_ID,)))
        self.assertNotIn(lifecycle.SCRIPT,inactive)
        self.assertIn(lifecycle.SCRIPT,active)
        text = active[lifecycle.SCRIPT].decode()
        self.assertEqual(set(lifecycle.PUBLIC_CLASSES),set(re.findall(r'modded class (\w+)',text)))
        self.assertNotIn('gdukq_',text)
        self.assertEqual(len(lifecycle.PUBLIC_CLASSES),text.count('AzimuthVehicleWrapCleanup();'))
        self.assertIn(lifecycle.PATCH,active['config.cpp'].decode())
        self.assertLessEqual(sum(map(len,active.values())),random_skin_mode.MAX_SOURCE_BYTES)

    def test_extracted_adapter_clears_queued_work_and_preserves_both_publisher_deletes(self):
        plane_body = method_body(PLANE.read_text(),'EEDelete')
        sea_body = method_body(SEA.read_text(),'EEDelete').replace('super.EEDelete','PublisherPlane::EEDelete')
        sea_cleanup = method_body(SEA.read_text(),'CleanupEffects').replace('super.CleanupEffects','PublisherPlane::CleanupEffects')
        generated = lifecycle.script_files((lifecycle.WORKSHOP_ID,))[lifecycle.SCRIPT].decode()
        cpp = r'''
#include <stdexcept>
struct Game { bool dedicated = false; bool IsDedicatedServer() { return dedicated; } } g_Game;
using EntityAI = int;
class CarScript { public:
    bool resolveQueued=true, renderQueued=true; int cleanup=0, effects=0, water=0;
    virtual ~CarScript() = default;
    void AzimuthVehicleWrapCleanup() { resolveQueued=false; renderQueued=false; ++cleanup; }
    virtual void EEDelete(EntityAI) { AzimuthVehicleWrapCleanup(); }
};
class PublisherPlane : public CarScript { public:
    virtual void CleanupEffects() { ++effects; }
    void EEDelete(EntityAI parent) override { PLANE_BODY }
};
class PublisherSea : public PublisherPlane { public:
    void gdukq_tkaaaa() { ++water; }
    void CleanupEffects() override { SEA_CLEANUP }
    void EEDelete(EntityAI parent) override { SEA_BODY }
};
'''.replace('PLANE_BODY',plane_body).replace('SEA_BODY',sea_body).replace('SEA_CLEANUP',sea_cleanup)
        sea_classes = {'LM_Catalina','LM_Patty_Wagon','LM_Tigermoth_MK3'}
        for name in lifecycle.PUBLIC_CLASSES:
            match = re.search(r'modded class '+name+r'\s*\{',generated)
            block = generated[match.end():closing(generated,match.end()-1)-1]
            parent = 'PublisherSea' if name in sea_classes else 'PublisherPlane'
            block = block.replace('override void EEDelete(EntityAI parent)','void EEDelete(EntityAI parent) override')
            block = block.replace('super.EEDelete',parent+'::EEDelete')
            cpp += f'class {name} : public {parent} {{ public: {block} }};\n'
        cpp += 'int main() {\n'
        for dedicated in ('false','true'):
            cpp += 'g_Game.dedicated='+dedicated+';\n'
            for name in lifecycle.PUBLIC_CLASSES:
                parent = 'PublisherSea' if name in sea_classes else 'PublisherPlane'
                cpp += f'''{{ {parent} before; {name} after;
before.EEDelete(0); after.EEDelete(0);
if (!before.resolveQueued || !before.renderQueued || after.resolveQueued || after.renderQueued) throw std::runtime_error("callback ownership");
if (after.cleanup != 1 || before.effects != after.effects || before.water != after.water) throw std::runtime_error("publisher cleanup changed");
after.EEDelete(0); if (after.resolveQueued || after.renderQueued) throw std::runtime_error("repeat cleanup");
}}\n'''
        cpp += 'return 0; }\n'
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder); source = path/'callbacks.cpp'; binary = path/'callbacks'
            source.write_text(cpp)
            compiled = subprocess.run(['g++','-std=c++17','-O0','-fsanitize=undefined','-fno-sanitize-recover=all',str(source),'-o',str(binary)],capture_output=True,text=True)
            self.assertEqual(0,compiled.returncode,compiled.stderr)
            executed = subprocess.run([str(binary)],capture_output=True,text=True)
            self.assertEqual(0,executed.returncode,executed.stdout+executed.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
