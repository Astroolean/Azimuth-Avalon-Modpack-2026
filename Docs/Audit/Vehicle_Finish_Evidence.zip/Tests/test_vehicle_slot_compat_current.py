"""Retained slot tests adapted for model-compatibility composition.

Original suite remains in vehicle_integration/Tests/test_vehicle_slot_compat.py.
Only the former cargo-only aggregate expectations changed; exact slot and
load-order assertions remain. No native DayZ execution claim.
"""
import json,os,pathlib,sys,tempfile,unittest
BASE=pathlib.Path(__file__).resolve().parents[1]
ROOT=pathlib.Path(os.environ.get('AZIMUTH_TEST_ROOT',BASE/'package/Azimuth'))
sys.path.insert(0,str(ROOT/'Engine'))
sys.path.insert(0,str(BASE.parent/'vehicle_integration/research/tools'))
from azimuth_app.transport import vehicle_slot_compat as compat
from decode_config import Text
from config_index import ConfigIndex,load_records

class SlotCompatTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.data=json.loads((ROOT/compat.DATA).read_text());cls.records=load_records()
  cls.original=(ROOT/'Custom/GunSkins/RandomSkins/azimuthrandomskins/config.cpp').read_text()
 def test_empty_and_irrelevant_active_are_noop(self):
  self.assertEqual(compat.config_fragment(ROOT,[]),'')
  self.assertEqual(compat.config_fragment(ROOT,['3456445155']),'')
  self.assertEqual(compat.apply_config(self.original,ROOT,['3456445155']),self.original)
 def test_no_cargo_replacement_preserves_only_verified_model_repairs(self):
  self.assertEqual(compat._render_slot_parts(ROOT,['2880254695']),('',''))
  d=Text(compat.config_fragment(ROOT,['2880254695'])).decode()['root']
  self.assertEqual(set(d['classes']['CfgPatches']['classes']),{'Azimuth_VehicleWrapModelCompatibility'})
  self.assert_model_repairs(d['classes']['CfgVehicles']['classes'])
  self.assertEqual(compat._render_slot_parts(ROOT,['3387855369','3225634444']),('',''))
 def assert_model_repairs(self, classes):
  expected={
   'rag_gaz69':('rag_gaz69_base',['dmgzone_back','dmgzone_fender_1_1','dmgzone_fender_2_1','dmgzone_fender_1_2','dmgzone_fender_2_2']),
   'rag_gaz69_hood':('CarDoor',['dmgzone_front']),
   'rag_schoolbus':('rag_schoolbus_base',['dmgzone_front','dmgzone_back','dmgzone_roof','dmgzone_fender_1_1','dmgzone_fender_2_1','dmgzone_fender_1_2','dmgzone_fender_2_2','dmgzone_chassis']),
   'rag_schoolbus_czech':('rag_schoolbus_base',['dmgzone_front','dmgzone_back','dmgzone_roof','dmgzone_fender_1_1','dmgzone_fender_2_1','dmgzone_fender_1_2','dmgzone_fender_2_2','dmgzone_chassis']),
  }
  self.assertEqual(set(classes),set(expected))
  for name,(parent,selections) in expected.items():
   c=classes[name]
   self.assertEqual(c['parent'],parent)
   self.assertEqual(c['properties'],{'hiddenSelections':selections})
   self.assertEqual(c['classes'],{})
   self.assertEqual(len(c['entries']),1)
   self.assertTrue(c['entries'][0]['append'])
 def test_only_replacer_no_lost_slots_no_patch(self):
  self.assertEqual(compat.config_fragment(ROOT,['2651195301']),'')
  self.assertEqual(compat.config_fragment(ROOT,['3834034916']),'')
 def test_gas_can_repair_exact_missing_slots(self):
  d=Text(compat.config_fragment(ROOT,['2880254695','2651195301'])).decode()['root']
  v=d['classes']['CfgVehicles'];self.assertEqual(set(v['classes']),{'CanisterGasoline','rag_gaz69','rag_gaz69_hood','rag_schoolbus','rag_schoolbus_czech'})
  self.assert_model_repairs({k:c for k,c in v['classes'].items() if k!='CanisterGasoline'})
  c=v['classes']['CanisterGasoline'];self.assertEqual(c['parent'],'Bottle_Base')
  self.assertEqual(c['properties']['inventorySlot'],['CanisterGasoline_1','CanisterGasoline_2'])
  self.assertTrue(c['entries'][0]['append'])
  deps=d['classes']['CfgPatches']['classes'][compat.PATCH]['properties']['requiredAddons']
  self.assertIn('Extension_Slots',deps);self.assertIn('rag_baja',deps);self.assertNotIn('An2Mod',deps)
 def test_barrel_repair_avalon_an2(self):
  d=Text(compat.config_fragment(ROOT,['3225634444','3834034916'])).decode()['root']
  c=d['classes']['CfgVehicles']['classes']['Barrel_ColorBase']
  self.assertEqual(c['parent'],'Container_Base');self.assertEqual(c['properties']['inventorySlot'],[f'drumSlot{x}' for x in range(1,7)])
  deps=d['classes']['CfgPatches']['classes'][compat.PATCH]['properties']['requiredAddons']
  self.assertEqual(deps,['An2Mod','RTchevyvan'])
 def test_every_dependency_owned_by_active_id(self):
  active={p['workshop_id'] for row in self.data['classes'] for p in row['providers']}
  for subset in (active,{'2651195301','2880254695'},{'3834034916','3387855369'},{'3834034916','3810689113'}):
   d=Text(compat.config_fragment(ROOT,sorted(subset))).decode()['root']
   deps=d['classes']['CfgPatches']['classes'][compat.PATCH]['properties']['requiredAddons']
   allowed={name for row in self.data['classes'] for p in row['providers'] if p['workshop_id'] in subset for name in p['required_addons']}
   self.assertLessEqual(set(deps),allowed)
   self.assertNotIn('DZ_Vehicles_Parts',deps)
 def test_apply_single_cfgpatches_and_untouched_original(self):
  s=compat.apply_config(self.original,ROOT,['3225634444','3834034916'])
  d=Text(s).decode()['root'];self.assertEqual(sum(e['kind']=='class' and e['name']=='CfgPatches' for e in d['entries']),1)
  before=Text(self.original).decode()['root'];self.assertEqual(before['classes']['CfgMods'],d['classes']['CfgMods'])
  self.assertEqual(before['classes']['CfgPatches']['classes']['Azimuth_RandomSkins'],d['classes']['CfgPatches']['classes']['Azimuth_RandomSkins'])
  with self.assertRaises(ValueError):compat.apply_config(s,ROOT,['3225634444','3834034916'])
 def test_all_config_slot_values_survive_both_provider_orders(self):
  for active in ({'3225634444','3834034916'},{'2651195301','2880254695'},{'3834034916','3387855369'}):
   selected=[(r,n) for r,n in self.records if r['source']=='dayz_client' or (r['source'].startswith('workshop_') and r['source'].split('_')[1] in active)]
   fragment=Text(compat.config_fragment(ROOT,sorted(active))).decode()['root']
   record={'source':'test','archive':'compat','prefix':'compat','input_path':'compat','input_sha256':'test'}
   for seq in (selected,list(reversed(selected))):
    # Native must load first, so only reverse publishers.
    seq=[(r,n) for r,n in seq if r['source']=='dayz_client']+[(r,n) for r,n in seq if r['source']!='dayz_client']
    idx=ConfigIndex(seq+[(record,fragment)])
    for row in self.data['classes']:
     providers=[p for p in row['providers'] if p['workshop_id'] in active]
     if not providers:continue
     expected={s.lower() for p in providers for s in p['slots']}
     props=idx.resolve(row['name'],include_nested=False)['properties'];slots=next((v for k,v in props.items() if k.lower()=='inventoryslot'),[])
     self.assertLessEqual(expected,{s.lower() for s in slots})
 def test_invalid_ids_and_data_rejected(self):
  with self.assertRaises(ValueError):compat.config_fragment(ROOT,['bad";'])
  with tempfile.TemporaryDirectory() as td:
   root=pathlib.Path(td);p=root/compat.DATA;p.parent.mkdir(parents=True)
   data=json.loads(json.dumps(self.data));data['classes'][0]['parent']='WrongBase';p.write_text(json.dumps(data))
   with self.assertRaises(ValueError):compat.config_fragment(root,['3834034916'])
 def test_generated_overrides_only_append_array(self):
  ids={p['workshop_id'] for row in self.data['classes'] for p in row['providers']}
  d=Text(compat.config_fragment(ROOT,sorted(ids))).decode()['root']
  for name,c in d['classes']['CfgVehicles']['classes'].items():
   if name not in compat.PARENTS:continue
   self.assertEqual(set(c['properties']),{'inventorySlot'});self.assertTrue(c['entries'][0]['append'])
   self.assertEqual(c['classes'],{})
if __name__=='__main__':unittest.main(verbosity=2)
