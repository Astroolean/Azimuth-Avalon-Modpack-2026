"""Installed vehicle rules exercised through extracted production C++ adapters.

These checks execute the catalog guards against captured publisher config
fixtures. They are not a native DayZ build, visual, UV, or gameplay test.
"""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import unittest

TASK = Path(__file__).resolve().parents[2] / "vehicle_integration"
WORKSPACE = TASK.parent
ROOT = Path(os.environ.get("AZIMUTH_TEST_ROOT", TASK.parent / "vehicle_finish/package/Azimuth"))
SOURCE = ROOT / "Custom/GunSkins/RandomSkins/azimuthrandomskins/scripts/4_world/azimuth_vehicle_wrap_rules.c"
CATALOG = json.loads((TASK / "research/mappings/installed_wrap_catalog.json").read_text())
# Replace only assumptions disproved/extended by actual compiled model data.
GEOMETRY = json.loads((WORKSPACE / "vehicle_finish/reports/wraps/model_wrap_candidates.json").read_text())
for candidate in GEOMETRY["candidates"]:
    model = candidate["resource"]
    selections = {slot["name"]: [surface["texture"] for surface in slot["surfaces"] if surface["texture"]] for slot in candidate["selections"]}
    if "/proxy/" not in model:
        CATALOG["body_catalog"][model] = selections
    else:
        parents = ["rag/rag_vehicles/rag_gaz69/rag_gaz69.p3d"] if "rag_gaz69" in model else ["motorhome_boss/motorhome_" + color + ".p3d" for color in ("white", "apo", "rust", "greencamo")]
        CATALOG["panel_catalog"][model] = {"parent_models": parents, "selections": selections}
for blocked in GEOMETRY["blocked_main_models"]:
    if blocked["resource"] != "airship/data/airship.p3d":  # Main hull absent, isolated banners remain valid.
        CATALOG["body_catalog"].pop(blocked["resource"], None)
spec = importlib.util.spec_from_file_location("old_vehicle_adapter", WORKSPACE / "vehicle_coverage/Tests/test_vehicle_wrap_rules.py")
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)

MAIN = legacy.MAIN.replace(
    'if(p.at(0)=="B")std::cout<<Rules::BodySelection(&e,p.at(3),p.at(4))<<"\\n";',
    'if(p.at(0)=="S")std::cout<<Rules::BodySelection(&e,p.at(3),p.at(4),false)<<"\\n";'
    'else if(p.at(0)=="B")std::cout<<Rules::BodySelection(&e,p.at(3),p.at(4))<<"\\n";'
)


def translate_rules(source):
    # The old adapter's broad door. -> door-> replacement also touched quoted
    # model filenames ending driverdoor.p3d. Preserve those literal path bytes.
    translated = legacy.translate_methods(source)
    return re.sub(r'"(?:\\.|[^"\\])*"', lambda match: match.group().replace("->", "."), translated)


def body(model, selection, original="publisher_body_co.paa", *, server=False, type_name="InstalledVehicle", hologram=False):
    return ("S" if server else "B", "UnknownKind", model, selection, original, type_name, str(int(hologram)))


def panel(model, parent, selection, original="publisher_panel_co.paa"):
    return ("D", "UnknownKind", parent, selection, original, "InstalledVehicle", "0", model)


class InstalledVehicleRulesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.binary = Path(cls.tmp.name) / "rules"
        cpp = Path(cls.tmp.name) / "rules.cpp"
        cpp.write_text(legacy.ADAPTER + translate_rules(SOURCE.read_text()) + MAIN)
        result = subprocess.run(["g++", "-std=c++17", "-fsanitize=undefined", "-fno-sanitize-recover=all", "-O1", str(cpp), "-o", str(cls.binary)], capture_output=True, text=True, timeout=60)
        if result.returncode:
            raise AssertionError(result.stderr)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def check(self, rows, expected):
        result = subprocess.run([str(self.binary)], input="\n".join("\t".join(row) for row in rows) + "\n", capture_output=True, text=True, timeout=30)
        self.assertEqual(0, result.returncode, result.stderr)
        actual = [int(x) for x in result.stdout.splitlines()]
        self.assertEqual(len(expected), len(actual))
        failures = [(row, want, got) for row, want, got in zip(rows, expected, actual) if bool(want) != bool(got)]
        self.assertEqual([], failures[:10], f"{len(failures)} mapping failures")

    def test_all_captured_body_models_and_declared_slots(self):
        rows = []; expected = []
        for model, selections in CATALOG["body_catalog"].items():
            for name in selections:
                rows.append(body(model, name)); expected.append(True)
                rows.append(body(model, "unrelated_camo")); expected.append(False)
        self.assertGreater(len(rows), 300)
        self.check(rows, expected)

    def test_all_scope_two_variants_use_the_actual_configured_slots(self):
        rows = []; expected = []
        for vehicle in CATALOG["vehicle_classes"]:
            if vehicle["scope"] != 2:
                continue
            approved = CATALOG["body_catalog"].get(vehicle["model"], {})
            for surface in vehicle["declared_surfaces"]:
                # Class name isn't used as a substitute for a correct model.
                rows.append(body(vehicle["model"], surface["selection"], type_name=vehicle["class"]))
                expected.append(surface["selection"] in approved)
        self.assertGreater(len(rows), 5000)
        self.check(rows, expected)

    def test_exact_panel_and_fitted_parent_model_pairs(self):
        rows = []; expected = []
        for model, rule in CATALOG["panel_catalog"].items():
            for parent in rule["parent_models"]:
                for name in rule["selections"]:
                    rows.extend((panel(model, parent, name), panel(model, "unrelated/vehicle.p3d", name)))
                    expected.extend((True, False))
        self.assertGreater(len(rows), 1000)
        self.check(rows, expected)

    def test_blank_only_slots_get_server_ids_without_painting_unreadable_client_slots(self):
        rows = []; expected = []
        for model, selections in CATALOG["body_catalog"].items():
            for name, known in selections.items():
                if known:
                    continue
                rows.extend((body(model, name, "", server=True), body(model, name, ""), body(model, name, "native_body_co.paa"), body(model, name, "native_body_ca.paa")))
                expected.extend((True, False, True, False))
        self.assertEqual(56, len(rows))  # Four cases for each remaining 14 guarded slots.
        self.check(rows, expected)

    def test_all_new_families_keep_glass_interior_lights_and_wheels_original(self):
        protected = ("glass", "window_front", "light_1_1", "light_dashboard", "camo_interior", "body_inside", "wheel", "camo_wheel", "rotor", "antiwater", "screen", "manual_poster", "camo_nomer")
        rows = [body(model, name) for model in CATALOG["body_catalog"] for name in protected]
        self.check(rows, [False] * len(rows))

    def test_unknown_model_substitutions_cannot_inherit_a_whitelist(self):
        rows = []
        for model, selections in CATALOG["body_catalog"].items():
            name = next(iter(selections))
            rows += [body("unrelated/" + model, name), body(model.replace(".p3d", "_other.p3d"), name), body("../" + model, name)]
        self.check(rows, [False] * len(rows))

    def test_model_case_slashes_and_double_separator_variants(self):
        rows = []
        for model, selections in CATALOG["body_catalog"].items():
            rows.append(body("\\" + model.upper().replace("/", "\\\\"), next(iter(selections)).upper()))
        self.check(rows, [True] * len(rows))

    def test_exact_publisher_nonstandard_texture_names_are_allowed_without_extension_wildcards(self):
        # These assets used to be rejected because their author omitted _co.
        allowed = ("Techs_AllTerrainVehicle/Techs_Textures/Tech_Body/Tec_Black.paa", "Ford_Raptor_MonsterTruck/data/f150_sign_1.paa", "Ford_Bronco_XLT/data/bronco_blue.pac", "ChevyVan/data/black_base.paa")
        rejected = ("othermod/Tec_Black.paa", "Techs_AllTerrainVehicle/Techs_Textures/Tech_Body/Tec_Black_ca.paa", "Spur_TrolleyKart/data/Kart_cart_enge_1_diffuse.paa", "Expansion/unknown.pac", "native_body_ca.paa", "#(argb,8,8,3)color(0,0,0,0,co)")
        self.check([("T", p) for p in allowed + rejected], [True] * len(allowed) + [False] * len(rejected))

    def test_focused_gokart_humvee_bicycle_boat_scooter_and_aircraft_surfaces(self):
        cases = (
            ("mbm_gokart/gokart.p3d", "camo"),
            ("tb_golfcart/tb_golfcart.p3d", "camo"),
            ("dz/vehicles/wheeled/offroad_02/offroad_02.p3d", "camo_roof"),
            ("bicycle/model2/bicycle.p3d", "camo1"),
            ("bicycle/model2/lady_bicycle.p3d", "camo1"),
            ("dz/vehicles/singletrack/motorbike_01/motorbike_01.p3d", "camo_fender"),
            ("dz/vehicles/singletrack/motorbike_02/motorbike_02.p3d", "camo_fenderrear"),
            ("dz/vehicles/water/boat_01/boat_01.p3d", "camo1"),
            ("crsk_vespa_125_primavera/crsk_vespa_125_primavera.p3d", "camo2"),
            ("extension_helicopters/ch47/ch_47f.p3d", "camo2"),
            ("dayzexpansion/vehicles/air/mh6/mh6.p3d", "camo"),
            ("extension_helicopters/mh-6/mh_6m.p3d", "camo"),
            ("van_rhib/van_rhib.p3d", "camo1"),
            ("an2mod/an2.p3d", "camo3"),
        )
        self.check([body(*case) for case in cases], [True] * len(cases))

    def test_native_shield_parts_follow_only_their_own_bitrak_body(self):
        parent = "dz/vehicles/singletrack/motorbike_02/motorbike_02.p3d"
        models = ["dz/vehicles/singletrack/motorbike_02/proxy/" + name + ".p3d" for name in ("motorbike_02_windshield", "motorbike_02_shieldleft", "motorbike_02_shieldright")]
        self.check([panel(model, parent, "camo") for model in models], [True] * 3)
        self.check([panel(model, "dz/vehicles/singletrack/motorbike_01/motorbike_01.p3d", "camo") for model in models], [False] * 3)

    def test_unsupported_models_are_not_claimed_as_repaintable(self):
        self.check([
            body("rtrzr/rtrzr.p3d", "camo"),
            body("armabicycles/model/old_bike.p3d", "camo"),
            body("dayzexpansion/vehicles/water/zodiac/zodiac.p3d", "camo", "zodiac_ca.paa"),
            body("dayzexpansion/vehicles/ground/vodnik/vodnik.p3d", "med"),
            body("dayzexpansion/vehicles/air/gyro/gyrocopter.p3d", "camo"),
        ], [False, False, False, False, True])
        self.assertTrue((WORKSPACE / "vehicle_finish/reports/wraps/lm_model_geometry.json").is_file())

    def test_existing_blue_gunter_blank_texture_support_is_preserved(self):
        self.check([body("dz/vehicles/wheeled/hatchback_02/hatchback_02.p3d", "camo_chassi", "", type_name="Hatchback_02_Blue")], [True])

    def test_every_reported_vehicle_reaches_an_actual_hook_and_parts_do_not_include_wheels(self):
        for row in CATALOG["vehicle_classes"]:
            self.assertIn(row["script_transport_base"], ("CarScript", "BoatScript", "MotorbikeScript"), row["class"])
        for model in CATALOG["panel_catalog"]:
            self.assertFalse(any(x in model.rsplit("/", 1)[-1] for x in ("wheel", "licenseplate", "licenceplate")), model)
        self.assertIn("s_Coverage.Count() >= 4096", SOURCE.read_text())

    def test_actual_fitted_panel_eligibility_and_server_client_readback_separation(self):
        adapter = legacy.ADAPTER.replace(
            "string GetType(){return type;}",
            "std::vector<Entity*> fitted; Entity* GetInventory(){return this;} "
            "int AttachmentCount(){return int(fitted.size());} "
            "Entity* GetAttachmentFromIndex(int i){return fitted.at(i);} "
            "string GetType(){return type;}"
        )
        adapter += r'''
struct CarDoor {static Entity* Cast(Entity* p){return p&&p->kind=="CarDoor"?p:nullptr;}};
struct MotorbikePart {static Entity* Cast(Entity* p){return p&&p->kind=="MotorbikePart"?p:nullptr;}};
'''
        helpers = []
        for name in ("HasMappedBody", "HasMappedPanel"):
            code = legacy.extract_method(SOURCE.read_text(), name)
            code = code.replace("ref array<string>", "Array<string>*").replace("new array<string>()", "new Array<string>()")
            for array in ("names", "textures"):
                code = code.replace(array + ".", array + "->")
                code = re.sub(r"\b" + array + r"\[([^\]]+)\]", r"(*" + array + r")[\1]", code)
            for entity in ("entity", "vehicle", "part"):
                code = code.replace(entity + ".", entity + "->")
            code = code.replace("GetInventory().", "GetInventory()->").replace("CarDoor.Cast", "CarDoor::Cast").replace("MotorbikePart.Cast", "MotorbikePart::Cast")
            helpers.append(code)
        translated = translate_rules(SOURCE.read_text()).rsplit("};", 1)[0] + "\n" + "\n".join(helpers) + "\n};\n"
        main = r'''
int main(){
    Entity yacht{"BoatScript","van_yacht/van_yacht.p3d","Van_Yacht"};
    yacht.names={"camo2"};yacht.defaults={""};
    if(Rules::HasMappedBody(&yacht))return 11;
    if(Rules::BodySelection(&yacht,"camo2",""))return 12;
    if(Rules::BodySelection(&yacht,"camo2","yacht_body_co.paa"))return 13;
    if(Rules::BodySelection(&yacht,"camo2","yacht_glass_ca.paa"))return 14;
    Entity heli{"CarScript","extension_helicopters/ka60/ka60_pmc.p3d","EXT_KA60"};
    Entity door{"CarDoor","extension_helicopters/ka60/proxy/ka60_doors_2_1.p3d","EXT_KA60_Door"};
    door.names={"camo1"};door.defaults={"extension_helicopters/ka60/data/ka60_ext_co.paa"};
    if(Rules::HasMappedBody(&heli)||Rules::HasMappedPanel(&heli))return 21;
    heli.fitted={&door};
    if(!Rules::HasMappedPanel(&heli))return 22;
    door.kind="Inventory_Base";
    if(Rules::HasMappedPanel(&heli))return 23;
    door.kind="CarDoor";heli.model="unrelated/helicopter.p3d";
    if(Rules::HasMappedPanel(&heli))return 24;
    Entity bike{"MotorbikeScript","dz/vehicles/singletrack/motorbike_02/motorbike_02.p3d","Motorbike_02_Red"};
    Entity shield{"MotorbikePart","dz/vehicles/singletrack/motorbike_02/proxy/motorbike_02_windshield.p3d","Motorbike_02_ShieldFront_Red"};
    shield.names={"camo"};shield.defaults={"dz/vehicles/singletrack/motorbike_02/data/motorbike_02_windshield_red_co.paa"};
    bike.fitted={&shield};if(!Rules::HasMappedPanel(&bike))return 31;
    bike.fitted.clear();if(Rules::HasMappedPanel(&bike))return 32;
    if(Rules::HasMappedBody(nullptr)||Rules::HasMappedPanel(nullptr))return 41;
    return 0;
}
'''
        cpp = Path(self.tmp.name) / "fitted.cpp"
        binary = Path(self.tmp.name) / "fitted"
        cpp.write_text(adapter + translated + main)
        build = subprocess.run(["g++", "-std=c++17", "-fsanitize=undefined", "-fno-sanitize-recover=all", str(cpp), "-o", str(binary)], capture_output=True, text=True, timeout=60)
        self.assertEqual(0, build.returncode, build.stderr)
        run = subprocess.run([str(binary)], capture_output=True, text=True, timeout=10)
        self.assertEqual(0, run.returncode, f"Fitted part/server-client separation scenario failed: {run.returncode} {run.stderr}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
