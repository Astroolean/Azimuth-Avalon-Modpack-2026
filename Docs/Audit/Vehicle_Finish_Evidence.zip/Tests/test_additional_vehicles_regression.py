import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch
from xml.etree import ElementTree as ET

BASE = Path(__file__).resolve().parents[2] / "vehicle_integration"
ROOT = Path(os.environ.get('AZIMUTH_TEST_ROOT', str(Path(__file__).resolve().parents[1] / "package/Azimuth")))
sys.path.insert(0, str(ROOT / 'Engine'))
from azimuth_app.transport import additional_vehicles as av


class CatalogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = av._catalog()
        cls.packs = {p['id']: p for p in cls.data['packs']}

    def test_all_catalog_parts_fit_declared_slots_and_no_duplicate_vehicle_names(self):
        names = [v['class'].lower() for p in self.data['packs'] for v in p['vehicles']]
        self.assertEqual(len(names), len(set(names)))
        self.assertGreater(len(names), 500)

    def test_gokart_four_wheels_and_no_gunter_parts_or_guessed_radiator(self):
        v = next(v for v in self.packs['3456445155']['vehicles'] if v['class'] == 'MBM_GoKart_Blue')
        self.assertEqual(len(v['wheel_slots']), 4)
        self.assertEqual(sum(a['class'] == 'MBM_GoKart_wheel_Black' for a in v['attachments']), 4)
        self.assertFalse(any(a['class'] == 'CarRadiator' or 'Hatchback_02' in a['class'] for a in v['attachments']))
        groups = av._spawnable(v).findall('attachments')
        self.assertEqual(len(groups), len(v['attachments']))
        self.assertTrue(all(len(g.findall('item')) == 1 for g in groups))

    def test_vespa_russian_wheel_slot_names_are_fitted(self):
        for v in self.packs['3830162428']['vehicles']:
            parts = {a['slot']: a['class'] for a in v['attachments']}
            self.assertEqual(parts['Vespa125P_koleso_1'], 'Vespa125P_koleso')
            self.assertEqual(parts['Vespa125P_koleso_2'], 'Vespa125P_koleso')

    def test_required_wheel_slots_fitted_for_every_variant(self):
        for pack in self.data['packs']:
            for v in pack['vehicles']:
                if pack['id'] == '3810689113' and v['class'] == 'Airship':
                    self.assertEqual(v['assembly'], 'publisher_on_spawn')
                    self.assertEqual(v['assembly_evidence']['source'], 'https://steamcommunity.com/sharedfiles/filedetails/?id=3810689113')
                    continue
                attached = {p['slot'].lower() for p in v['attachments']}
                self.assertTrue({s.lower() for s in v.get('wheel_slots', [])} <= attached, v['class'])

    def test_all_galleons_receive_sail_and_keep_large_water_route(self):
        for v in self.packs['3706032797']['vehicles']:
            self.assertEqual(v['route'], 'large_water')
            self.assertTrue(any(a['slot'] == 'Van_Galleon_Sail' for a in v['attachments']))

    def test_decoded_planes_are_active_and_admin_variants_not_in_random_pools(self):
        self.assertIn('3639695989', av.READY_IDS)
        self.assertTrue(self.packs['3639695989']['load'])
        for pack in self.data['packs']:
            for v in pack['vehicles']:
                self.assertNotIn('admin', v['class'].lower())
                self.assertNotIn('static', v['class'].lower())

    def test_per_child_minimum_does_not_force_hundreds_of_vehicles(self):
        rows = [v for p in self.data['packs'] for v in p['vehicles'] if v['route'] == 'road']
        event = av._event('road', rows, 10)
        self.assertGreater(len(rows), 300)
        self.assertEqual(event.findtext('nominal'), '10')
        self.assertTrue(all(c.get('min') == '0' for c in event.findall('children/child')))


class PreparationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.mission = self.folder / 'mission'
        self.mission.mkdir()
        (self.mission / 'db').mkdir()
        (self.mission / 'db/types.xml').write_text('<types/>')
        (self.mission / 'db/events.xml').write_text('<events/>')
        (self.mission / 'cfgspawnabletypes.xml').write_text('<spawnabletypes/>')
        (self.mission / 'cfgeconomycore.xml').write_bytes(b'\xef\xbb\xbf<?xml version="1.0" encoding="utf-8"?><economycore><classes><rootclass name="CarScript" act="car" reportMemoryLOD="no"/></classes></economycore>')
        (self.mission / 'cfgeventspawns.xml').write_text('<eventposdef><event name="VehicleOffroadHatchback"><pos x="18001" z="7501" a="5"/><pos x="18002" z="7502" a="6"/><pos x="18003" z="7503" a="7"/></event><event name="VehicleTruck01"><pos x="999" z="999"/></event><event name="VehicleBoat"><pos x="200" z="300"/></event></eventposdef>')
        self.profiles = self.folder / 'profiles'
        self.profiles.mkdir()
        self.sentinel = self.profiles / 'existing_car_receipt.json'
        self.sentinel.write_bytes(b'Gunter already delivered\x00unchanged')
        self.save = self.mission / 'storage_1'
        self.save.mkdir()
        (self.save / 'players.db').write_bytes(b'preserve players')
        self.mods = {}
        for ident in ('3456445155', '3830162428', '3354681846', '3706032797'):
            p = self.folder / ident
            p.mkdir()
            self.mods[ident] = p
        self.sites = patch.object(av, 'load_sites', return_value=None)
        self.sites.start()
        self.addCleanup(self.sites.stop)

    def read_output(self, name):
        return ET.parse(self.mission / av.FOLDER / (name + '.xml')).getroot()

    def test_real_prepare_preserves_save_and_old_receipt_and_registers_bike_boat(self):
        av.prepare(self.mission, self.profiles, self.mods)
        self.assertEqual(self.sentinel.read_bytes(), b'Gunter already delivered\x00unchanged')
        self.assertEqual((self.save / 'players.db').read_bytes(), b'preserve players')
        core = ET.parse(self.mission / 'cfgeconomycore.xml').getroot()
        roots = {n.get('name'): n.get('act') for n in core.findall('classes/rootclass')}
        self.assertEqual(roots, {'CarScript': 'car', 'BoatScript': 'car', 'MotorbikeScript': 'car'})
        self.assertEqual(len(core.findall(f"ce[@folder='{av.FOLDER}']")), 1)
        events = self.read_output('events')
        self.assertEqual({e.get('name') for e in events}, {av.EVENTS['light'], av.EVENTS['water']})
        self.assertNotIn('Van_Galleon', {c.get('type') for c in events.findall('event/children/child')})
        types = {n.get('name') for n in self.read_output('types')}
        self.assertIn('Van_Galleon', types)

    def test_idempotent_prepare_and_event_coordinates_are_authored(self):
        av.prepare(self.mission, self.profiles, self.mods)
        files = [self.mission / av.FOLDER / (kind + '.xml') for kind in ('types', 'events', 'spawnabletypes')]
        files += [self.mission / 'cfgeconomycore.xml', self.mission / 'cfgeventspawns.xml']
        before = {p: p.read_bytes() for p in files}
        av.prepare(self.mission, self.profiles, self.mods)
        self.assertEqual(before, {p: p.read_bytes() for p in files})
        root = ET.parse(self.mission / 'cfgeventspawns.xml').getroot()
        self.assertEqual({p.get('x') for p in root.findall(f"event[@name='{av.EVENTS['light']}']/pos")}, {'18001', '18002', '18003'})
        self.assertEqual(root.find("event[@name='VehicleTruck01']/pos").get('x'), '999')

    def test_truck_never_uses_disabled_template_coordinates(self):
        _, _, points, _ = av._positions(self.mission, {'truck'})
        self.assertEqual({p.get('x') for p in points['truck']}, {'18001', '18002', '18003'})

    def test_large_boat_requires_its_own_authored_list(self):
        p = self.mission / 'cfgeventspawns.xml'
        root = ET.parse(p).getroot()
        event = ET.SubElement(root, 'event', name=av.EVENTS['large_water'])
        ET.SubElement(event, 'pos', x='1000', z='2000', y='0', a='90')
        p.write_bytes(av._bytes(root))
        av.prepare(self.mission, self.profiles, self.mods)
        events = self.read_output('events')
        large = events.find(f"event[@name='{av.EVENTS['large_water']}']")
        self.assertIsNotNone(large)
        self.assertEqual(large.findtext('nominal'), '1')
        root = ET.parse(p).getroot()
        self.assertEqual(root.find(f"event[@name='{av.EVENTS['large_water']}']/pos").attrib, {'x': '1000', 'z': '2000', 'y': '0', 'a': '90'})

    def test_failed_registration_restores_exact_core_and_positions(self):
        files = [self.mission / 'cfgeconomycore.xml', self.mission / 'cfgeventspawns.xml']
        before = {p: p.read_bytes() for p in files}
        with patch.object(av, 'register_bytes', side_effect=ValueError('deliberate collision')):
            with self.assertRaisesRegex(ValueError, 'deliberate collision'):
                av.prepare(self.mission, self.profiles, self.mods)
        self.assertEqual(before, {p: p.read_bytes() for p in files})
        self.assertFalse((self.profiles / 'Azimuth/Additional_Vehicle_Transport_Audit.json').exists())

    def test_failed_saved_record_write_rolls_back_all_new_ce_files(self):
        files = [self.mission / 'cfgeconomycore.xml', self.mission / 'cfgeventspawns.xml']
        before = {p: p.read_bytes() for p in files}
        real_write = av.atomic_text
        def fail_report(path, text):
            if path.name == 'Additional_Vehicle_Transport_Audit.json':
                raise OSError('record write failure')
            return real_write(path, text)
        with patch.object(av, 'atomic_text', side_effect=fail_report):
            with self.assertRaisesRegex(OSError, 'record write failure'):
                av.prepare(self.mission, self.profiles, self.mods)
        self.assertEqual(before, {p: p.read_bytes() for p in files})
        self.assertFalse((self.mission / av.FOLDER / 'types.xml').exists())
        self.assertFalse((self.mission / av.FOLDER / 'events.xml').exists())
        self.assertFalse((self.mission / av.FOLDER / 'spawnabletypes.xml').exists())

    def test_missing_saved_pack_blocks_without_any_mutation(self):
        av.prepare(self.mission, self.profiles, self.mods)
        files = [p for p in self.folder.rglob('*') if p.is_file()]
        before = {p: p.read_bytes() for p in files}
        missing = dict(self.mods)
        del missing['3456445155']
        with self.assertRaisesRegex(ValueError, 'This save previously used MBM Go-Kart'):
            av.prepare(self.mission, self.profiles, missing)
        self.assertEqual(before, {p: p.read_bytes() for p in files})

    def test_invalid_saved_pack_record_blocks_instead_of_overwriting(self):
        p = self.profiles / 'Azimuth/Additional_Vehicle_Transport_Audit.json'
        p.parent.mkdir()
        p.write_text('{broken')
        with self.assertRaisesRegex(ValueError, 'record is invalid'):
            av.require_saved_packs(self.profiles, self.mods)
        self.assertEqual(p.read_text(), '{broken')


if __name__ == '__main__':
    unittest.main()
