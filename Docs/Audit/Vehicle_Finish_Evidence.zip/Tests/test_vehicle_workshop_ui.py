"""Exercise real Workshop callbacks with a headless widget adapter.

This checks UI structure and callback flow, not native Tk rendering or Steam.
"""
from __future__ import annotations

import os
from pathlib import Path
from queue import Queue
import sys
from types import MethodType, SimpleNamespace
import unittest
from unittest.mock import Mock, patch

TASK = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get("AZIMUTH_TEST_ROOT", TASK / "package/Azimuth")).resolve()
sys.path.insert(0, str(ROOT / "Engine"))
from azimuth_app.ui import dashboard_workshop, dashboard as dashboard_module
from azimuth_app.transport import vehicle_workshop


class Widget:
    labels = []

    def __init__(self, parent=None, *args, **options):
        self.options = dict(options)
        self.children = []
        self.manager = ""
        self.bindings = {}
        self.drawings = []
        if hasattr(parent, "children") and isinstance(parent.children, list):
            parent.children.append(self)
        if "text" in options:
            self.labels.append(options["text"])

    def pack(self, **_options): self.manager = "pack"
    def pack_forget(self): self.manager = ""
    def winfo_manager(self): return self.manager
    def configure(self, **options): self.options.update(options)
    def bind(self, name, command): self.bindings[name] = command
    def winfo_children(self): return self.children
    def winfo_width(self): return 400
    def delete(self, _tag): self.drawings.clear()
    def create_rectangle(self, *args, **options): self.drawings.append((args, options))
    def create_window(self, *args, **options): return 1
    def itemconfigure(self, *args, **options): pass
    def bbox(self, *_args): return (0, 0, 500, 1000)
    def yview(self, *_args): pass
    def yview_scroll(self, *_args): pass
    def set(self, *_args): pass


class VehicleWorkshopUiTests(unittest.TestCase):
    def page(self):
        Widget.labels = []
        required = (("CF", "1559212036"), ("Avalon", "3225634444"))
        dashboard = SimpleNamespace(
            azimuth=SimpleNamespace(avalon_workshop_status=Mock(return_value=(True, {x[1] for x in required})),
                                    enable_avalon_workshop=Mock()),
            server=object(), skins_page=SimpleNamespace(_export_vehicle_data=Mock()),
            action=Mock(), show_notice=Mock(), open_avalon_pack_item=Mock(return_value=True),
            panel=lambda parent: Widget(parent),
            label=lambda parent, text, **kwargs: Widget(parent, text=text, **kwargs),
            button=lambda parent, text, command, **kwargs: Widget(parent, text=text, command=command, **kwargs))
        page = SimpleNamespace(dashboard=dashboard, items=required, status=None, opened=set(), busy=False,
                               rows={}, vehicle_items=vehicle_workshop.ITEMS, vehicle_status=None,
                               vehicle_opened=set(), vehicle_rows={}, children=[], winfo_toplevel=lambda: "window")
        for name in ("_build", "_render_controls", "_bind_scroll", "_wheel", "_draw_progress", "render_status",
                     "render_vehicle_status", "show_vehicle_error", "set_busy", "_open_item", "_open_next",
                     "_open_vehicle_item", "_open_next_vehicle", "_export_vehicle_data", "_open_steam_downloads",
                     "_refresh", "_refreshed", "_enable", "_enabled"):
            setattr(page, name, MethodType(getattr(dashboard_workshop.WorkshopPage, name), page))
        with patch.object(dashboard_workshop.tk, "Frame", Widget), patch.object(dashboard_workshop.tk, "Canvas", Widget), \
                patch.object(dashboard_workshop.ttk, "Scrollbar", Widget):
            page._build()
        page._render_controls()
        return page

    def test_all_fourteen_vehicle_rows_precede_required_rows_and_have_exact_links(self):
        page = self.page()
        self.assertEqual(14, len(page.vehicle_rows))
        self.assertEqual(vehicle_workshop.ITEMS[0][0], next(iter(page.vehicle_rows)))
        self.assertEqual("3456445155", next(iter(page.vehicle_rows)))
        current = Widget.labels.index("Current Avalon pack")
        for _item_id, title, _detail in vehicle_workshop.ITEMS:
            self.assertLess(Widget.labels.index(title), current)
        self.assertGreater(Widget.labels.index("Community Framework"), current)
        for item_id, (_label, action) in page.vehicle_rows.items():
            action.options["command"]()
            page.dashboard.open_avalon_pack_item.assert_called_with(item_id, "window")
        page.dashboard.azimuth.enable_avalon_workshop.assert_not_called()
        page.dashboard.action.assert_not_called()

    def test_extra_downloads_never_change_required_pack_readiness(self):
        page = self.page()
        page.render_status((True, {"1559212036", "3225634444"}))
        expected = page.status, dict(page.pack_state.options), dict(page.summary.options), list(page.progress.drawings)
        page.render_vehicle_status(set())
        self.assertEqual(expected, (page.status, page.pack_state.options, page.summary.options, page.progress.drawings))
        page.render_vehicle_status(set(vehicle_workshop.ITEM_IDS) | {"not-a-candidate"})
        self.assertEqual(expected, (page.status, page.pack_state.options, page.summary.options, page.progress.drawings))
        self.assertEqual(set(vehicle_workshop.ITEM_IDS), set(page.vehicle_status))
        self.assertEqual("", page.enable_button.winfo_manager())
        self.assertEqual("Auto-load", page.vehicle_rows["3639695989"][0].options["text"])
        self.assertTrue(all(label.options["text"] == "Auto-load" for identity, (label, _action) in page.vehicle_rows.items() if identity != "3639695989"))
        self.assertIn("14 packs configured", page.vehicle_summary.options["text"])

    def test_next_vehicle_follows_catalog_skips_found_and_cycles_unopened(self):
        page = self.page()
        page.render_vehicle_status(set())
        first, second = [row[0] for row in vehicle_workshop.ITEMS[:2]]
        page._open_next_vehicle()
        page.dashboard.open_avalon_pack_item.assert_called_with(first, "window")
        page._open_next_vehicle()
        page.dashboard.open_avalon_pack_item.assert_called_with(second, "window")
        page.render_vehicle_status(set(vehicle_workshop.ITEM_IDS) - {second})
        page._open_next_vehicle()
        page.dashboard.open_avalon_pack_item.assert_called_with(second, "window")
        self.assertEqual(set(), page.opened)

    def test_open_failure_does_not_advance_or_start_setup(self):
        page = self.page()
        page.render_vehicle_status(set())
        page.dashboard.open_avalon_pack_item.return_value = False
        page._open_next_vehicle()
        self.assertEqual(set(), page.vehicle_opened)
        page.dashboard.action.assert_not_called()
        page.dashboard.show_notice.assert_not_called()
        self.assertFalse(page._open_vehicle_item("999999"))
        self.assertEqual(1, page.dashboard.open_avalon_pack_item.call_count)

    def test_export_reuses_existing_skin_export_and_respects_busy_guard(self):
        page = self.page()
        page._export_vehicle_data()
        page.dashboard.skins_page._export_vehicle_data.assert_called_once_with()
        page.set_busy(True)
        page._export_vehicle_data()
        page._refresh()
        page._open_next_vehicle()
        self.assertEqual(1, page.dashboard.skins_page._export_vehicle_data.call_count)
        page.dashboard.action.assert_not_called()
        page.dashboard.open_avalon_pack_item.assert_not_called()
        self.assertEqual("disabled", page.vehicle_export_button.options["state"])
        self.assertTrue(all(action.options["state"] == "disabled" for _state, action in page.vehicle_rows.values()))

    def test_manual_refresh_defers_both_scans_and_renders_both_statuses(self):
        page = self.page()
        found = {vehicle_workshop.ITEMS[0][0]}
        with patch.object(vehicle_workshop, "downloaded_ids", return_value=found) as scan:
            page._refresh()
            scan.assert_not_called()
            page.dashboard.azimuth.avalon_workshop_status.assert_not_called()
            label, command, done = page.dashboard.action.call_args.args
            self.assertIn("Checking", label)
            result = command()
            scan.assert_called_once_with(page.dashboard.server)
            page.dashboard.azimuth.avalon_workshop_status.assert_called_once_with()
            done(result)
        self.assertEqual(frozenset(found), page.vehicle_status)
        self.assertTrue(page.status[0])
        self.assertEqual("Auto-load", page.vehicle_rows[next(iter(found))][0].options["text"])
        self.assertEqual("Not downloaded", page.vehicle_rows[vehicle_workshop.ITEMS[1][0]][0].options["text"])

    def test_candidate_scan_error_retains_required_pack_success(self):
        page = self.page()
        with patch.object(vehicle_workshop, "downloaded_ids", side_effect=OSError("drive unavailable")):
            page._refresh()
            _label, command, done = page.dashboard.action.call_args.args
            done(command())
        self.assertTrue(page.status[0])
        self.assertIsNone(page.vehicle_status)
        self.assertIn("Click Refresh", page.vehicle_summary.options["text"])
        self.assertEqual("disabled", page.vehicle_next_button.options["state"])
        self.assertTrue(page.dashboard.show_notice.call_args.kwargs["error"])

    def test_required_scan_error_still_renders_candidate_success(self):
        page = self.page()
        page.dashboard.azimuth.avalon_workshop_status.side_effect = OSError("pack scan failed")
        with patch.object(vehicle_workshop, "downloaded_ids", return_value=set(vehicle_workshop.ITEM_IDS)):
            page._refresh()
            _label, command, done = page.dashboard.action.call_args.args
            done(command())
        self.assertIsNone(page.status)
        self.assertEqual(frozenset(vehicle_workshop.ITEM_IDS), page.vehicle_status)
        self.assertEqual("disabled", page.vehicle_next_button.options["state"])
        self.assertTrue(page.dashboard.show_notice.call_args.kwargs["error"])

    def test_automatic_poll_runs_both_catalogs_in_worker_and_keeps_payloads_separate(self):
        in_worker = [False]
        server = SimpleNamespace(active_world_id="avalon", process=None, status=Mock(return_value={}),
                                 recent_logs=Mock(return_value=""), backup_status=Mock(return_value={}))
        required = (True, {"1559212036", "3225634444"})
        dash = SimpleNamespace(polling=False, busy=False, next_workshop_poll=0,
                               next_backups_poll=float("inf"), next_skins_poll=float("inf"),
                               server=server, azimuth=SimpleNamespace(avalon_workshop_status=Mock(return_value=required)),
                               monitor=SimpleNamespace(sample=Mock(return_value={})), results=Queue(),
                               window=SimpleNamespace(after=Mock()), poll_status=Mock())
        dash._poll_optional = MethodType(dashboard_module.Dashboard._poll_optional, dash)
        class ImmediateWorker:
            def __init__(self, target, daemon): self.target = target
            def start(self):
                in_worker[0] = True
                try: self.target()
                finally: in_worker[0] = False
        def vehicle_scan(actual_server):
            self.assertTrue(in_worker[0])
            self.assertIs(server, actual_server)
            return {"3456445155"}
        with patch.object(dashboard_module.threading, "Thread", ImmediateWorker), \
                patch.object(dashboard_module, "get_lan_ip", return_value="127.0.0.1"), \
                patch.object(vehicle_workshop, "downloaded_ids", side_effect=vehicle_scan):
            dashboard_module.Dashboard.poll_status(dash)
        packets = []
        while not dash.results.empty(): packets.append(dash.results.get_nowait())
        self.assertEqual(["status", "workshop", "vehicle_workshop", "poll_done"], [row[0] for row in packets])
        self.assertEqual(required, packets[1][2])
        self.assertEqual({"3456445155"}, packets[2][2])
        dash.window.after.assert_called_once_with(2000, dash.poll_status)

    def test_vehicle_poll_results_dispatch_without_overwriting_required_status(self):
        for error in (None, OSError("Steam unavailable")):
            with self.subTest(error=error):
                page = SimpleNamespace(render_vehicle_status=Mock(), show_vehicle_error=Mock())
                dash = SimpleNamespace(results=Queue(), busy=False, events=[], stop_deadline=0,
                                       server=SimpleNamespace(events=Queue()),
                                       azimuth=SimpleNamespace(play_error="", show_requested=lambda: False),
                                       last_play_error="", workshop_status=(True, frozenset({"1559212036"})),
                                       workshop_page=page, redact=lambda value: value,
                                       refresh=Mock(), render_logs=Mock(), window=SimpleNamespace(after=Mock()),
                                       drain_queues=Mock())
                dash.results.put(("vehicle_workshop", None, {"3456445155"}, error))
                dashboard_module.Dashboard.drain_queues(dash)
                self.assertEqual((True, frozenset({"1559212036"})), dash.workshop_status)
                if error is None:
                    page.render_vehicle_status.assert_called_once_with({"3456445155"})
                    page.show_vehicle_error.assert_not_called()
                else:
                    page.show_vehicle_error.assert_called_once_with("Steam unavailable")
                    page.render_vehicle_status.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)
