"""Source/config/model tests; no native DayZ rendering claim."""
from pathlib import Path
import json
import os
import sys
import unittest

WORK = Path(__file__).resolve().parents[2]
ROOT = Path(os.environ.get('AZIMUTH_TEST_ROOT', WORK/'vehicle_finish/package/Azimuth'))
sys.path[:0] = [str(ROOT/'Engine'), str(WORK/'vehicle_integration/research/tools')]
from azimuth_app.transport import vehicle_asset_compat as repair
from config_index import ConfigIndex, load_records
from decode_config import Text


def properties(node, path=()):
    result = {path+(key,): value for key, value in node.get('properties', {}).items()}
    for name, child in node.get('classes', {}).items():
        result.update(properties(child, path+(name,)))
    return result


class PublisherAssetRecoveryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records = load_records()
        cls.before = ConfigIndex(cls.records)
        patches, vehicles = repair.config_parts([repair.WORKSHOP_ID])
        cls.text = f'class CfgPatches {{{patches}}}; class CfgVehicles {{{vehicles}}};'
        cls.tree = Text(cls.text).decode()['root']
        rec = {'source':'asset_repair','archive':'asset_repair','prefix':'asset_repair',
               'input_path':'asset_repair','input_sha256':'generated'}
        cls.after = ConfigIndex(cls.records+[(rec, cls.tree)])
        cls.roots = {'Van_Cybertruck','Van_DodgePhoenix','Van_HiluxCamper',
                     'Van_CamperRV_Doors_Driver','Van_HiluxCamper_Doors_Driver'}
        cls.names = []
        for name in cls.before.section('CfgVehicles'):
            base = cls.before.resolve(name, include_nested=False)
            if name in cls.roots or any(a in cls.roots for a in base['ancestry']):
                cls.names.append(name)
        cls.pairs = {name:(cls.before.resolve(name),cls.after.resolve(name)) for name in cls.names}

    def test_patch_is_gated_to_exact_installed_publisher(self):
        self.assertEqual(('', ''),repair.config_parts([]))
        self.assertEqual(('', ''),repair.config_parts(['3125203834']))
        needed = self.tree['classes']['CfgPatches']['classes'][repair.PATCH]['properties']['requiredAddons']
        self.assertEqual(set(needed),set(repair.SOURCE_HASHES))
        self.assertTrue(set(needed).issubset(self.before.section('CfgPatches')))

    def test_original_config_hashes_match_new_uploaded_payloads(self):
        manifest = json.loads((WORK/'vehicle_finish/input/assets/Vehicle_Repair_Files.json').read_text())
        hashes = {r['sha256'] for r in manifest['files'] if r.get('kind')=='config' and r.get('status')=='copied'}
        self.assertTrue(set(repair.SOURCE_HASHES.values()).issubset(hashes))

    def test_only_intended_renderer_properties_change_across_descendants(self):
        self.assertGreater(len(self.pairs),20)
        for name,(before,after) in self.pairs.items():
            with self.subTest(name=name):
                self.assertEqual(before['parent'],after['parent'])
                self.assertEqual(before['properties'],after['properties'])
                old,new=properties(before),properties(after)
                self.assertEqual(set(old),set(new))
                for path,value in old.items():
                    if value == new[path]:continue
                    self.assertEqual(path[:2],('DamageSystem','DamageZones'))
                    self.assertEqual(path[-2],'Health')
                    self.assertIn(path[-1],('RefTexsMats','healthLevels'))
                    if path[-1]=='healthLevels':
                        self.assertEqual([p[0] for p in value],[p[0] for p in new[path]])
                        self.assertEqual(value[-1],new[path][-1])

    def test_missing_window_requests_are_empty_but_terminal_hiding_remains(self):
        count=0
        for name,(before,after) in self.pairs.items():
            for path,value in properties(before).items():
                if path[-1]!='healthLevels':continue
                original=json.dumps(value).lower()
                if ('van_dodgephoenix' not in original and 'van_hiluxcamper' not in original):continue
                updated=properties(after)[path]
                self.assertEqual([[],[],[],[]],[row[1] for row in updated[:-1]])
                self.assertEqual('hidden',updated[-1][1]);count+=1
        self.assertGreater(count,20)

    def test_invalid_refs_removed_from_effective_affected_config(self):
        for name,(_,after) in self.pairs.items():
            text=json.dumps(list(properties(after).items()))
            folded=text.lower().replace('\\\\','/')
            self.assertNotIn('van_dodgephoenix/data/steklo',folded,name)
            self.assertNotIn('van_hiluxcamper/data/glass',folded,name)
            self.assertNotIn('/armor/armor_body.rvmat',folded,name)

    def test_door_selectors_match_actual_exterior_model_materials(self):
        metadata=json.loads((WORK/'vehicle_finish/reports/wraps/model_geometry.json').read_text())
        models={m['resource']:m for m in metadata['models']}
        inventory=json.loads((WORK/'collector_repair/input/evidence/Vehicle_Wrap_Evidence.json').read_text())
        assets={
            (a.get('virtual_prefix','').rstrip('/')+'/'+m['path'].replace('\\','/')).lower()
            for a in inventory['archives'] for m in a.get('members',[])
        }
        names={'Van_CamperRV_Doors_Driver':'van_camperrv/proxy/van_camperrv_doors_driver.p3d',
               'Van_HiluxCamper_Doors_Driver':'van_hiluxcamper/proxy/van_hiluxcamper_doors_driver.p3d'}
        for name,resource in names.items():
            model=models[resource]
            materials={m.lower().replace('\\','/') for lod in model['visual_lods'] for m in lod['materials']}
            for selected in repair.DOOR_MATERIAL_SELECTORS[name]:
                self.assertIn(selected,materials);self.assertIn(selected,assets)
                self.assertNotIn('mirror',selected);self.assertNotIn('penetration',selected)
            # Both original models have alpha glass with no assigned material.
            glass=[s for lod in model['visual_lods'] for s in lod['sections'] if (s.get('texture') or '').startswith('#(argb')]
            self.assertTrue(glass)
            self.assertTrue(all(s['material'] is None for s in glass))

    def test_cybertruck_existing_same_vehicle_aliases_are_preserved(self):
        node=self.after.resolve('Van_Cybertruck')
        for path,value in properties(node).items():
            if path[-1]!='healthLevels' or path[2] not in ('Windowfront','Windowrear','Windowleft','Windowright'):continue
            self.assertEqual('hidden',value[-1][1])
            for _,materials in value:
                if isinstance(materials,list):
                    for material in materials:self.assertTrue(material.lower().startswith('van_cybertruck/data/glass'))


if __name__=='__main__':unittest.main(verbosity=2)
