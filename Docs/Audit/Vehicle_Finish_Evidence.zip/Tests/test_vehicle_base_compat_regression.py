from __future__ import annotations
import copy,json,os,pathlib,sys,unittest
BASE=pathlib.Path(__file__).resolve().parents[2]/"vehicle_integration"
ROOT=pathlib.Path(os.environ.get('AZIMUTH_TEST_ROOT',pathlib.Path(__file__).resolve().parents[1]/"package/Azimuth"))
sys.path.insert(0,str(ROOT/'Engine'));sys.path.insert(0,str(BASE/'research/tools'))
from azimuth_app.transport import vehicle_base_compat as base_compat,vehicle_slot_compat
from config_index import ConfigIndex,load_records
from decode_config import Text
RECORD={'source':'azimuth_test','archive':'compat','prefix':'compat','input_path':'compat','input_sha256':'test'}
def sem(node):return {'properties':node.get('properties',{}),'classes':{k:sem(v) for k,v in node.get('classes',{}).items()}}
def remove(node,path):
 for key in path[:-1]:node=node['classes'][key]
 node['classes'].pop(path[-1],None)
def wheels(vehicle):
 module=vehicle['classes']['SimulationModule'];axles=module['classes']['Axles']['classes'];slots=[]
 for axle in axles.values():
  for wheel in axle['classes'].get('Wheels',{}).get('classes',{}).values():
   value=next((v for k,v in wheel['properties'].items() if k.lower()=='inventoryslot'),None)
   if value:slots.append(value)
 return slots
class BaseCompatibilityTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.records=load_records();cls.before=ConfigIndex(cls.records)
  cls.text=vehicle_slot_compat.config_fragment(ROOT,['3387855369'])
  cls.tree=Text(cls.text).decode()['root'];cls.after=ConfigIndex(cls.records+[(RECORD,cls.tree)])
  cls.data=json.loads((ROOT/base_compat.DATA).read_text())
 def test_inactive_pack_has_no_base_patch(self):
  self.assertEqual(base_compat.config_parts(ROOT,[]),('',''));self.assertEqual(base_compat.config_parts(ROOT,['3456445155']),('',''))
 def test_dependency_names_exact_4k_providers(self):
  p=self.tree['classes']['CfgPatches']['classes'][base_compat.PATCH]['properties']
  expected=set()
  for r,n in self.records:
   if r['source']=='workshop_3387855369_library_1' and 'CarScript' in n['classes'].get('CfgVehicles',{}).get('classes',{}):expected.update(n['classes'].get('CfgPatches',{}).get('classes',{}))
  self.assertEqual(set(p['requiredAddons']),expected);self.assertEqual(len(expected),7)
 def test_shared_axle_nodes_removed_and_native_fuel_capacity_restored(self):
  before=sem(self.before.resolve('CarScript'));after=sem(self.after.resolve('CarScript'))
  for path in base_compat.PATHS:remove(before,path)
  before["properties"]["fuelCapacity"] = 50  # Intentional v46 scalar restoration.
  self.assertEqual(before,after)
  self.assertIn('Cargo1',after['classes']['Crew']['classes']);self.assertIn('Cargo2',after['classes']['Crew']['classes'])
 def test_entire_kamaz_behavior_tree_preserved(self):
  for name in ['Kamaz_TyphoonK','Kamaz_TyphoonK_Green','Kamaz_TyphoonK_Rusty']:
   with self.subTest(name=name):self.assertEqual(sem(self.before.resolve(name)),sem(self.after.resolve(name)))
 def test_gunter_audi_kamaz_wheel_sets(self):
  for name,prefix,count in [('Hatchback_02_Blue','Hatchback_02_Wheel_',4),('Audi_R8_Base','Audi_R8_Wheel_',4),('Kamaz_TyphoonK','Kamaz_TyphoonK_Wheel_',6)]:
   with self.subTest(name=name):
    slots=wheels(self.after.resolve(name));self.assertEqual(len(slots),count);self.assertTrue(all(s.startswith(prefix) for s in slots))
  self.assertEqual(len(wheels(self.before.resolve('Audi_R8_Base'))),6)
 def test_no_explicit_subclasses_reference_deleted_children(self):
  names={path[-1].lower() for path in base_compat.PATHS};found=[]
  def walk(c,path):
   if c.get('parent','').lower() in names:found.append(path)
   for key,child in c.get('classes',{}).items():walk(child,path+'/'+key)
  for r,n in self.records:walk(n,r['input_path'])
  self.assertEqual(found,[])
 def test_no_unrelated_top_level_properties_change(self):
  model_rows=json.loads((ROOT/'Custom/Transport/Workshop/wrap_model_compat.json').read_text())['classes']
  for name in self.before.section('CfgVehicles'):
   with self.subTest(name=name):
    before={k:v for k,v in self.before.resolve(name,include_nested=False)['properties'].items() if k.lower() not in {'weight','fuelcapacity'}}
    after={k:v for k,v in self.after.resolve(name,include_nested=False)['properties'].items() if k.lower() not in {'weight','fuelcapacity'}}
    if before.get('hiddenSelections') != after.get('hiddenSelections'):
     chain=[name]+self.before.resolve(name,include_nested=False)['ancestry']
     changes=[row for row in model_rows if row['workshop_id']=='3387855369' and row['name'] in chain]
     self.assertTrue(changes,name)
     appended=[section for row in reversed(changes) for section in row['append']]
     expected=before.get('hiddenSelections',[])+appended
     self.assertEqual(after.get('hiddenSelections'),expected,name)
     before['hiddenSelections']=expected
    self.assertEqual(before,after)
 def test_one_cfgvehicles_with_both_repairs(self):
  active=['3387855369','2651195301','2880254695','3834034916','3225634444']
  original=(ROOT/'Custom/GunSkins/RandomSkins/azimuthrandomskins/config.cpp').read_text()
  d=Text(vehicle_slot_compat.apply_config(original,ROOT,active)).decode()['root']
  self.assertEqual(sum(e['kind']=='class' and e['name']=='CfgVehicles' for e in d['entries']),1)
  self.assertEqual(sum(e['kind']=='class' and e['name']=='CfgPatches' for e in d['entries']),1)
  self.assertIn(base_compat.PATCH,d['classes']['CfgPatches']['classes']);self.assertIn(vehicle_slot_compat.PATCH,d['classes']['CfgPatches']['classes'])
 def test_independent_truck_copies_exact_publisher_definitions(self):
  raw=next(n for r,n in self.records if r['input_path']==self.data['evidence_config'])['classes']['CfgVehicles']['classes']
  def get(c,path):
   for key in path:c=c['classes'][key]
   return c
  for row in self.data['isolation']:
   reference='Kamaz_TyphoonK' if row['truck_definition_source']=='existing_truck' else 'CarScript'
   self.assertEqual(sem(get(raw[reference],row['path'])),sem(row['definition']))
   c=get(self.tree['classes']['CfgVehicles']['classes']['Kamaz_TyphoonK'],row['path']);self.assertEqual(c['parent'],row['definition']['parent']);self.assertNotIn(c['parent'],{p[-1] for p in base_compat.PATHS})
if __name__=='__main__':unittest.main(verbosity=2)
