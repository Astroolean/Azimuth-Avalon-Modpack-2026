"""Captured geometry/config checks and extracted production-rule execution."""
from pathlib import Path
import importlib.util, json, os, re, subprocess, sys, tempfile, unittest
BASE=Path(__file__).resolve().parents[2]
ROOT=Path(os.environ.get('AZIMUTH_TEST_ROOT',BASE/'vehicle_finish/package/Azimuth'))
sys.path.insert(0,str(ROOT/'Engine'))
from azimuth_app.transport import vehicle_wrap_model_compat as compat, vehicle_slot_compat
spec=importlib.util.spec_from_file_location('installed_rules_adapter',BASE/'vehicle_integration/Tests/test_installed_vehicle_rules.py');adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
EVIDENCE=json.loads((BASE/'vehicle_finish/reports/wraps/model_wrap_candidates.json').read_text())
SOURCE=ROOT/'Custom/GunSkins/RandomSkins/azimuthrandomskins/scripts/4_world/azimuth_vehicle_wrap_rules.c'

class ModelCompatTests(unittest.TestCase):
 def test_append_only_gated_config_preserves_native_indices_and_materials(self):
  rows=compat.load(ROOT);self.assertEqual(24,len(rows))
  self.assertEqual(('',''),compat.config_parts(ROOT,[]))
  self.assertEqual(('',''),compat.config_parts(ROOT,['9999999999']))
  patch,text=compat.config_parts(ROOT,{r['workshop_id'] for r in rows})
  self.assertEqual(24,text.count('hiddenSelections[] +='))
  for prohibited in ['hiddenSelectionsTextures','hiddenSelectionsMaterials','model =','DamageSystem','SimulationModule']:
   self.assertNotIn(prohibited,text)
  for row in rows:
   self.assertFalse(set(n.lower() for n in row['original_selections']) & set(row['append']))
   self.assertIn('class '+row['name']+': '+row['parent'],text)
  patch,text=compat.config_parts(ROOT,['3639695989'])
  self.assertNotIn('Audi_R8_White',text)
  self.assertIn('LM_DC_3',text)
  self.assertNotIn('LM_Catalina',text)
  self.assertNotIn('LM_Cessna180',text)
 def test_inherited_variants_do_not_duplicate_appended_names(self):
  names={r['name'] for r in compat.load(ROOT)}
  for inherited in ['ExpansionBigGyrocopter','ExpansionVodnik_Camo','ExpansionVodnik_CamoMedical','MotorHome_Rust','MotorHome_GreenCamo']:
   self.assertNotIn(inherited,names)
 def test_one_cfgvehicles_and_duplicate_install_guard(self):
  original=(ROOT/'Custom/GunSkins/RandomSkins/azimuthrandomskins/config.cpp').read_text()
  generated=vehicle_slot_compat.apply_config(original,ROOT,['3639695989','3387855369','2291785437','2880254695'])
  self.assertEqual(1,len(re.findall(r'\bclass\s+CfgVehicles\s*\{',generated)))
  self.assertEqual(1,generated.count('class Azimuth_VehicleWrapModelCompatibility'))
  with self.assertRaises(ValueError):vehicle_slot_compat.apply_config(generated,ROOT,['3639695989'])
 def test_actual_compiled_selection_guards_and_protected_surfaces(self):
  with tempfile.TemporaryDirectory() as td:
   cpp=Path(td)/'rules.cpp';exe=Path(td)/'rules'
   cpp.write_text(adapter.legacy.ADAPTER+adapter.translate_rules(SOURCE.read_text())+adapter.MAIN)
   result=subprocess.run(['g++','-std=c++17','-fsanitize=undefined','-fno-sanitize-recover=all','-O1',str(cpp),'-o',str(exe)],capture_output=True,text=True,timeout=60)
   self.assertEqual(0,result.returncode,result.stderr)
   cases=[];expect=[]
   for c in EVIDENCE['candidates']:
    if '/proxy/' in c['resource']:continue
    for sel in c['selections']:
     cases.extend([adapter.body(c['resource'],sel['name'],''),adapter.body(c['resource'],sel['name'],'',server=True)])
     expect.extend([1,1])
    for name in ['glass','light_1_1','wheel','camo_interior','rotor','antiwater','unknown']:
     cases.append(adapter.body(c['resource'],name));expect.append(0)
   for c in EVIDENCE['blocked_main_models']:
    if c['resource']=='airship/data/airship.p3d':continue  # Existing isolated banners remain supported.
    for sel in ['camo','camo1','camo2','zbytek','dmgzone_doors']:
     cases.append(adapter.body(c['resource'],sel,'publisher_body_co.paa',server=True));expect.append(0)
   # Preserve proven working Gunter, kart, golf cart, RHIB and scooter routes.
   for model,name in [('dz/vehicles/wheeled/hatchback_02/hatchback_02.p3d','camo_chassi'),('mbm_gokart/gokart.p3d','camo'),('tb_golfcart/tb_golfcart.p3d','camo'),('van_rhib/van_rhib.p3d','camo1'),('crsk_vespa_125_primavera/crsk_vespa_125_primavera.p3d','camo2')]:
    cases.append(adapter.body(model,name));expect.append(1)
   p=subprocess.run([str(exe)],input='\n'.join('\t'.join(c) for c in cases)+'\n',capture_output=True,text=True,timeout=30)
   self.assertEqual(0,p.returncode,p.stderr)
   values=[int(v) for v in p.stdout.splitlines()]
   self.assertEqual(len(expect),len(values))
   self.assertEqual([],[(c,e,v) for c,e,v in zip(cases,expect,values) if e!=v][:10])

if __name__=='__main__':unittest.main()
