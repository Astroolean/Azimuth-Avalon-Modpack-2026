"""Package the audited Azimuth repair, retaining original payload and evidence."""
from pathlib import Path
from hashlib import sha256
import json
import os
import re
import zipfile

TASK = Path(__file__).resolve().parent
ROOT = TASK / 'package/Azimuth'
PARENT = json.loads((TASK / 'parent.json').read_text())
OUTPUT = TASK / 'output/Azimuth_DayZ_Server_Manager_R23_Full_Audit_Repair.zip'

def digest(path):
    h = sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def sources(root):
    return {p.relative_to(root).as_posix(): digest(p) for p in sorted(root.rglob('*'))
            if p.is_file() and not p.relative_to(root).as_posix().startswith('Docs/')}

def count(path):
    text = path.read_text()
    matches = re.findall(r'Ran (\d+) tests? in', text)
    if not matches or not re.search(r'^OK\s*$', text, re.M) or re.search(r'^(FAILED|ERROR:|FAIL:)', text, re.M):
        raise ValueError(f'No passing test result: {path}')
    return int(matches[-1])

def preserve():
    parent = Path(PARENT['archive'])
    if digest(parent) != PARENT['sha256']:
        raise ValueError('Parent ZIP identity changed.')
    changed, unchanged, protected = [], [], []
    with zipfile.ZipFile(parent) as archive:
        names = set()
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = info.filename.removeprefix('Azimuth/')
            names.add(name)
            target = ROOT / name
            if not target.is_file() or target.is_symlink():
                raise ValueError(f'Original file missing or unsafe: {name}')
            same = sha256(archive.read(info)).hexdigest() == digest(target)
            (unchanged if same else changed).append(name)
            if (name.startswith(('Custom/GunSkins/Art/', 'Custom/GunSkins/azimuthskins/',
                                 'Custom/GunSkins/VehicleShowcase/', 'Worlds/'))
                    or name in {'Custom/GunSkins/catalog.json',
                                'Engine/azimuth_app/cosmetics/vehicle_showcase.py'}):
                if not same:
                    raise ValueError(f'Protected payload changed: {name}')
                protected.append(name)
    all_files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    if any('/__pycache__/' in p or p.endswith(('.pyc', '.tmp')) for p in all_files):
        raise ValueError('Temporary output in release payload.')
    if any(p.is_symlink() for p in ROOT.rglob('*')):
        raise ValueError('Link in release payload.')
    if any(p.startswith(('Config/', 'Backups/', 'Profiles/')) for p in all_files):
        raise ValueError('User state was accidentally packaged.')
    return {'parent_sha256': PARENT['sha256'], 'changed': changed,
            'unchanged': unchanged, 'added': sorted(all_files - names),
            'protected_unchanged': protected, 'removed': [],
            'live_user_state_changed': False}

def write_evidence(final=False):
    ui_path = TASK / 'reports/ui/package_review.json'
    ui = json.loads(ui_path.read_text())
    ui['collector_target_resources'] = 200
    ui['collector_workshop_owners'] = 12
    ui_path.write_text(json.dumps(ui, indent=2) + '\n')
    verification = {
        'release': OUTPUT.name, 'parent': PARENT,
        'repair_tests': count(TASK / 'reports/all_repair_tests_final.log'),
        'retained_regressions': count(TASK / 'reports/retained_regressions.log'),
        'skin_assets': 'All 30 finishes passed the bundled binary/format/reference checker.',
        'native_dayz_compilation_or_execution': False,
        'native_windows_execution': False,
        'live_user_files_modified': False,
        'scope': 'Source, actual supplied configuration, isolated file operations, and extracted code adapters.',
        'remaining': [
            '33 vehicle variants without mapped exteriors; 8 fitted panels only; 19 require live opaque readback.',
            'LMs Planes unreadable export; original installed PBO required.',
            '8 missing publisher material paths and Tech ATV handlebars model lack supplied replacements.',
            'Native game execution, terrain survey results, rendering and handling were not run here.'
        ],
    }
    if final:
        verification['fresh_zip_repair_tests'] = count(TASK / 'reports/fresh_zip_repair_tests.log')
        verification['fresh_zip_retained_regressions'] = count(TASK / 'reports/fresh_zip_retained_regressions.log')
        fresh = sources(TASK / 'fresh/Azimuth')
        if fresh != sources(ROOT):
            raise ValueError('Packaged code/assets changed after fresh-ZIP qualification.')
        verification['fresh_zip_code_and_asset_hashes_match_final'] = True
    audit = ROOT / 'Docs/Audit'
    (audit / 'Full_Audit_Repair_Verification.json').write_text(json.dumps(verification, indent=2) + '\n')
    preservation = preserve()
    (TASK / 'reports/package_preservation.json').write_text(json.dumps(preservation, indent=2) + '\n')
    paths = [TASK / 'parent.json', TASK / 'finalize_release.py']
    paths += sorted((TASK / 'Tests').glob('*.py'))
    paths += [p for p in (TASK / 'reports').rglob('*') if p.is_file()
              and 'world' not in p.relative_to(TASK / 'reports').parts
              and 'reference' not in p.relative_to(TASK / 'reports').parts
              and p.suffix in {'.json', '.log', '.txt', '.md', '.csv'}]
    with zipfile.ZipFile(audit / 'Repair_Evidence.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr('README.txt',
            'Repair sources, test harnesses and executed check reports.\n'
            'Tests use original retained release, installed-config export and Worlds.zip fixtures identified in the reports.\n'
            'Those private/source fixtures and the native game are not bundled here.\n'
            'No native DayZ pass is claimed. This is developer evidence, not a user testing assignment.\n')
        for path in paths:
            archive.write(path, path.relative_to(TASK).as_posix())
        archive.writestr('qualified_code_asset_sha256.json', json.dumps(sources(ROOT), indent=2) + '\n')

def package():
    preserve()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    temporary = OUTPUT.with_suffix('.tmp')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(ROOT.rglob('*')):
            if path.is_file():
                archive.write(path, 'Azimuth/' + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() is not None:
            raise ValueError('Release ZIP CRC failed.')
        for name in archive.namelist():
            path = ROOT / name.removeprefix('Azimuth/')
            if sha256(archive.read(name)).hexdigest() != digest(path):
                raise ValueError('ZIP payload mismatch: ' + name)
    os.replace(temporary, OUTPUT)
    result = {'path': str(OUTPUT), 'sha256': digest(OUTPUT), 'bytes': OUTPUT.stat().st_size,
              'files': len([p for p in ROOT.rglob('*') if p.is_file()])}
    (TASK / 'release.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--final', action='store_true')
    args = parser.parse_args()
    write_evidence(final=args.final)
    package()
