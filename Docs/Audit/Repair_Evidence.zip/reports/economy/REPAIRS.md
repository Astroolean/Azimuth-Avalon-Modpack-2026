# Economy and mission repairs

Implemented in the shared `complete_repair/package/Azimuth` tree. **20 regression tests pass.** The original user archive, source mission files and saves were not changed.

## Completed changes

- Bicycle: validates the retained installed attachment definitions against every exact publisher event variant and wheel class, then migrates all eight variants to 40 distinct existing Avalon road sites. Unknown, duplicate and nonpositive wheel rules are refused.
- Humvee: generates a complete managed event override fixing only the exact known min 3/max 2 contradiction to min 3/max 4, preserving parent nominal 4 and other settings.
- Static routes: HipPack_Party gains its sibling's Village route; SVD_Wooden and PunchedCard gain verified Military routes. Original usages, tiers, flags and source counts 3/4/3 remain intact. No general rare-item uplift is applied to these repaired rows.
- Event availability: nominal-zero events and zero-capacity children no longer count as positive sources. Custom infected distribution weights retain their separate meaning.
- Checker: adds event numeric/flag/mode/child validation, finite coordinate pools, positive fixed vehicle-site requirements, all registered cargo/attachment/preset chance ranges, duplicate root detection and required CE root/action checks. Additional vehicle roots are resolved from the exact catalog.
- BeeHive: adds bounded inspection of installed config.cpp/config.bin and raw PBO config members to recover missing concrete companion classes. Only scope=2 classes positively identifying spatula, dipper or honey-pot roles are used; local inheritance across config payloads is resolved, ambiguity is refused, ruined/full variants excluded, authored rows preserved, and new supply pots start empty. Missing assets or unsupported config encodings produce explicit setup evidence rather than fabricated class names.

## Actual mission result

The supplied archived mission plus available publisher bicycle data and current adapters produces 2,310 effective CE classes. The expanded checker validates 56 events, nine active vehicle events, 1,909 probability fields and nine CE roots. It reports **zero errors and zero unmatched ordinary static routes**. The original db/types, db/events, cfgspawnabletypes, mapgroupproto and mapgrouppos remain byte-identical. Repeated repair and balance is byte-stable.

The four regression mutations formerly ignored by the checker are now individually detected: removing MotorbikeScript, a nonnumeric event nominal, an entirely invalid vehicle coordinate pool, and attachment chance=2. Actual publisher Lady_Bicycle fallback, malicious wheel rejection, all 61 ammo/box/magazine policy classes, source preservation and Humvee/event-source fixes also pass.

## Evidence limit

Actual BeeHive binaries were not supplied. The recovery code is covered by explicit synthetic publisher fixtures, raw-PBO inspection tests, and a decoder check against the actual supplied Bicycle binary config; this is not a claim that particular real BeeHive class names were discovered here. The code performs that discovery from the installed publisher release. The eight ambiguous source map-prototype names remain warnings; no engine precedence was invented. No native DayZ execution is claimed.

See `test_results.txt`, `current_check.json`, and `repair_results.json`. Tests are in `complete_repair/Tests/test_economy_repairs.py` and `test_publisher_companion_economy.py`.

Final cross-agent integration also passes with all 568 additional vehicle variants and an explicitly injected survey-site fixture: 4,593 CE classes, 63 events, 16 active vehicle events, 15,299 chance fields, zero errors and zero unmatched static routes. CarScript action corruption is detected, covering the catalog Airship root. This verifies CE integration, not native site measurements. The additional companion regression checks inherited scope/displayName across two config payloads and a role preserved on later retained-file reload.
