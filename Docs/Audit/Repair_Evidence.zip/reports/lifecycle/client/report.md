# Client repairs

Implemented in the isolated repair package at `complete_repair/package/Azimuth`. No live DayZ files or original release files were changed.

- **FPS restoration safeguard:** existing graphics baselines must contain valid managed values before a preset can overwrite the profile. Empty, unrelated, malformed and duplicate-value baselines fail without modifying either file. A managed field introduced after the original baseline is saved once with its current value, preserving earlier originals. FPS and legacy visual changes now use the existing transaction mechanism, which rolls back newly created or extended backups if profile publication fails.
- **Direct client/server compatibility check:** `require_matching_dayz_versions(client_executable, server_executable, *, loaded_server_version=None)` reads the two executable fixed file versions directly, requires full four-part resources and DayZ 1.30+, and rejects differing versions. A supplied running-server version must also match, so an on-disk update cannot conceal an older running process. Product-version strings and A2S query strings do not substitute for the file resources. Existing `require_dayz130` behavior is unchanged.

Integration owned by parent: import `require_matching_dayz_versions` from `azimuth_app.transport.transport_version` and invoke it with `client / "DayZ_x64.exe"` and `installation / "DayZServer_x64.exe"` before launch, passing `loaded_server_version` captured at server startup when Avalon is running. This child did not edit `core/azimuth.py`.

Changed source files:

- `Engine/azimuth_app/client/client_performance.py`
- `Engine/azimuth_app/transport/transport_version.py`

Validation: **18 regression tests passed**, covering damaged and partial backups, preservation of existing originals and unrelated user settings, FPS/quality transitions, legacy visual restoration, injected profile publication failures with new/existing backups, exact executable-version match/mismatch, unsupported versions, absent/incomplete fixed resources, minimum-version precedence, and an older running server after its executable was replaced on disk. Command: `PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s complete_repair/Tests -p test_client_repair.py -v`.

Evidence is code and isolated Python fixtures. Native Windows version APIs, actual installed executable pairs, Steam/BattlEye launch, and native DayZ joining were not available for execution here.
