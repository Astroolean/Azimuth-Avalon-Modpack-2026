# Independent restore review — resolved

Reviewed the repaired backup validation, restore journal and component swaps, server startup/recovery gates, launch provenance, and configured UDP reservation. The issues raised during this review are resolved in the current repair package.

- **Restore/recovery on a still-running external server:** restore now reserves the configured game, game+2, and query UDP sockets for the complete operation, including rollback. Independent real-socket probes confirmed that occupied game or query ports reject restoration before mutation, all three ports remain held at all nine observed publication/rollback rename points, and all reservations are released on completion/failure. Startup recovery loads the configured ports first and rejects recovery while one is occupied; after release, the same pending journal recovers successfully.
- **Outstanding restore journal during a later Start/Restore:** entry gates run journal recovery before continuing; failed recovery blocks further work.
- **Interruption before the first component move:** the referenced originals directory is now retained while its journal exists. Reopening recovers successfully even when the directory is still empty.

The independent interruption matrix injected `KeyboardInterrupt` before and after each of eight restore rename boundaries: **16/16 passed**, with reopened state consistently either the preserved original World/Profiles pair or the fully committed archive pair. Four additional UDP reservation checks passed, including rollback and startup recovery. Launch provenance review found no new ordinary-flow stale-clean-log bypass.

Evidence: `restore_boundary_review.json` and `restore_external_port_probe.json`. The latter supersedes the earlier open-port reproduction and explicitly records status `resolved`.

These results exercise isolated filesystem fixtures, actual local UDP sockets, and Python control flow. They do not claim native DayZ execution or machine/power-loss durability.
