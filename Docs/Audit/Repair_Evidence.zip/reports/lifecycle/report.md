# Lifecycle and client repairs

Implemented only in `complete_repair/package/Azimuth`; the authoritative v45 source and live user data were not changed.

- **Stop now completes a final backup.** The paused worker waits for graceful exit, verifies current-run shutdown evidence and archives without restarting. Scheduled maintenance still restarts.
- **Launch provenance survives reopening.** RPT baselines are saved before process creation; old clean markers cannot certify a later failed launch. Activity displays current-run report content or says no new report exists.
- **Archives are checked before use.** Verification requires safe Windows-compatible paths, one complete matching mission, valid types XML, nonempty save data, no file/directory conflicts and valid CRCs. Corrupt/future-dated archives cannot defer the backup schedule.
- **Restore is implemented.** It requires a paused/stopped manager and closed client, stages a private validated archive, retains a safety ZIP and exact replaced originals, and journals all component swaps. Failed publication rolls back. Reopening recovers interrupted swaps before starting; an unresolved journal blocks launch. All configured UDP ports remain reserved through restoration and recovery, blocking an orphan server on those ports. Current connection settings remain unchanged.
- **Graphics originals are protected.** Invalid FPS/legacy visual backups block edits; added managed settings get their own original baseline; failed edits roll back backup changes.
- **Client/server build checks are exact.** Fixed file versions must match and support 1.30+. The captured running-server version also has to match, preventing an updated executable from hiding an older running process.
- **Never-online startups are bounded.** After 180 seconds the manager requests graceful shutdown and pauses retries. It does not force-kill the world or stop a previously online server merely because a query reply is missing.
- **Survey setup is connected.** The new survey runs as a server-only mod. Play waits up to 120 seconds for its report, combines completed survey/fishing setup into one clean backup/restart before joining, and keeps existing transport available if discovery times out.

**Validation:** all 44 lifecycle/client regression tests passed. An independent reviewer additionally passed 16 injected interruption cases before/after every restore rename and four UDP reservation/recovery probes. All changed Python modules parsed successfully. Evidence is in `results.json`, `changes.json`, and `client/independent_restore_review.md`.

No native Windows/Steam/BattlEye/DayZ launch was performed. The interruption evidence covers process interruption, not power failure. Archive checks establish safe structure and CRC integrity; native save semantics and the root-owned terrain-survey runtime remain outside these tests.
