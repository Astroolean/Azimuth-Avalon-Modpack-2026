Repair sources, test harnesses and executed check reports.
Tests use original retained release, installed-config export and Worlds.zip fixtures identified in the reports.
Those private/source fixtures and the native game are not bundled here.
No native DayZ pass is claimed. This is developer evidence, not a user testing assignment.
